<?php
// =============================================
// 文件名：admin_ai_settings.php
// 用途：AI审核设置
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

$ai_config = [];
$stmt = $pdo->query("SELECT `setting_key`, `setting_value` FROM `settings` WHERE `setting_key` IN ('ai_api_url','ai_api_key','ai_model','ai_enabled')");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $ai_config[$row['setting_key']] = $row['setting_value'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $api_url = trim($_POST['api_url'] ?? '');
    $api_key = trim($_POST['api_key'] ?? '');
    $model = trim($_POST['model'] ?? '');
    $enabled = isset($_POST['enabled']) ? '1' : '0';

    try {
        $pdo->beginTransaction();
        foreach (['ai_api_url' => $api_url, 'ai_api_key' => $api_key, 'ai_model' => $model, 'ai_enabled' => $enabled] as $k => $v) {
            $stmt = $pdo->prepare("UPDATE `settings` SET `setting_value` = :value WHERE `setting_key` = :key");
            $stmt->execute([':value' => $v, ':key' => $k]);
        }
        $pdo->commit();
        $success = '设置已保存';
        $stmt = $pdo->query("SELECT `setting_key`, `setting_value` FROM `settings` WHERE `setting_key` IN ('ai_api_url','ai_api_key','ai_model','ai_enabled')");
        $ai_config = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $ai_config[$row['setting_key']] = $row['setting_value'];
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = '保存失败';
    }
}

if (isset($_GET['test'])) {
    require_once 'ai_functions.php';
    $result = ai_check_content('你好，这是一条测试文本');
    $testResult = $result['safe'] ? '安全' : '不安全';
    $testReason = $result['reason'];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI审核设置</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-row { margin-bottom: 14px; }
        .form-row label { display: block; margin-bottom: 5px; font-weight: 500; color: var(--text-light); font-size: 13px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>AI内容审核设置</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台</a>
        <a href="admin_ai_settings.php?test=1" class="btn btn-warning btn-sm">测试模型</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <?php if (isset($testResult)): ?>
        <div class="card" style="max-width:640px;">
            <h3>测试结果</h3>
            <p>结果：<strong><?php echo $testResult; ?></strong></p>
            <p>原因：<?php echo htmlspecialchars($testReason); ?></p>
        </div>
    <?php endif; ?>

    <div class="card" style="max-width:640px;">
        <h2>接口配置</h2>
        <form method="post" action="admin_ai_settings.php">
            <div class="form-row">
                <label>API URL</label>
                <input type="text" name="api_url" value="<?php echo htmlspecialchars($ai_config['ai_api_url'] ?? ''); ?>" placeholder="https://api.xxx.com/v1/chat/completions">
            </div>
            <div class="form-row">
                <label>API Key</label>
                <input type="text" name="api_key" value="<?php echo htmlspecialchars($ai_config['ai_api_key'] ?? ''); ?>">
            </div>
            <div class="form-row">
                <label>模型名称</label>
                <input type="text" name="model" value="<?php echo htmlspecialchars($ai_config['ai_model'] ?? ''); ?>" placeholder="例如 gpt-3.5-turbo">
            </div>
            <div class="form-row">
                <label>
                    <input type="checkbox" name="enabled" <?php echo ($ai_config['ai_enabled'] ?? '0') === '1' ? 'checked' : ''; ?>>
                    启用AI审核
                </label>
            </div>
            <button type="submit" class="btn">保存设置</button>
        </form>
    </div>
</body>
</html>