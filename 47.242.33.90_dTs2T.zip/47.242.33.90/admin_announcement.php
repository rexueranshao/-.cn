<?php
// =============================================
// 文件名：admin_announcement.php
// 用途：管理员修改公告
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['content'])) {
    $content = trim($_POST['content']);
    if ($content === '') {
        $error = '公告内容不能为空';
    } else {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) FROM `announcements`");
            if ($stmt->fetchColumn() > 0) {
                $stmt = $pdo->prepare("UPDATE `announcements` SET `content` = :content ORDER BY `id` DESC LIMIT 1");
                $stmt->execute([':content' => $content]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO `announcements` (`content`) VALUES (:content)");
                $stmt->execute([':content' => $content]);
            }
            $success = '公告已更新';
        } catch (PDOException $e) {
            $error = '更新失败，请重试';
        }
    }
}

try {
    $stmt = $pdo->query("SELECT `content` FROM `announcements` ORDER BY `id` DESC LIMIT 1");
    $currentContent = $stmt->fetchColumn();
} catch (PDOException $e) {
    $currentContent = '';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改公告</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>修改公告</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:760px;">
        <h2>当前公告预览</h2>
        <?php if ($currentContent): ?>
            <div style="border:1px dashed var(--border);padding:12px;border-radius:8px;background:#fafbfc;">
                <?php echo nl2br(htmlspecialchars($currentContent)); ?>
            </div>
        <?php else: ?>
            <p class="text-mute">暂无公告内容</p>
        <?php endif; ?>
    </div>

    <div class="card" style="max-width:760px;">
        <h2>编辑公告</h2>
        <form method="post" action="admin_announcement.php">
            <textarea name="content" rows="8" placeholder="请输入公告内容" required><?php echo htmlspecialchars($currentContent ?: ''); ?></textarea>
            <p class="mt-20"><button type="submit" class="btn">保存公告</button></p>
        </form>
    </div>
</body>
</html>