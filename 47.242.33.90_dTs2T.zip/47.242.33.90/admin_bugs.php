<?php
// =============================================
// 文件名：admin_bugs.php
// 用途：管理员管理bug（批量删除、奖励、编辑）
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // 批量删除
    if ($action === 'bulk_delete' && isset($_POST['ids']) && is_array($_POST['ids'])) {
        $ids = array_map('intval', $_POST['ids']);
        if (!empty($ids)) {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            try {
                $stmt = $pdo->prepare("DELETE FROM `bug_reports` WHERE `id` IN ($placeholders)");
                $stmt->execute($ids);
                $success = '已删除 ' . count($ids) . ' 个bug';
            } catch (PDOException $e) {
                $error = '批量删除失败，请重试';
            }
        }
    }

    // 删除单个
    if ($action === 'delete' && isset($_POST['bug_id'])) {
        $bugId = intval($_POST['bug_id']);
        try {
            $stmt = $pdo->prepare("DELETE FROM `bug_reports` WHERE `id` = :id");
            $stmt->execute([':id' => $bugId]);
            $success = 'bug #' . $bugId . ' 已删除';
        } catch (PDOException $e) {
            $error = '删除失败';
        }
    }

    // 奖励积分
    if ($action === 'reward' && isset($_POST['bug_id'])) {
        $bugId = intval($_POST['bug_id']);
        $points = intval($_POST['points'] ?? 0);
        if ($points <= 0) {
            $error = '奖励积分必须大于0';
        } else {
            try {
                $stmt = $pdo->prepare("SELECT `reporter_name`, `points_awarded` FROM `bug_reports` WHERE `id` = :id");
                $stmt->execute([':id' => $bugId]);
                $bug = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$bug) {
                    $error = 'bug不存在';
                } elseif ($bug['points_awarded'] > 0) {
                    $error = '该bug已奖励过积分，不能重复奖励';
                } else {
                    $pdo->beginTransaction();
                    $stmt = $pdo->prepare("UPDATE `users` SET `points` = `points` + :points WHERE `name` = :reporter");
                    $stmt->execute([':points' => $points, ':reporter' => $bug['reporter_name']]);
                    $stmt = $pdo->prepare("UPDATE `bug_reports` SET `points_awarded` = :points WHERE `id` = :id");
                    $stmt->execute([':points' => $points, ':id' => $bugId]);
                    $pdo->commit();
                    $success = '已奖励 ' . $points . ' 积分给 ' . $bug['reporter_name'];
                }
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = '奖励失败，请稍后再试';
            }
        }
    }
}

$bugs = [];
try {
    $stmt = $pdo->query("SELECT `id`, `title`, `bug_type`, `severity`, `status`, `reporter_name`, `points_awarded`, `created_at` FROM `bug_reports` ORDER BY `created_at` DESC, `id` DESC");
    $bugs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '查询失败';
}

function statusText($status) {
    switch ($status) {
        case 'open': return '待处理';
        case 'confirmed': return '已确认';
        case 'resolved': return '已解决';
        case 'rejected': return '已拒绝';
        case 'rewarded': return '已奖励';
        default: return $status;
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理bug报告</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>管理bug报告</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
        <a href="bug_list.php" class="btn btn-secondary btn-sm">查看公开列表</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <?php if (empty($bugs)): ?>
        <p class="text-mute">暂无bug报告</p>
    <?php else: ?>
        <form method="post" action="admin_bugs.php" onsubmit="return confirm('确定删除选中的bug吗？');">
            <input type="hidden" name="action" value="bulk_delete">
            <p class="mb-10">
                <button type="submit" class="btn btn-danger btn-sm">批量删除选中</button>
            </p>
            <table>
                <tr>
                    <th style="width:40px;"><input type="checkbox" onclick="toggleAll(this)"></th>
                    <th style="width:70px;">编号</th>
                    <th>标题</th>
                    <th style="width:100px;">类型</th>
                    <th style="width:80px;">严重</th>
                    <th style="width:80px;">状态</th>
                    <th style="width:100px;">报告人</th>
                    <th style="width:80px;">奖励</th>
                    <th style="width:260px;">操作</th>
                </tr>
                <?php foreach ($bugs as $bug): ?>
                <tr>
                    <td><input type="checkbox" name="ids[]" value="<?php echo $bug['id']; ?>"></td>
                    <td>#<?php echo $bug['id']; ?></td>
                    <td><?php echo htmlspecialchars($bug['title']); ?></td>
                    <td><?php echo htmlspecialchars($bug['bug_type']); ?></td>
                    <td><?php echo htmlspecialchars($bug['severity']); ?></td>
                    <td><?php echo statusText($bug['status']); ?></td>
                    <td><?php echo htmlspecialchars($bug['reporter_name']); ?></td>
                    <td><?php echo $bug['points_awarded'] > 0 ? $bug['points_awarded'] : '-'; ?></td>
                    <td>
                        <a href="bug_view.php?id=<?php echo $bug['id']; ?>" class="btn btn-sm btn-outline">查看</a>
                        <a href="bug_edit.php?id=<?php echo $bug['id']; ?>" class="btn btn-sm">编辑</a>
                        <?php if ($bug['points_awarded'] == 0): ?>
                            <form method="post" action="admin_bugs.php" style="display:inline-block;" onsubmit="return confirm('确认属实并奖励积分？');">
                                <input type="hidden" name="action" value="reward">
                                <input type="hidden" name="bug_id" value="<?php echo $bug['id']; ?>">
                                <input type="number" name="points" min="1" placeholder="积分" required style="width:70px;padding:4px 8px;font-size:12px;">
                                <button type="submit" class="btn btn-sm btn-warning">奖励</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </form>
    <?php endif; ?>

    <script>
        function toggleAll(source) {
            var checkboxes = document.querySelectorAll('input[name="ids[]"]');
            checkboxes.forEach(function(cb) { cb.checked = source.checked; });
        }
    </script>
</body>
</html>