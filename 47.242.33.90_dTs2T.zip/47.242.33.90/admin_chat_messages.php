<?php
// =============================================
// 文件名：admin_chat_messages.php
// 用途：管理员聊天室消息管理（查看、编辑、批量删除、人工复议入口）
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

// 处理批量删除<?php
// =============================================
// 文件名：admin_chat_messages.php
// 用途：管理员聊天室消息管理（查看、编辑、批量删除、人工复议入口）
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

// 批量删除
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'bulk_delete') {
    $ids = $_POST['ids'] ?? [];
    if (!empty($ids)) {
        $ids = array_map('intval', $ids);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        try {
            $stmt = $pdo->prepare("DELETE FROM `chat_messages` WHERE `id` IN ($placeholders)");
            $stmt->execute($ids);
            $success = '已删除 ' . count($ids) . ' 条消息';
        } catch (PDOException $e) {
            $error = '删除失败，请重试';
        }
    }
}

// 删除单条
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    try {
        $stmt = $pdo->prepare("DELETE FROM `chat_messages` WHERE `id` = :id");
        $stmt->execute([':id' => $id]);
        $success = '消息已删除';
    } catch (PDOException $e) {
        $error = '删除失败';
    }
    header('Location: admin_chat_messages.php');
    exit;
}

$roomFilter = isset($_GET['room_id']) ? intval($_GET['room_id']) : 0;
$messages = [];
$rooms = [];

try {
    $rooms = $pdo->query("SELECT `id`, `name` FROM `chat_rooms` ORDER BY `id`")->fetchAll(PDO::FETCH_ASSOC);

    if ($roomFilter > 0) {
        $stmt = $pdo->prepare("SELECT cm.id, cm.room_id, cr.name AS room_name, cm.user_name, cm.content, cm.status, cm.created_at 
                               FROM `chat_messages` cm 
                               LEFT JOIN `chat_rooms` cr ON cm.room_id = cr.id 
                               WHERE cm.room_id = :room_id 
                               ORDER BY cm.created_at DESC");
        $stmt->execute([':room_id' => $roomFilter]);
    } else {
        $stmt = $pdo->query("SELECT cm.id, cm.room_id, cr.name AS room_name, cm.user_name, cm.content, cm.status, cm.created_at 
                             FROM `chat_messages` cm 
                             LEFT JOIN `chat_rooms` cr ON cm.room_id = cr.id 
                             ORDER BY cm.created_at DESC");
    }
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '查询失败';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>聊天室消息管理</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>聊天室消息管理</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
        <a href="admin_manual_review.php" class="btn btn-warning btn-sm">人工复议</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card">
        <form method="get" action="admin_chat_messages.php">
            <label style="display:block;margin-bottom:6px;font-size:13px;color:var(--text-light);">筛选聊天室：</label>
            <select name="room_id" onchange="this.form.submit()" style="max-width:300px;">
                <option value="0">全部</option>
                <?php foreach ($rooms as $room): ?>
                    <option value="<?php echo $room['id']; ?>" <?php echo $roomFilter == $room['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($room['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>

    <?php if (empty($messages)): ?>
        <p class="text-mute">暂无消息</p>
    <?php else: ?>
        <form method="post" action="admin_chat_messages.php" onsubmit="return confirm('确定删除选中的消息吗？');">
            <input type="hidden" name="action" value="bulk_delete">
            <p class="mb-10"><button type="submit" class="btn btn-danger btn-sm">批量删除选中</button></p>
            <table>
                <tr>
                    <th style="width:40px;"><input type="checkbox" onclick="toggleCheckboxes(this)"></th>
                    <th style="width:60px;">ID</th>
                    <th style="width:110px;">聊天室</th>
                    <th style="width:110px;">发送人</th>
                    <th>内容</th>
                    <th style="width:100px;">状态</th>
                    <th style="width:160px;">时间</th>
                    <th style="width:120px;">操作</th>
                </tr>
                <?php foreach ($messages as $msg): ?>
                <tr>
                    <td><input type="checkbox" name="ids[]" value="<?php echo $msg['id']; ?>"></td>
                    <td><?php echo $msg['id']; ?></td>
                    <td><?php echo htmlspecialchars($msg['room_name']); ?></td>
                    <td><?php echo htmlspecialchars($msg['user_name']); ?></td>
                    <td><?php echo htmlspecialchars($msg['content']); ?></td>
                    <td><?php echo htmlspecialchars($msg['status']); ?></td>
                    <td><?php echo htmlspecialchars($msg['created_at']); ?></td>
                    <td>
                        <a href="chat_message_edit.php?id=<?php echo $msg['id']; ?>" class="btn btn-sm">编辑</a>
                        <a href="admin_chat_messages.php?action=delete&id=<?php echo $msg['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定删除此消息？');">删除</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </form>
    <?php endif; ?>

    <script>
        function toggleCheckboxes(source) {
            var checkboxes = document.querySelectorAll('input[name="ids[]"]');
            checkboxes.forEach(function(cb) { cb.checked = source.checked; });
        }
    </script>
</body>
</html>
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'bulk_delete') {
    $ids = $_POST['ids'] ?? [];
    if (!empty($ids)) {
        $ids = array_map('intval', $ids);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        try {
            $stmt = $pdo->prepare("DELETE FROM `chat_messages` WHERE `id` IN ($placeholders)");
            $stmt->execute($ids);
            $success = '已删除 ' . count($ids) . ' 条消息';
        } catch (PDOException $e) {
            $error = '删除失败，请重试';
        }
    }
}

// 处理删除单条
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    try {
        $stmt = $pdo->prepare("DELETE FROM `chat_messages` WHERE `id` = :id");
        $stmt->execute([':id' => $id]);
        $success = '消息已删除';
    } catch (PDOException $e) {
        $error = '删除失败';
    }
    header('Location: admin_chat_messages.php');
    exit;
}

// 查询消息，按聊天室筛选
$roomFilter = isset($_GET['room_id']) ? intval($_GET['room_id']) : 0;
$messages = [];
$rooms = [];
try {
    $rooms = $pdo->query("SELECT `id`, `name` FROM `chat_rooms` ORDER BY `id`")->fetchAll(PDO::FETCH_ASSOC);

    if ($roomFilter > 0) {
        $stmt = $pdo->prepare("SELECT cm.id, cm.room_id, cr.name AS room_name, cm.user_name, cm.content, cm.status, cm.created_at 
                               FROM `chat_messages` cm 
                               LEFT JOIN `chat_rooms` cr ON cm.room_id = cr.id 
                               WHERE cm.room_id = :room_id 
                               ORDER BY cm.created_at DESC");
        $stmt->execute([':room_id' => $roomFilter]);
    } else {
        $stmt = $pdo->query("SELECT cm.id, cm.room_id, cr.name AS room_name, cm.user_name, cm.content, cm.status, cm.created_at 
                             FROM `chat_messages` cm 
                             LEFT JOIN `chat_rooms` cr ON cm.room_id = cr.id 
                             ORDER BY cm.created_at DESC");
    }
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '查询失败';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>聊天室消息管理</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        h1 { border-bottom: 1px solid #ddd; padding-bottom: 10px; }
        table { border-collapse: collapse; width: 100%; margin-top: 15px; }
        th, td { border: 1px solid #ccc; padding: 6px 10px; text-align: left; }
        th { background: #f5f5f5; }
        .error { color: red; } .success { color: green; }
        a { color: blue; text-decoration: none; margin-right: 10px; }
        a:hover { text-decoration: underline; }
        form { display: inline; }
        .admin-nav { margin-bottom: 15px; }
        .admin-nav a { margin-right: 15px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>聊天室消息管理</h1>
    <div class="admin-nav">
        <a href="admin_index.php">返回后台首页</a>
        <a href="admin_manual_review.php">【人工复议】</a>
    </div>
    <hr>
    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <form method="get" action="admin_chat_messages.php">
        <label>筛选聊天室：</label>
        <select name="room_id" onchange="this.form.submit()">
            <option value="0">全部</option>
            <?php foreach ($rooms as $room): ?>
                <option value="<?php echo $room['id']; ?>" <?php echo $roomFilter == $room['id'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($room['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>

    <?php if (empty($messages)): ?>
        <p>暂无消息</p>
    <?php else: ?>
        <form method="post" action="admin_chat_messages.php" onsubmit="return confirm('确定删除选中的消息吗？');">
            <input type="hidden" name="action" value="bulk_delete">
            <table>
                <tr>
                    <th><input type="checkbox" onclick="toggleCheckboxes(this)"></th>
                    <th>ID</th>
                    <th>聊天室</th>
                    <th>发送人</th>
                    <th>内容</th>
                    <th>状态</th>
                    <th>时间</th>
                    <th>操作</th>
                </tr>
                <?php foreach ($messages as $msg): ?>
                <tr>
                    <td><input type="checkbox" name="ids[]" value="<?php echo $msg['id']; ?>"></td>
                    <td><?php echo $msg['id']; ?></td>
                    <td><?php echo htmlspecialchars($msg['room_name']); ?></td>
                    <td><?php echo htmlspecialchars($msg['user_name']); ?></td>
                    <td><?php echo htmlspecialchars($msg['content']); ?></td>
                    <td><?php echo htmlspecialchars($msg['status']); ?></td>
                    <td><?php echo htmlspecialchars($msg['created_at']); ?></td>
                    <td>
                        <a href="chat_message_edit.php?id=<?php echo $msg['id']; ?>">编辑</a>
                        <a href="admin_chat_messages.php?action=delete&id=<?php echo $msg['id']; ?>" onclick="return confirm('确定删除此消息？');">删除</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <br>
            <button type="submit">批量删除选中</button>
        </form>
    <?php endif; ?>

    <script>
        function toggleCheckboxes(source) {
            var checkboxes = document.querySelectorAll('input[name="ids[]"]');
            checkboxes.forEach(function(cb) { cb.checked = source.checked; });
        }
    </script>
</body>
</html>