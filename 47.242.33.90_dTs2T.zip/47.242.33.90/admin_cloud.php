<?php
// =============================================
// 文件名：admin_cloud.php
// 用途：管理员云盘管理（跨用户/跨空间）
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';
require_once 'config_oss.php';

$view     = $_GET['view'] ?? 'public';
$userId   = intval($_GET['user_id'] ?? 0);
$folderId = intval($_GET['folder'] ?? 0);

// 用户列表
$users = $pdo->query("
    SELECT u.id, u.name,
        (SELECT COUNT(*) FROM cloud_files WHERE user_id = u.id AND is_folder = 0 AND is_public = 0) AS file_count,
        (SELECT COALESCE(SUM(file_size),0) FROM cloud_files WHERE user_id = u.id AND is_folder = 0 AND is_public = 0) AS total_size
    FROM users u ORDER BY u.id ASC
")->fetchAll(PDO::FETCH_ASSOC);

$publicStats = $pdo->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(file_size),0) AS total FROM cloud_files WHERE is_folder = 0 AND is_public = 1")->fetch(PDO::FETCH_ASSOC);
$privateStats = $pdo->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(file_size),0) AS total FROM cloud_files WHERE is_folder = 0 AND is_public = 0")->fetch(PDO::FETCH_ASSOC);

$currentUser = null;
if ($view === 'user' && $userId > 0) {
    $stmt = $pdo->prepare("SELECT id, name FROM users WHERE id = :id");
    $stmt->execute([':id' => $userId]);
    $currentUser = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$currentUser) $view = 'public';
}

$viewLabel = ($view === 'public') ? '公共空间' : ($currentUser ? $currentUser['name'] . ' 的私人空间' : '私人空间');

// 面包屑
$breadcrumb = [];
if ($folderId > 0) {
    $id = $folderId;
    $guard = 0;
    while ($id > 0 && $guard++ < 50) {
        $stmt = $pdo->prepare("SELECT id, original_name, parent_id FROM cloud_files WHERE id = :id AND is_folder = 1");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) break;
        array_unshift($breadcrumb, $row);
        $id = $row['parent_id'];
    }
}

// 文件列表
if ($view === 'public') {
    $stmt = $pdo->prepare("SELECT id, user_id, user_name, original_name, file_size, is_folder, is_public, created_at FROM cloud_files WHERE parent_id = :pid AND is_public = 1 ORDER BY is_folder DESC, id DESC LIMIT 500");
    $stmt->execute([':pid' => $folderId]);
} else {
    $stmt = $pdo->prepare("SELECT id, user_id, user_name, original_name, file_size, is_folder, is_public, created_at FROM cloud_files WHERE parent_id = :pid AND user_id = :uid AND is_public = 0 ORDER BY is_folder DESC, id DESC LIMIT 500");
    $stmt->execute([':pid' => $folderId, ':uid' => $userId]);
}
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 全部文件夹
function collectAllFolders($pdo, $pid = 0, $prefix = '') {
    $result = [];
    $stmt = $pdo->prepare("SELECT id, original_name, user_id, user_name, is_public FROM cloud_files WHERE is_folder = 1 AND parent_id = :pid ORDER BY is_public DESC, user_id ASC, id ASC");
    $stmt->execute([':pid' => $pid]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $tag = $row['is_public'] ? '[公共]' : '[' . $row['user_name'] . ']';
        $result[] = ['id' => $row['id'], 'label' => $prefix . $row['original_name'] . ' ' . $tag];
        $result = array_merge($result, collectAllFolders($pdo, $row['id'], $prefix . '　'));
    }
    return $result;
}
$allFolders = collectAllFolders($pdo);

function formatBytes($bytes, $precision = 2) {
    if ($bytes <= 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    $i = floor(log($bytes, 1024));
    if ($i >= count($units)) $i = count($units) - 1;
    return round($bytes / pow(1024, $i), $precision) . ' ' . $units[$i];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>云盘管理</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .top-tabs {
            display: flex; align-items: center; gap: 12px;
            background: #fff; border: 1px solid var(--border); border-radius: var(--radius);
            padding: 10px 14px; margin-bottom: 18px; flex-wrap: wrap;
        }
        .top-tabs select {
            padding: 8px 12px; border-radius: 8px;
            max-width: 400px; flex: 1; min-width: 200px;
        }
        .top-tabs .spacer { flex: 1; }
        .stat-bar {
            display: flex; gap: 24px; flex-wrap: wrap;
            background: #fff; border: 1px solid var(--border); border-radius: var(--radius);
            padding: 14px 20px; margin-bottom: 18px;
        }
        .stat-bar .item { display: flex; flex-direction: column; gap: 2px; }
        .stat-bar .item .label { font-size: 12px; color: var(--text-mute); }
        .stat-bar .item .value { font-size: 16px; font-weight: 700; color: var(--accent); font-family: "SF Mono", Consolas, monospace; }

        .modal-mask {
            display: none; position: fixed; inset: 0; background: rgba(15,23,42,.5);
            z-index: 1000; align-items: center; justify-content: center;
        }
        .modal-mask.show { display: flex; }
        .modal {
            background: #fff; border-radius: 14px; padding: 24px 28px;
            width: 480px; max-width: calc(100vw - 40px);
            box-shadow: 0 20px 60px rgba(15,23,42,.3);
        }
        .modal h3 { margin: 0 0 14px; }
        .modal select { max-height: 300px; }
        .modal .actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>云盘管理</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
    </p>

    <div class="stat-bar">
        <div class="item"><span class="label">公共空间文件</span><span class="value"><?php echo (int)$publicStats['cnt']; ?> 个 / <?php echo formatBytes($publicStats['total']); ?></span></div>
        <div class="item"><span class="label">私人空间文件</span><span class="value"><?php echo (int)$privateStats['cnt']; ?> 个 / <?php echo formatBytes($privateStats['total']); ?></span></div>
        <div class="item"><span class="label">云盘总量</span><span class="value"><?php echo formatBytes($publicStats['total'] + $privateStats['total']); ?></span></div>
    </div>

    <div class="top-tabs">
        <a href="admin_cloud.php?view=public" class="btn btn-sm <?php echo $view === 'public' ? '' : 'btn-outline'; ?>">🌐 公共空间</a>
        <select onchange="switchUser(this.value)">
            <option value="">— 选择用户查看私人空间 —</option>
            <?php foreach ($users as $u): ?>
                <option value="<?php echo $u['id']; ?>" <?php echo ($view === 'user' && $userId == $u['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($u['name']); ?>（<?php echo (int)$u['file_count']; ?> 文件，<?php echo formatBytes($u['total_size']); ?>）
                </option>
            <?php endforeach; ?>
        </select>
        <span class="spacer"></span>
        <span class="text-mute">当前：<?php echo htmlspecialchars($viewLabel); ?></span>
    </div>

    <div class="card">
        <div style="font-size:14px;">
            <a href="admin_cloud.php?view=<?php echo $view; ?><?php echo $view === 'user' ? '&user_id=' . $userId : ''; ?>" class="btn btn-sm btn-outline"><?php echo htmlspecialchars($viewLabel); ?></a>
            <?php foreach ($breadcrumb as $b): ?>
                <span style="color:#cbd3df;margin:0 6px;">/</span>
                <a href="admin_cloud.php?view=<?php echo $view; ?><?php echo $view === 'user' ? '&user_id=' . $userId : ''; ?>&folder=<?php echo $b['id']; ?>" class="btn btn-sm btn-outline"><?php echo htmlspecialchars($b['original_name']); ?></a>
            <?php endforeach; ?>
            <?php if ($folderId > 0): ?>
                <span style="color:#cbd3df;margin:0 6px;">/</span>
                <span class="text-mute">当前目录</span>
            <?php endif; ?>
        </div>
    </div>

    <div class="card" style="padding:0;overflow:hidden;">
        <?php if (empty($items)): ?>
            <div style="padding:40px;text-align:center;color:var(--text-mute);">当前目录为空</div>
        <?php else: ?>
            <table>
                <tr>
                    <th style="width:35%;">名称</th>
                    <th style="width:10%;">大小</th>
                    <th style="width:12%;">所有者</th>
                    <th style="width:10%;">类型</th>
                    <th style="width:14%;">时间</th>
                    <th>操作</th>
                </tr>
                <?php foreach ($items as $it): ?>
                    <tr>
                        <td>
                            <?php if ($it['is_folder']): ?>
                                <a href="admin_cloud.php?view=<?php echo $view; ?><?php echo $view === 'user' ? '&user_id=' . $userId : ''; ?>&folder=<?php echo $it['id']; ?>" style="display:flex;align-items:center;gap:8px;font-weight:600;">
                                    📁 <?php echo htmlspecialchars($it['original_name']); ?>
                                </a>
                            <?php else: ?>
                                <span style="display:flex;align-items:center;gap:8px;">
                                    📄 <?php echo htmlspecialchars($it['original_name']); ?>
                                </span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $it['is_folder'] ? '-' : formatBytes($it['file_size']); ?></td>
                        <td><span class="badge badge-owner"><?php echo htmlspecialchars($it['user_name']); ?></span></td>
                        <td>
                            <?php if ($it['is_folder']): ?>
                                <span class="badge badge-folder">文件夹</span>
                            <?php elseif ($it['is_public']): ?>
                                <span class="badge badge-public">公共</span>
                            <?php else: ?>
                                <span class="badge badge-private">私人</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($it['created_at']); ?></td>
                        <td>
                            <?php if (!$it['is_folder']): ?>
                                <a class="btn btn-sm btn-success" href="cloud_download.php?id=<?php echo $it['id']; ?>">下载</a>
                            <?php endif; ?>
                            <button class="btn btn-sm btn-warning" onclick="togglePublic(<?php echo $it['id']; ?>, <?php echo $it['is_public']; ?>, <?php echo $it['is_folder']; ?>)">
                                <?php echo $it['is_public'] ? '转私人' : '转公共'; ?>
                            </button>
                            <button class="btn btn-sm" onclick="moveItem(<?php echo $it['id']; ?>, '<?php echo htmlspecialchars(addslashes($it['original_name'])); ?>', <?php echo $it['is_folder']; ?>)">移动</button>
                            <button class="btn btn-sm btn-purple" onclick="renameItem(<?php echo $it['id']; ?>, '<?php echo htmlspecialchars(addslashes($it['original_name'])); ?>')">重命名</button>
                            <button class="btn btn-sm btn-danger" onclick="deleteItem(<?php echo $it['id']; ?>, <?php echo $it['is_folder']; ?>)">删除</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>

    <div class="modal-mask" id="moveModal">
        <div class="modal">
            <h3>移动文件 / 文件夹</h3>
            <p class="text-mute" id="moveItemName" style="margin:0 0 12px;"></p>
            <select id="moveTarget">
                <option value="0">— 根目录 —</option>
                <?php foreach ($allFolders as $f): ?>
                    <option value="<?php echo $f['id']; ?>"><?php echo htmlspecialchars($f['label']); ?></option>
                <?php endforeach; ?>
            </select>
            <div class="actions">
                <button class="btn btn-secondary" onclick="closeMoveModal()">取消</button>
                <button class="btn" onclick="confirmMove()">确认移动</button>
            </div>
        </div>
    </div>

<script>
var moveId = 0;

function switchUser(uid) {
    if (!uid) location.href = 'admin_cloud.php?view=public';
    else location.href = 'admin_cloud.php?view=user&user_id=' + uid;
}

function post(url, data) {
    var body = new URLSearchParams(data).toString();
    return fetch(url, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: body
    }).then(function(r) { return r.json(); });
}

function togglePublic(id, isPublic, isFolder) {
    var msg = isPublic
        ? (isFolder ? '确定将该文件夹及内部所有内容转为私人？' : '确定将该文件转为私人？')
        : (isFolder ? '确定将该文件夹及内部所有内容转为公共？' : '确定将该文件转为公共？');
    if (!confirm(msg)) return;
    post('admin_cloud_action.php', { action: 'toggle_public', id: id }).then(function(res){
        if (res.code === 0) location.reload(); else alert(res.message);
    });
}

function moveItem(id, name, isFolder) {
    moveId = id;
    document.getElementById('moveItemName').textContent = (isFolder ? '📁 ' : '📄 ') + name;
    document.getElementById('moveTarget').value = '0';
    document.getElementById('moveModal').classList.add('show');
}

function closeMoveModal() {
    document.getElementById('moveModal').classList.remove('show');
    moveId = 0;
}

function confirmMove() {
    var target = document.getElementById('moveTarget').value;
    if (moveId <= 0) return;
    post('admin_cloud_action.php', { action: 'move', id: moveId, target_folder_id: target }).then(function(res){
        if (res.code === 0) { closeMoveModal(); location.reload(); }
        else alert(res.message);
    });
}

function renameItem(id, oldName) {
    var newName = prompt('请输入新名称：', oldName);
    if (!newName || newName === oldName) return;
    post('admin_cloud_action.php', { action: 'rename', id: id, name: newName }).then(function(res){
        if (res.code === 0) location.reload(); else alert(res.message);
    });
}

function deleteItem(id, isFolder) {
    var msg = isFolder ? '确定删除该文件夹及里面所有内容？' : '确定删除该文件？';
    if (!confirm(msg)) return;
    post('admin_cloud_action.php', { action: 'delete', id: id }).then(function(res){
        if (res.code === 0) location.reload(); else alert(res.message);
    });
}
</script>
</body>
</html>