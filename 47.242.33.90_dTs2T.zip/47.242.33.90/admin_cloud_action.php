<?php
// =============================================
// 文件名：admin_cloud_action.php
// 用途：管理员云盘操作接口
// =============================================
session_start();
header('Content-Type: application/json; charset=utf-8');
if (!isset($_SESSION['admin'])) {
    echo json_encode(['code' => 401, 'message' => '未登录']);
    exit;
}
require_once 'config.php';
require_once 'config_oss.php';

use OSS\Core\OssException;

function json_out($code, $msg, $data = null) {
    while (ob_get_level()) @ob_end_clean();
    echo json_encode(['code' => $code, 'message' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';
try {
    $ossClient = getOssClient();
    $bucket    = getBucketName();
} catch (Exception $e) {
    json_out(500, 'OSS 初始化失败：' . $e->getMessage());
}

switch ($action) {

case 'move':
    $id             = intval($_POST['id'] ?? 0);
    $targetFolderId = intval($_POST['target_folder_id'] ?? 0);

    if ($id <= 0) json_out(400, '参数错误');
    if ($id == $targetFolderId) json_out(400, '不能移动到自身');

    $stmt = $pdo->prepare("SELECT id, user_id, is_folder, is_public FROM cloud_files WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$item) json_out(404, '不存在');

    if ($targetFolderId > 0) {
        $stmt = $pdo->prepare("SELECT id, user_id, is_public FROM cloud_files WHERE id = :id AND is_folder = 1");
        $stmt->execute([':id' => $targetFolderId]);
        $target = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$target) json_out(404, '目标文件夹不存在');

        if ($item['is_folder'] && isDescendant($pdo, $targetFolderId, $id)) {
            json_out(400, '不能移动到自己的子文件夹');
        }

        $newUserId   = $target['user_id'];
        $newIsPublic = $target['is_public'];
    } else {
        $newUserId   = $item['user_id'];
        $newIsPublic = $item['is_public'];
    }

    try {
        $pdo->beginTransaction();
        $pdo->prepare("UPDATE cloud_files SET parent_id = :pid, user_id = :uid, is_public = :ip WHERE id = :id")
            ->execute([':pid' => $targetFolderId, ':uid' => $newUserId, ':ip' => $newIsPublic, ':id' => $id]);
        if ($item['is_folder']) {
            updateFolderOwnership($pdo, $id, $newUserId, $newIsPublic);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        json_out(500, '移动失败：' . $e->getMessage());
    }
    json_out(0, '移动成功');
    break;

case 'delete':
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) json_out(400, '参数错误');

    $stmt = $pdo->prepare("SELECT id, is_folder, stored_path FROM cloud_files WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$item) json_out(404, '不存在');

    if ($item['is_folder']) {
        deleteFolderRecursive($pdo, $ossClient, $bucket, $id);
    } else {
        if (!empty($item['stored_path'])) {
            try { $ossClient->deleteObject($bucket, $item['stored_path']); } catch (Exception $e) {}
        }
        $pdo->prepare("DELETE FROM cloud_files WHERE id = :id")->execute([':id' => $id]);
    }
    json_out(0, '删除成功');
    break;

case 'toggle_public':
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) json_out(400, '参数错误');

    $stmt = $pdo->prepare("SELECT is_public, is_folder FROM cloud_files WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$item) json_out(404, '不存在');

    $newVal = $item['is_public'] ? 0 : 1;

    try {
        $pdo->beginTransaction();
        $pdo->prepare("UPDATE cloud_files SET is_public = :ip WHERE id = :id")
            ->execute([':ip' => $newVal, ':id' => $id]);
        if ($item['is_folder']) {
            togglePublicRecursive($pdo, $id, $newVal);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        json_out(500, '操作失败');
    }
    json_out(0, '已更新', ['is_public' => $newVal]);
    break;

case 'rename':
    $id   = intval($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    if ($id <= 0 || $name === '' || mb_strlen($name) > 200) json_out(400, '参数错误');
    if (strpos($name, '/') !== false) json_out(400, '名称不能包含 /');

    $pdo->prepare("UPDATE cloud_files SET original_name = :n WHERE id = :id")
        ->execute([':n' => $name, ':id' => $id]);
    json_out(0, '已重命名');
    break;

default:
    json_out(400, '未知操作：' . $action);
}

function isDescendant($pdo, $childId, $ancestorId) {
    $id = $childId;
    $guard = 0;
    while ($id > 0 && $guard++ < 100) {
        if ($id == $ancestorId) return true;
        $stmt = $pdo->prepare("SELECT parent_id FROM cloud_files WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) break;
        $id = intval($row['parent_id']);
    }
    return false;
}

function updateFolderOwnership($pdo, $folderId, $newUserId, $newIsPublic) {
    $stmt = $pdo->prepare("SELECT id, is_folder FROM cloud_files WHERE parent_id = :pid");
    $stmt->execute([':pid' => $folderId]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $child) {
        $pdo->prepare("UPDATE cloud_files SET user_id = :uid, is_public = :ip WHERE id = :id")
            ->execute([':uid' => $newUserId, ':ip' => $newIsPublic, ':id' => $child['id']]);
        if ($child['is_folder']) {
            updateFolderOwnership($pdo, $child['id'], $newUserId, $newIsPublic);
        }
    }
}

function deleteFolderRecursive($pdo, $ossClient, $bucket, $folderId) {
    $stmt = $pdo->prepare("SELECT id, is_folder, stored_path FROM cloud_files WHERE parent_id = :pid");
    $stmt->execute([':pid' => $folderId]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $child) {
        if ($child['is_folder']) {
            deleteFolderRecursive($pdo, $ossClient, $bucket, $child['id']);
        } else {
            if (!empty($child['stored_path'])) {
                try { $ossClient->deleteObject($bucket, $child['stored_path']); } catch (Exception $e) {}
            }
        }
        $pdo->prepare("DELETE FROM cloud_files WHERE id = :id")->execute([':id' => $child['id']]);
    }
    $pdo->prepare("DELETE FROM cloud_files WHERE id = :id")->execute([':id' => $folderId]);
}

function togglePublicRecursive($pdo, $folderId, $newVal) {
    $stmt = $pdo->prepare("SELECT id, is_folder FROM cloud_files WHERE parent_id = :pid");
    $stmt->execute([':pid' => $folderId]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $child) {
        $pdo->prepare("UPDATE cloud_files SET is_public = :ip WHERE id = :id")
            ->execute([':ip' => $newVal, ':id' => $child['id']]);
        if ($child['is_folder']) {
            togglePublicRecursive($pdo, $child['id'], $newVal);
        }
    }
}