<?php
// =============================================
// 文件名：admin_favicon.php
// 用途：管理员上传网站图标
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

$currentFavicon = '';
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'site_favicon' LIMIT 1");
    $currentFavicon = $stmt->fetchColumn();
    if ($currentFavicon === false) $currentFavicon = '';
} catch (PDOException $e) {
    $error = '读取设置失败';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['favicon_file'])) {
    $file = $_FILES['favicon_file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = '上传失败，请重试';
    } else {
        $maxSize = 2 * 1024 * 1024;
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if ($ext === 'ico') {
            if ($file['size'] > $maxSize) {
                $error = '图标大小不能超过 2MB';
            } else {
                $targetPath = __DIR__ . '/favicon.ico';
                if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                    $oldPng = __DIR__ . '/favicon.png';
                    if (file_exists($oldPng)) @unlink($oldPng);
                    $faviconUrl = 'favicon.ico';
                    try {
                        $stmt = $pdo->prepare("UPDATE `settings` SET `setting_value` = :value WHERE `setting_key` = 'site_favicon'");
                        $stmt->execute([':value' => $faviconUrl]);
                        $currentFavicon = $faviconUrl;
                        $success = '网站图标已更新（favicon.ico）';
                    } catch (PDOException $e) {
                        $error = '数据库更新失败，请重试';
                        @unlink($targetPath);
                    }
                } else {
                    $error = '文件保存失败，请检查根目录写入权限';
                }
            }
        } else {
            $imageInfo = @getimagesize($file['tmp_name']);
            if ($imageInfo === false) {
                $error = '文件不是有效图片（仅支持 PNG/JPG/GIF/WEBP/ICO）';
            } elseif ($file['size'] > $maxSize) {
                $error = '图标大小不能超过 2MB';
            } else {
                $mime = $imageInfo['mime'];
                $allowedMimes = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
                if (!in_array($mime, $allowedMimes)) {
                    $error = '只允许上传 PNG/JPG/GIF/WEBP/ICO 格式的图片';
                } else {
                    $sourceImage = null;
                    switch ($mime) {
                        case 'image/jpeg': $sourceImage = @imagecreatefromjpeg($file['tmp_name']); break;
                        case 'image/gif': $sourceImage = @imagecreatefromgif($file['tmp_name']); break;
                        case 'image/png': $sourceImage = @imagecreatefrompng($file['tmp_name']); break;
                        case 'image/webp':
                            if (function_exists('imagecreatefromwebp')) $sourceImage = @imagecreatefromwebp($file['tmp_name']);
                            break;
                    }

                    if (!$sourceImage) {
                        $error = '图片加载失败，请更换图片';
                    } else {
                        $targetPath = __DIR__ . '/favicon.png';
                        $oldIco = __DIR__ . '/favicon.ico';
                        if (file_exists($oldIco)) @unlink($oldIco);

                        if (imagepng($sourceImage, $targetPath, 9)) {
                            imagedestroy($sourceImage);
                            $faviconUrl = 'favicon.png';
                            try {
                                $stmt = $pdo->prepare("UPDATE `settings` SET `setting_value` = :value WHERE `setting_key` = 'site_favicon'");
                                $stmt->execute([':value' => $faviconUrl]);
                                $currentFavicon = $faviconUrl;
                                $success = '网站图标已更新（favicon.png）';
                            } catch (PDOException $e) {
                                $error = '数据库更新失败，请重试';
                                @unlink($targetPath);
                            }
                        } else {
                            imagedestroy($sourceImage);
                            $error = '图片保存失败，请检查根目录写入权限';
                        }
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>网站图标管理</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .favicon-preview { width: 48px; height: 48px; vertical-align: middle; border-radius: 8px; border: 1px solid var(--border); }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>网站图标管理</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:600px;">
        <h2>当前网站图标</h2>
        <?php if ($currentFavicon): ?>
            <p>
                <img src="<?php echo htmlspecialchars($currentFavicon); ?>" class="favicon-preview" alt="当前图标">
                <span class="text-mute" style="margin-left:10px;">路径：<?php echo htmlspecialchars($currentFavicon); ?></span>
            </p>
        <?php else: ?>
            <p class="text-mute">未设置图标</p>
        <?php endif; ?>
    </div>

    <div class="card" style="max-width:600px;">
        <h2>上传新图标</h2>
        <form method="post" action="admin_favicon.php" enctype="multipart/form-data">
            <p class="mb-10">
                <label style="font-size:13px;color:var(--text-light);">选择图标文件（推荐 ICO 或带背景色的 PNG，不超过 2MB）</label>
            </p>
            <input type="file" name="favicon_file" accept=".ico,image/png,image/jpeg,image/gif,image/webp" required>
            <p class="mt-20"><button type="submit" class="btn">上传并应用</button></p>
        </form>
        <p class="text-mute mt-10">上传 ICO 文件直接保存为根目录 favicon.ico；上传 PNG/JPG/GIF/WEBP 将转换为根目录 favicon.png。移动端建议使用 ICO 或不透明背景的 PNG。</p>
    </div>
</body>
</html>