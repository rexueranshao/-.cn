<?php
// =============================================
// 文件名：admin_footer.php
// 用途：管理员编辑网站页脚署名文字（支持HTML）
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

$currentFooter = '';
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'site_footer' LIMIT 1");
    $currentFooter = $stmt->fetchColumn();
    if ($currentFooter === false) $currentFooter = '';
} catch (PDOException $e) {
    $error = '读取设置失败';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['footer_content'])) {
    $content = $_POST['footer_content'];
    try {
        $stmt = $pdo->prepare("UPDATE `settings` SET `setting_value` = :value WHERE `setting_key` = 'site_footer'");
        $stmt->execute([':value' => $content]);
        $currentFooter = $content;
        $success = '页脚内容已更新';
    } catch (PDOException $e) {
        $error = '保存失败，请重试';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>页脚设置</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>页脚署名设置</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:800px;">
        <h2>当前页脚内容</h2>
        <?php if ($currentFooter): ?>
            <div style="border:1px dashed var(--border);padding:12px;border-radius:8px;background:#fafbfc;">
                <?php echo $currentFooter; ?>
            </div>
        <?php else: ?>
            <p class="text-mute">暂无内容</p>
        <?php endif; ?>
    </div>

    <div class="card" style="max-width:800px;">
        <h2>编辑页脚内容（支持 HTML 代码）</h2>
        <form method="post" action="admin_footer.php">
            <textarea name="footer_content" rows="8" placeholder="请输入HTML内容，例如：© 2025 我的网站 | 技术支持：DS"><?php echo htmlspecialchars($currentFooter); ?></textarea>
            <p class="mt-20"><button type="submit" class="btn">保存页脚</button></p>
        </form>
        <p class="text-mute mt-10">注意：此处内容将直接输出到用户首页底部，支持HTML标签，请自行确保代码安全。</p>
    </div>
</body>
</html>