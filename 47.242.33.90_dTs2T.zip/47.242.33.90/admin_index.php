<?php
// =============================================
// 文件名：admin_index.php
// 用途：管理员后台首页
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

// 处理报名功能开关更新
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['program_signup_enabled'])) {
    $enabled = $_POST['program_signup_enabled'] === '1' ? '1' : '0';
    try {
        $stmt = $pdo->prepare("UPDATE `settings` SET `setting_value` = :value WHERE `setting_key` = 'program_signup_enabled'");
        $stmt->execute([':value' => $enabled]);
    } catch (PDOException $e) {}
    header('Location: admin_index.php');
    exit;
}

// 查询当前开关状态
$programSignupEnabled = '1';
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'program_signup_enabled' LIMIT 1");
    $val = $stmt->fetchColumn();
    if ($val !== false) $programSignupEnabled = $val;
} catch (PDOException $e) {}

// 统计数据
$stats = ['total_count' => 0, 'total_duration' => 0, 'type_stats' => [], 'props_list' => []];
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM `program_registrations`");
    $stats['total_count'] = (int)$stmt->fetchColumn();

    $stmt = $pdo->query("SELECT `duration` FROM `program_registrations` WHERE `duration` IS NOT NULL AND `duration` != ''");
    $durations = $stmt->fetchAll(PDO::FETCH_COLUMN);
    function parseDuration($text) {
        preg_match_all('/\d+(?:\.\d+)?/', $text, $matches);
        if (empty($matches[0])) return 0;
        $nums = $matches[0];
        if (count($nums) >= 2 && strpos($text, '-') !== false) return (floatval($nums[0]) + floatval($nums[1])) / 2;
        return floatval($nums[0]);
    }
    foreach ($durations as $d) $stats['total_duration'] += parseDuration($d);

    $stmt = $pdo->query("SELECT `program_type`, COUNT(*) AS cnt FROM `program_registrations` GROUP BY `program_type` ORDER BY cnt DESC");
    $stats['type_stats'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT `props` FROM `program_registrations` WHERE `props` IS NOT NULL AND `props` != '' ORDER BY `id` DESC");
    $stats['props_list'] = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员首页</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>欢迎您，管理员：<?php echo htmlspecialchars($_SESSION['admin'], ENT_QUOTES, 'UTF-8'); ?></h1>
    <p class="page-nav">
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <div class="card">
        <h2>节目数据统计</h2>
        <p>节目总报名条数：<?php echo $stats['total_count']; ?></p>
        <p>全部节目预估时长相加的总时长：<?php echo $stats['total_duration']; ?> 分钟</p>
        <h3>按节目类型统计</h3>
        <?php if (empty($stats['type_stats'])): ?>
            <p class="text-mute">暂无类型数据</p>
        <?php else: ?>
            <ul>
                <?php foreach ($stats['type_stats'] as $type): 
                    $percent = ($stats['total_count'] > 0) ? round(($type['cnt'] / $stats['total_count']) * 100, 1) : 0;
                ?>
                    <li><?php echo htmlspecialchars($type['program_type']); ?>：<?php echo $type['cnt']; ?> 个（占比 <?php echo $percent; ?>%）</li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
        <h3>道具需求汇总</h3>
        <?php if (empty($stats['props_list'])): ?>
            <p class="text-mute">暂无道具需求</p>
        <?php else: ?>
            <ul>
                <?php foreach ($stats['props_list'] as $prop): ?>
                    <li><?php echo htmlspecialchars($prop); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2>元旦晚会报名功能开关</h2>
        <form method="post" action="admin_index.php">
            <label style="display:block;margin-bottom:8px;">
                <input type="radio" name="program_signup_enabled" value="1" <?php echo $programSignupEnabled === '1' ? 'checked' : ''; ?>>
                开启（仅"同学"组普通用户可见）
            </label>
            <label style="display:block;margin-bottom:12px;">
                <input type="radio" name="program_signup_enabled" value="0" <?php echo $programSignupEnabled !== '1' ? 'checked' : ''; ?>>
                关闭（所有普通用户不可见）
            </label>
            <button type="submit" class="btn">保存开关</button>
        </form>
    </div>

    <div class="card">
        <h2>管理入口</h2>
        <p class="flex">
            <a href="program_signup.php" class="btn btn-sm">新增节目报名</a>
            <a href="program_list.php" class="btn btn-sm">查看节目列表</a>
            <a href="user_manage.php" class="btn btn-sm">用户管理</a>
            <a href="group_manage.php" class="btn btn-sm">用户组管理</a>
            <a href="admin_messages.php" class="btn btn-sm">留言管理</a>
            <a href="admin_announcement.php" class="btn btn-sm">修改公告</a>
            <a href="forum.php" class="btn btn-sm">论坛管理</a>
            <a href="admin_invite.php" class="btn btn-sm">邀请码管理</a>
            <a href="admin_bugs.php" class="btn btn-sm">bug管理</a>
            <a href="admin_chat_messages.php" class="btn btn-sm">聊天室消息管理</a>
            <a href="admin_favicon.php" class="btn btn-sm">网站图标</a>
            <a href="admin_footer.php" class="btn btn-sm">页脚设置</a>
            <a href="admin_login_bg.php" class="btn btn-sm">登录页背景</a>
            <a href="admin_mc_servers.php" class="btn btn-sm">MC服务器管理</a>
            <a href="admin_mc_permission.php" class="btn btn-sm">MC板块权限</a>
            <a href="admin_reports.php" class="btn btn-sm">举报管理</a>
            <a href="admin_ai_settings.php" class="btn btn-sm">AI审核设置</a>
            <a href="admin_manual_review.php" class="btn btn-sm">人工复议</a>
            <a href="admin_cloud.php" class="btn btn-sm">云盘管理</a>
        </p>
    </div>
</body>
</html>