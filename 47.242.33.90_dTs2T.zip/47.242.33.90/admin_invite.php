<?php
// =============================================
// 文件名：admin_invite.php
// 用途：管理员邀请码管理（生成、查看、删除）
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

// 生成邀请码
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'generate') {
    $maxUses = intval($_POST['max_uses'] ?? 1);
    if ($maxUses <= 0) {
        $error = '使用次数必须大于0';
    } else {
        $code = strtoupper(bin2hex(random_bytes(8)));
        try {
            $stmt = $pdo->prepare("INSERT INTO `invite_codes` (`code`, `max_uses`) VALUES (:code, :max_uses)");
            $stmt->execute([':code' => $code, ':max_uses' => $maxUses]);
            $success = '邀请码生成成功：' . $code;
        } catch (PDOException $e) {
            $error = '生成失败，请重试';
        }
    }
}

// 删除邀请码
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($id > 0) {
        try {
            $stmt = $pdo->prepare("DELETE FROM `invite_codes` WHERE `id` = :id");
            $stmt->execute([':id' => $id]);
            $success = '邀请码已删除';
        } catch (PDOException $e) {
            $error = '删除失败，请重试';
        }
    }
    header('Location: admin_invite.php');
    exit;
}

$codes = [];
try {
    $stmt = $pdo->query("SELECT `id`, `code`, `max_uses`, `used_count`, `created_at` FROM `invite_codes` ORDER BY `id` DESC");
    $codes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '查询失败，请重试';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>邀请码管理</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>邀请码管理</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:600px;">
        <h2>生成新邀请码</h2>
        <form method="post" action="admin_invite.php" class="flex">
            <input type="hidden" name="action" value="generate">
            <label style="font-size:13px;color:var(--text-light);">可使用次数</label>
            <input type="number" name="max_uses" value="1" min="1" required style="max-width:120px;">
            <button type="submit" class="btn">生成随机邀请码</button>
        </form>
    </div>

    <div class="card">
        <h2>邀请码列表</h2>
        <?php if (empty($codes)): ?>
            <p class="text-mute">暂无邀请码，请先生成。</p>
        <?php else: ?>
            <table>
                <tr>
                    <th style="width:60px;">ID</th>
                    <th>邀请码</th>
                    <th style="width:110px;">最大使用</th>
                    <th style="width:110px;">已使用</th>
                    <th style="width:110px;">剩余</th>
                    <th style="width:160px;">生成时间</th>
                    <th style="width:80px;">操作</th>
                </tr>
                <?php foreach ($codes as $code): ?>
                <tr>
                    <td><?php echo $code['id']; ?></td>
                    <td style="font-family:'SF Mono',Consolas,monospace;font-weight:600;"><?php echo htmlspecialchars($code['code']); ?></td>
                    <td><?php echo $code['max_uses']; ?></td>
                    <td><?php echo $code['used_count']; ?></td>
                    <td><?php echo max(0, $code['max_uses'] - $code['used_count']); ?></td>
                    <td><?php echo htmlspecialchars($code['created_at']); ?></td>
                    <td>
                        <a href="admin_invite.php?action=delete&id=<?php echo $code['id']; ?>" onclick="return confirm('确定删除此邀请码？');">删除</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>