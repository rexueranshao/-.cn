<?php
// =============================================
// 文件名：admin_login_bg.php
// 用途：管理员上传/删除登录页背景图片
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

$currentBg = '';
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'login_bg' LIMIT 1");
    $currentBg = $stmt->fetchColumn();
    if ($currentBg === false) $currentBg = '';
} catch (PDOException $e) {
    $error = '读取设置失败';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload') {
    if (isset($_FILES['bg_file']) && $_FILES['bg_file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['bg_file'];
        $maxSize = 20 * 1024 * 1024;
        $imageInfo = @getimagesize($file['tmp_name']);
        if ($imageInfo === false) {
            $error = '文件不是有效图片';
        } elseif ($file['size'] > $maxSize) {
            $error = '图片大小不能超过 20MB';
        } else {
            $mime = $imageInfo['mime'];
            $allowedMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            if (!in_array($mime, $allowedMimes)) {
                $error = '只允许上传 JPG/PNG/GIF/WEBP 格式的图片';
            } else {
                $uploadDir = __DIR__ . '/uploads/login_bg/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                $extMap = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
                $ext = $extMap[$mime] ?? 'jpg';
                $newFileName = 'login_bg_' . bin2hex(random_bytes(8)) . '.' . $ext;
                $targetPath = $uploadDir . $newFileName;

                if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                    $bgUrl = 'uploads/login_bg/' . $newFileName;
                    if (!empty($currentBg)) {
                        $oldFile = __DIR__ . '/' . $currentBg;
                        if (file_exists($oldFile)) @unlink($oldFile);
                    }
                    try {
                        $stmt = $pdo->prepare("UPDATE `settings` SET `setting_value` = :value WHERE `setting_key` = 'login_bg'");
                        $stmt->execute([':value' => $bgUrl]);
                        $currentBg = $bgUrl;
                        $success = '登录页背景已更新';
                    } catch (PDOException $e) {
                        $error = '数据库更新失败，请重试';
                        @unlink($targetPath);
                    }
                } else {
                    $error = '文件保存失败，请检查目录权限';
                }
            }
        }
    } else {
        $error = '请选择要上传的图片';
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'delete') {
    if (!empty($currentBg)) {
        $oldFile = __DIR__ . '/' . $currentBg;
        if (file_exists($oldFile)) @unlink($oldFile);
    }
    try {
        $stmt = $pdo->prepare("UPDATE `settings` SET `setting_value` = '' WHERE `setting_key` = 'login_bg'");
        $stmt->execute();
        $currentBg = '';
        $success = '登录页背景已删除，将使用默认纯色背景';
    } catch (PDOException $e) {
        $error = '删除失败，请重试';
    }
    header('Location: admin_login_bg.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录页背景设置</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .bg-preview { max-width: 100%; max-height: 300px; border-radius: 10px; border: 1px solid var(--border); margin-top: 10px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>登录页背景设置</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:700px;">
        <h2>当前背景</h2>
        <?php if ($currentBg): ?>
            <p class="text-mute">背景已设置</p>
            <img src="<?php echo htmlspecialchars($currentBg); ?>" class="bg-preview" alt="当前背景">
            <p class="mt-20">
                <a href="admin_login_bg.php?action=delete" class="btn btn-danger btn-sm" onclick="return confirm('确定删除当前背景吗？');">删除背景</a>
            </p>
        <?php else: ?>
            <p class="text-mute">未设置背景，登录页将使用默认纯色</p>
        <?php endif; ?>
    </div>

    <div class="card" style="max-width:700px;">
        <h2>上传新背景</h2>
        <form method="post" action="admin_login_bg.php" enctype="multipart/form-data">
            <input type="hidden" name="action" value="upload">
            <p class="mb-10">
                <label style="font-size:13px;color:var(--text-light);">选择图片（推荐 1920×1080 以上，JPG/PNG/GIF/WEBP，不超过 20MB）</label>
            </p>
            <input type="file" name="bg_file" accept="image/*" required>
            <p class="mt-20"><button type="submit" class="btn">上传并应用</button></p>
        </form>
    </div>
</body>
</html>