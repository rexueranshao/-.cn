<?php
// =============================================
// 文件名：admin_manual_review.php
// 用途：管理员人工复议队列（聊天消息、论坛帖子、论坛回复）
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

// 处理审核
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $type = $_POST['type'] ?? '';
    $id = intval($_POST['id'] ?? 0);

    if ($id > 0 && in_array($type, ['chat_message', 'forum_post', 'forum_reply'])) {
        if ($action === 'approve') {
            $newStatus = 'normal';
        } elseif ($action === 'reject') {
            $newStatus = 'rejected';
        } else {
            $error = '无效操作';
        }

        if (!$error) {
            try {
                if ($type == 'chat_message') {
                    $stmt = $pdo->prepare("UPDATE chat_messages SET status = :status WHERE id = :id");
                } elseif ($type == 'forum_post') {
                    $stmt = $pdo->prepare("UPDATE forum_posts SET status = :status WHERE id = :id");
                } else {
                    $stmt = $pdo->prepare("UPDATE forum_replies SET status = :status WHERE id = :id");
                }
                $stmt->execute([':status' => $newStatus, ':id' => $id]);
                $success = '处理成功';
            } catch (PDOException $e) {
                $error = '数据库操作失败';
            }
        }
    } else {
        $error = '无效参数';
    }
}

// 待复议内容
$pendingChat = [];
$pendingPosts = [];
$pendingReplies = [];

try {
    $pendingChat = $pdo->query("SELECT id, user_name, content, created_at FROM chat_messages WHERE status='pending_manual' ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
    $pendingPosts = $pdo->query("SELECT id, user_name, title, content, created_at FROM forum_posts WHERE status='pending_manual' ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
    $pendingReplies = $pdo->query("SELECT r.id, r.user_name, r.content, r.created_at, p.title AS post_title FROM forum_replies r LEFT JOIN forum_posts p ON r.post_id=p.id WHERE r.status='pending_manual' ORDER BY r.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '查询失败：' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>人工复议队列</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .review-item {
            border: 1px solid var(--border);
            border-radius: 10px;
            background: #fafbfc;
            padding: 16px 20px;
            margin-bottom: 14px;
        }
        .review-item h3 { margin: 0 0 8px; }
        .review-item .meta { color: var(--text-mute); font-size: 12.5px; margin-bottom: 8px; }
        .review-item .content {
            background: #fff;
            border-left: 3px solid var(--accent);
            padding: 10px 14px;
            border-radius: 0 6px 6px 0;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>人工复议队列</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card">
        <h2>聊天消息待复议（<?php echo count($pendingChat); ?>）</h2>
        <?php if (empty($pendingChat)): ?>
            <p class="text-mute">暂无</p>
        <?php else: ?>
            <?php foreach ($pendingChat as $item): ?>
                <div class="review-item">
                    <div class="meta"><strong><?php echo htmlspecialchars($item['user_name']); ?></strong> · <?php echo htmlspecialchars($item['created_at']); ?></div>
                    <div class="content"><?php echo nl2br(htmlspecialchars($item['content'])); ?></div>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="type" value="chat_message">
                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                        <button type="submit" name="action" value="approve" class="btn btn-sm btn-success">通过</button>
                        <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger">拒绝</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2>论坛帖子待复议（<?php echo count($pendingPosts); ?>）</h2>
        <?php if (empty($pendingPosts)): ?>
            <p class="text-mute">暂无</p>
        <?php else: ?>
            <?php foreach ($pendingPosts as $item): ?>
                <div class="review-item">
                    <h3><?php echo htmlspecialchars($item['title']); ?></h3>
                    <div class="meta"><strong><?php echo htmlspecialchars($item['user_name']); ?></strong> · <?php echo htmlspecialchars($item['created_at']); ?></div>
                    <div class="content"><?php echo nl2br(htmlspecialchars($item['content'])); ?></div>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="type" value="forum_post">
                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                        <button type="submit" name="action" value="approve" class="btn btn-sm btn-success">通过</button>
                        <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger">拒绝</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2>论坛回复待复议（<?php echo count($pendingReplies); ?>）</h2>
        <?php if (empty($pendingReplies)): ?>
            <p class="text-mute">暂无</p>
        <?php else: ?>
            <?php foreach ($pendingReplies as $item): ?>
                <div class="review-item">
                    <div class="meta"><strong><?php echo htmlspecialchars($item['user_name']); ?></strong> 回复于「<?php echo htmlspecialchars($item['post_title'] ?? '未知帖子'); ?>」 · <?php echo htmlspecialchars($item['created_at']); ?></div>
                    <div class="content"><?php echo nl2br(htmlspecialchars($item['content'])); ?></div>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="type" value="forum_reply">
                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                        <button type="submit" name="action" value="approve" class="btn btn-sm btn-success">通过</button>
                        <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger">拒绝</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>