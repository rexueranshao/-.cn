<?php
// =============================================
// 文件名：admin_mc_permission.php
// 用途：设置哪些用户组可以访问 MC 游戏联机板块
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

$groups = [];
try {
    $stmt = $pdo->query("SELECT `id`, `name` FROM `user_groups` ORDER BY `id` ASC");
    $groups = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '用户组查询失败';
}

$allowedGroups = [];
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'mc_game_groups' LIMIT 1");
    $val = $stmt->fetchColumn();
    if ($val !== false && $val !== '') {
        $allowedGroups = array_map('intval', explode(',', $val));
    }
} catch (PDOException $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected = $_POST['groups'] ?? [];
    if (is_array($selected)) {
        $selected = array_map('intval', $selected);
        $groupsStr = implode(',', $selected);
        try {
            $stmt = $pdo->prepare("UPDATE `settings` SET `setting_value` = :value WHERE `setting_key` = 'mc_game_groups'");
            $stmt->execute([':value' => $groupsStr]);
            $allowedGroups = $selected;
            $success = '权限设置已更新';
        } catch (PDOException $e) {
            $error = '保存失败，请重试';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MC板块权限设置</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .group-list label {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 0;
            font-size: 14px;
            cursor: pointer;
        }
        .group-list label:hover { background: #f9fafc; padding-left: 6px; transition: all .15s; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>MC游戏联机板块访问权限</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:640px;">
        <h2>选择允许访问 MC 游戏联机的用户组</h2>
        <form method="post" action="admin_mc_permission.php">
            <?php if (empty($groups)): ?>
                <p class="text-mute">暂无用户组，请先创建用户组。</p>
            <?php else: ?>
                <div class="group-list">
                    <?php foreach ($groups as $group): ?>
                        <label>
                            <input type="checkbox" name="groups[]" value="<?php echo $group['id']; ?>" <?php echo in_array($group['id'], $allowedGroups) ? 'checked' : ''; ?>>
                            <?php echo htmlspecialchars($group['name']); ?>（ID：<?php echo $group['id']; ?>）
                        </label>
                    <?php endforeach; ?>
                </div>
                <p class="text-mute mt-10">未勾选的用户组将看不到首页的"MC游戏联机"入口。新注册用户如果所在组未勾选，默认不可见。</p>
                <p class="mt-20"><button type="submit" class="btn">保存设置</button></p>
            <?php endif; ?>
        </form>
    </div>
</body>
</html>