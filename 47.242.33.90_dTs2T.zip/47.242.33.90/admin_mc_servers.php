<?php
// =============================================
// 文件名：admin_mc_servers.php
// 用途：管理员管理MC服务器列表
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

// 编辑模式
$editId = 0;
$editData = null;
if (isset($_GET['edit']) && intval($_GET['edit']) > 0) {
    $editId = intval($_GET['edit']);
    try {
        $stmt = $pdo->prepare("SELECT * FROM `mc_servers` WHERE `id` = :id");
        $stmt->execute([':id' => $editId]);
        $editData = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$editData) $editId = 0;
    } catch (PDOException $e) {}
}

// 添加/编辑
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save') {
    $id = intval($_POST['id'] ?? 0);
    $server_name = trim($_POST['server_name'] ?? '');
    $server_number = trim($_POST['server_number'] ?? '');
    $server_address = trim($_POST['server_address'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $requirements = trim($_POST['requirements'] ?? '');
    $modpack_url = trim($_POST['modpack_url'] ?? '');

    $server_image = trim($_POST['server_image'] ?? '');
    if (isset($_FILES['server_image_file']) && $_FILES['server_image_file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['server_image_file'];
        $maxSize = 5 * 1024 * 1024;
        $imageInfo = @getimagesize($file['tmp_name']);
        if ($imageInfo === false) {
            $error = '宣传图不是有效图片';
        } elseif ($file['size'] > $maxSize) {
            $error = '宣传图大小不能超过 5MB';
        } else {
            $mime = $imageInfo['mime'];
            $allowedMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            if (!in_array($mime, $allowedMimes)) {
                $error = '只允许上传 JPG/PNG/GIF/WEBP 格式的图片';
            } else {
                $uploadDir = __DIR__ . '/uploads/mc_servers/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                $extMap = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
                $ext = $extMap[$mime] ?? 'jpg';
                $newFileName = 'mc_' . bin2hex(random_bytes(8)) . '.' . $ext;
                $targetPath = $uploadDir . $newFileName;

                if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                    if (!empty($editData['server_image']) && strpos($editData['server_image'], 'uploads/mc_servers/') !== false) {
                        $oldFile = __DIR__ . '/' . $editData['server_image'];
                        if (file_exists($oldFile)) @unlink($oldFile);
                    }
                    $server_image = 'uploads/mc_servers/' . $newFileName;
                } else {
                    $error = '宣传图上传失败，请检查目录权限';
                }
            }
        }
    }

    if ($server_name === '' || $server_number === '' || $server_address === '' || $error) {
        if (!$error) $error = '请填写服务器名称、编号和地址';
    } else {
        try {
            if ($id > 0) {
                $stmt = $pdo->prepare("UPDATE `mc_servers` SET `server_name`=:server_name, `server_number`=:server_number, `server_address`=:server_address, `server_image`=:server_image, `description`=:description, `requirements`=:requirements, `modpack_url`=:modpack_url WHERE `id`=:id");
                $stmt->execute([
                    ':server_name' => $server_name, ':server_number' => $server_number,
                    ':server_address' => $server_address, ':server_image' => $server_image,
                    ':description' => $description, ':requirements' => $requirements,
                    ':modpack_url' => $modpack_url, ':id' => $id
                ]);
                $success = '服务器信息已更新';
            } else {
                $stmt = $pdo->prepare("INSERT INTO `mc_servers` (`server_name`, `server_number`, `server_address`, `server_image`, `description`, `requirements`, `modpack_url`) VALUES (:server_name, :server_number, :server_address, :server_image, :description, :requirements, :modpack_url)");
                $stmt->execute([
                    ':server_name' => $server_name, ':server_number' => $server_number,
                    ':server_address' => $server_address, ':server_image' => $server_image,
                    ':description' => $description, ':requirements' => $requirements,
                    ':modpack_url' => $modpack_url
                ]);
                $success = '服务器已添加';
            }
            $editId = 0;
            $editData = null;
        } catch (PDOException $e) {
            $error = '数据库操作失败，请重试';
        }
    }
}

// 删除
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($id > 0) {
        try {
            $stmt = $pdo->prepare("SELECT `server_image` FROM `mc_servers` WHERE `id` = :id");
            $stmt->execute([':id' => $id]);
            $image = $stmt->fetchColumn();
            if ($image && strpos($image, 'uploads/mc_servers/') !== false) {
                $filePath = __DIR__ . '/' . $image;
                if (file_exists($filePath)) @unlink($filePath);
            }
        } catch (PDOException $e) {}
        try {
            $stmt = $pdo->prepare("DELETE FROM `mc_servers` WHERE `id` = :id");
            $stmt->execute([':id' => $id]);
            $success = '服务器已删除';
        } catch (PDOException $e) {
            $error = '删除失败';
        }
    }
    header('Location: admin_mc_servers.php');
    exit;
}

// 服务器列表
$servers = [];
try {
    $stmt = $pdo->query("SELECT * FROM `mc_servers` ORDER BY `id` DESC");
    $servers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '查询失败';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MC服务器管理</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-row { margin-bottom: 12px; }
        .form-row label { display: block; margin-bottom: 5px; font-weight: 500; color: var(--text-light); font-size: 13px; }
        .server-thumb { max-width: 100px; max-height: 60px; border-radius: 6px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>MC服务器管理</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card">
        <h2><?php echo $editId > 0 ? '编辑服务器 #' . $editId : '添加新服务器'; ?></h2>
        <?php if ($editId > 0): ?>
            <p><a href="admin_mc_servers.php">取消编辑</a></p>
        <?php endif; ?>
        <form method="post" action="admin_mc_servers.php" enctype="multipart/form-data">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?php echo $editId; ?>">
            <div class="form-row">
                <label>服务器名称</label>
                <input type="text" name="server_name" value="<?php echo $editData ? htmlspecialchars($editData['server_name']) : ''; ?>" required>
            </div>
            <div class="form-row">
                <label>服务器编号</label>
                <input type="text" name="server_number" value="<?php echo $editData ? htmlspecialchars($editData['server_number']) : ''; ?>" required>
            </div>
            <div class="form-row">
                <label>服务器地址</label>
                <input type="text" name="server_address" value="<?php echo $editData ? htmlspecialchars($editData['server_address']) : ''; ?>" required>
            </div>
            <div class="form-row">
                <label>宣传图（上传文件）</label>
                <input type="file" name="server_image_file" accept="image/*">
                <?php if ($editData && $editData['server_image']): ?>
                    <p class="mt-10">当前宣传图：<img src="<?php echo htmlspecialchars($editData['server_image']); ?>" class="server-thumb"></p>
                <?php endif; ?>
            </div>
            <div class="form-row">
                <label>或宣传图 URL（可手动填写）</label>
                <input type="text" name="server_image" value="<?php echo $editData ? htmlspecialchars($editData['server_image']) : ''; ?>">
            </div>
            <div class="form-row">
                <label>宣传文字</label>
                <textarea name="description" rows="3"><?php echo $editData ? htmlspecialchars($editData['description']) : ''; ?></textarea>
            </div>
            <div class="form-row">
                <label>加入要求</label>
                <textarea name="requirements" rows="3"><?php echo $editData ? htmlspecialchars($editData['requirements']) : ''; ?></textarea>
            </div>
            <div class="form-row">
                <label>整合包下载链接</label>
                <input type="text" name="modpack_url" value="<?php echo $editData ? htmlspecialchars($editData['modpack_url']) : ''; ?>">
            </div>
            <button type="submit" class="btn"><?php echo $editId > 0 ? '保存修改' : '添加服务器'; ?></button>
        </form>
    </div>

    <div class="card">
        <h2>现有服务器列表</h2>
        <?php if (empty($servers)): ?>
            <p class="text-mute">暂无服务器</p>
        <?php else: ?>
            <table>
                <tr>
                    <th style="width:60px;">ID</th>
                    <th>名称</th>
                    <th style="width:100px;">编号</th>
                    <th>地址</th>
                    <th style="width:120px;">宣传图</th>
                    <th style="width:140px;">操作</th>
                </tr>
                <?php foreach ($servers as $s): ?>
                <tr>
                    <td><?php echo $s['id']; ?></td>
                    <td><?php echo htmlspecialchars($s['server_name']); ?></td>
                    <td><?php echo htmlspecialchars($s['server_number']); ?></td>
                    <td><?php echo htmlspecialchars($s['server_address']); ?></td>
                    <td><?php if ($s['server_image']): ?><img src="<?php echo htmlspecialchars($s['server_image']); ?>" class="server-thumb"><?php endif; ?></td>
                    <td>
                        <a href="admin_mc_servers.php?edit=<?php echo $s['id']; ?>" class="btn btn-sm">编辑</a>
                        <a href="admin_mc_servers.php?action=delete&id=<?php echo $s['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定删除该服务器？');">删除</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>