<?php
// =============================================
// 文件名：admin_messages.php
// 用途：管理员查看所有留言并删除
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

// 删除留言
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $deleteId = intval($_GET['id']);
    if ($deleteId > 0) {
        try {
            $stmt = $pdo->prepare("DELETE FROM `messages` WHERE `id` = :id");
            $stmt->execute([':id' => $deleteId]);
            $success = '留言已删除';
        } catch (PDOException $e) {
            $error = '删除失败，请稍后再试';
        }
    }
    header('Location: admin_messages.php');
    exit;
}

$allMessages = [];
try {
    $stmt = $pdo->query("SELECT `id`, `user_name`, `content`, `created_at` FROM `messages` ORDER BY `created_at` DESC, `id` DESC");
    $allMessages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '留言查询失败，请稍后再试';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>留言管理</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>留言管理</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <?php if (empty($allMessages)): ?>
        <p class="text-mute">暂无留言。</p>
    <?php else: ?>
        <table>
            <tr>
                <th style="width:60px;">ID</th>
                <th style="width:120px;">留言人</th>
                <th>留言内容</th>
                <th style="width:170px;">提交时间</th>
                <th style="width:80px;">操作</th>
            </tr>
            <?php foreach ($allMessages as $msg): ?>
            <tr>
                <td><?php echo $msg['id']; ?></td>
                <td><?php echo htmlspecialchars($msg['user_name']); ?></td>
                <td><?php echo htmlspecialchars($msg['content']); ?></td>
                <td><?php echo htmlspecialchars($msg['created_at']); ?></td>
                <td>
                    <a href="admin_messages.php?action=delete&id=<?php echo $msg['id']; ?>" 
                       onclick="return confirm('确定要删除这条留言吗？');">删除</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</body>
</html>