<?php
// =============================================
// 文件名：admin_reports.php
// 用途：管理员查看和处理举报
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

// 处理举报状态更新
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['report_id'], $_POST['action'])) {
    $reportId = intval($_POST['report_id']);
    $action = $_POST['action'];
    if ($action === 'resolve_safe' || $action === 'resolve_unsafe') {
        $status = $action === 'resolve_safe' ? 'resolved_safe' : 'resolved_unsafe';
        try {
            $stmt = $pdo->prepare("UPDATE `reports` SET `status` = :status, `resolved_at` = NOW(), `resolver_admin_id` = 1 WHERE `id` = :id");
            $stmt->execute([':status' => $status, ':id' => $reportId]);
            $success = '举报已处理';
        } catch (PDOException $e) {
            $error = '操作失败';
        }
    }
}

// 查询所有举报
$reports = [];
try {
    $sql = "SELECT r.id, r.target_type, r.target_id, r.reporter_user_id, r.reason, r.ai_safe, r.ai_reason, r.status, r.created_at, r.resolved_at
            FROM reports r
            ORDER BY r.created_at DESC";
    $reports = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '举报查询失败';
}

function statusText($status) {
    switch ($status) {
        case 'pending_ai': return '待AI处理';
        case 'pending_manual': return '待人工复议';
        case 'resolved_safe': return '已处理-安全';
        case 'resolved_unsafe': return '已处理-违规';
        default: return $status;
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>举报管理</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>举报管理</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <?php if (empty($reports)): ?>
        <p class="text-mute">暂无举报</p>
    <?php else: ?>
        <table>
            <tr>
                <th style="width:60px;">ID</th>
                <th style="width:100px;">目标类型</th>
                <th style="width:70px;">目标ID</th>
                <th style="width:80px;">举报人</th>
                <th>原因</th>
                <th style="width:90px;">AI结果</th>
                <th>AI理由</th>
                <th style="width:120px;">状态</th>
                <th style="width:160px;">举报时间</th>
                <th style="width:150px;">操作</th>
            </tr>
            <?php foreach ($reports as $r): ?>
            <tr>
                <td><?php echo $r['id']; ?></td>
                <td><?php echo htmlspecialchars($r['target_type']); ?></td>
                <td><?php echo $r['target_id']; ?></td>
                <td><?php echo $r['reporter_user_id']; ?></td>
                <td><?php echo htmlspecialchars($r['reason']); ?></td>
                <td><?php echo $r['ai_safe'] === null ? '未检测' : ($r['ai_safe'] ? '安全' : '不安全'); ?></td>
                <td><?php echo htmlspecialchars($r['ai_reason'] ?? ''); ?></td>
                <td><?php echo statusText($r['status']); ?></td>
                <td><?php echo htmlspecialchars($r['created_at']); ?></td>
                <td>
                    <?php if ($r['status'] == 'pending_ai' || $r['status'] == 'pending_manual'): ?>
                        <form method="post" style="display:inline;" onsubmit="return confirm('确定标记为安全？');">
                            <input type="hidden" name="report_id" value="<?php echo $r['id']; ?>">
                            <input type="hidden" name="action" value="resolve_safe">
                            <button type="submit" class="btn btn-sm btn-success">安全</button>
                        </form>
                        <form method="post" style="display:inline;" onsubmit="return confirm('确定标记为违规？');">
                            <input type="hidden" name="report_id" value="<?php echo $r['id']; ?>">
                            <input type="hidden" name="action" value="resolve_unsafe">
                            <button type="submit" class="btn btn-sm btn-danger">违规</button>
                        </form>
                    <?php else: ?>
                        <span class="text-mute">已处理</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</body>
</html>