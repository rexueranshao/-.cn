<?php
// =============================================
// 文件名：ai_functions.php
// 用途：提供AI内容安全检测函数
// =============================================

/**
 * 调用AI检测文本是否安全
 * @param string $text 待检测文本
 * @return array ['safe' => bool, 'reason' => string]
 */
function ai_check_content($text) {
    global $pdo; // 使用 config.php 中的 $pdo
    // 读取AI配置
    $stmt = $pdo->query("SELECT `setting_key`, `setting_value` FROM `settings` WHERE `setting_key` IN ('ai_api_url','ai_api_key','ai_model','ai_enabled')");
    $config = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $config[$row['setting_key']] = $row['setting_value'];
    }
    if (($config['ai_enabled'] ?? '0') !== '1') {
        // AI未启用，默认安全
        return ['safe' => true, 'reason' => 'AI审核未启用'];
    }
    $apiUrl = $config['ai_api_url'] ?? '';
    $apiKey = $config['ai_api_key'] ?? '';
    $model = $config['ai_model'] ?? '';
    if (empty($apiUrl) || empty($apiKey) || empty($model)) {
        return ['safe' => false, 'reason' => 'AI配置不完整'];
    }

    $prompt = "你是内容安全检测器，只输出JSON，禁止输出任何额外文字。\n任务：判断下面用户提交文本是否含有违规内容：色情、暴力、辱骂、歧视、违法教唆、敏感言论。\n输出格式严格：{\"safe\":true,\"reason\":\"ok\"} 或者 {\"safe\":false,\"reason\":\"简单说明原因\"}\n待检测文本：{$text}";

    // 调用API（此处示例为OpenAI格式，可根据实际调整）
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);
    $postData = json_encode([
        'model' => $model,
        'messages' => [
            ['role' => 'user', 'content' => $prompt]
        ],
        'temperature' => 0.1
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode != 200) {
        return ['safe' => false, 'reason' => 'AI服务请求失败，HTTP ' . $httpCode];
    }
    $data = json_decode($response, true);
    $content = $data['choices'][0]['message']['content'] ?? '';
    // 尝试解析返回的JSON
    $result = json_decode($content, true);
    if (is_array($result) && isset($result['safe'])) {
        return [
            'safe' => (bool)$result['safe'],
            'reason' => $result['reason'] ?? ($result['safe'] ? 'ok' : '违规内容')
        ];
    }
    // 解析失败，默认安全（避免误杀）
    return ['safe' => true, 'reason' => 'AI解析失败，默认安全'];
}