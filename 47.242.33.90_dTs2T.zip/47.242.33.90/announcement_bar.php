<?php
// =============================================
// 文件名：announcement_bar.php
// 用途：公告栏组件（摘要显示 + 阅读全文按钮）
// =============================================
require_once 'config.php';

$siteFavicon = '';
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'site_favicon' LIMIT 1");
    $siteFavicon = $stmt->fetchColumn();
    if ($siteFavicon === false) $siteFavicon = '';
} catch (PDOException $e) {}

try {
    $stmt = $pdo->query("SELECT `content` FROM `announcements` ORDER BY `id` DESC LIMIT 1");
    $announcement = $stmt->fetchColumn();
} catch (PDOException $e) {
    $announcement = '';
}

if ($siteFavicon !== ''):
?>
<script>
(function() {
    var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
    link.type = 'image/x-icon';
    link.rel = 'shortcut icon';
    link.href = '<?php echo htmlspecialchars($siteFavicon, ENT_QUOTES, 'UTF-8'); ?>';
    document.head.appendChild(link);
})();
</script>
<?php endif; ?>

<?php if ($announcement !== '' && $announcement !== false): ?>
    <?php
    $summary = mb_substr($announcement, 0, 30, 'UTF-8');
    if (mb_strlen($announcement, 'UTF-8') > 30) $summary .= '...';
    ?>
<div class="card" style="background:#f9fbff;border-color:#d8e6ff;padding:12px 18px;margin-bottom:18px;">
    <strong>公告：</strong>
    <span><?php echo htmlspecialchars($summary); ?></span>
    <a href="announcement_detail.php" class="btn btn-sm" style="margin-left:10px;">阅读全文</a>
</div>
<?php endif; ?>