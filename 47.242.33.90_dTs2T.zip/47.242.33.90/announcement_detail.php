<?php
// =============================================
// 文件名：announcement_detail.php
// 用途：公告详情页（阅读完整公告）
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$siteFavicon = '';
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'site_favicon' LIMIT 1");
    $siteFavicon = $stmt->fetchColumn();
    if ($siteFavicon === false) $siteFavicon = '';
} catch (PDOException $e) {}

$ann = null;
try {
    $stmt = $pdo->query("SELECT `content`, `updated_at` FROM `announcements` ORDER BY `id` DESC LIMIT 1");
    $ann = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>公告详情</title>
    <?php if ($siteFavicon): ?>
        <link rel="icon" href="<?php echo htmlspecialchars($siteFavicon, ENT_QUOTES, 'UTF-8'); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <p class="page-nav">
        <a href="javascript:history.back()" class="btn btn-secondary btn-sm">返回</a>
    </p>
    <?php if ($ann): ?>
        <div class="card" style="max-width:760px;">
            <h1 style="border:none;padding:0;">公告</h1>
            <p class="text-mute">发布时间：<?php echo htmlspecialchars($ann['updated_at']); ?></p>
            <div style="margin-top:14px;"><?php echo nl2br(htmlspecialchars($ann['content'])); ?></div>
        </div>
    <?php else: ?>
        <p class="text-mute">暂无公告</p>
    <?php endif; ?>
</body>
</html>