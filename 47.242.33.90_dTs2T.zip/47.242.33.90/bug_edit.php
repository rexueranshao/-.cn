<?php
// =============================================
// 文件名：bug_edit.php
// 用途：管理员编辑bug报告
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$bugId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$bug = null;

if ($bugId <= 0) {
    $error = '无效的bug编号';
} else {
    try {
        $stmt = $pdo->prepare("SELECT `id`, `title`, `description`, `bug_type`, `severity`, `status`, `admin_comment` FROM `bug_reports` WHERE `id` = :id");
        $stmt->execute([':id' => $bugId]);
        $bug = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$bug) $error = 'bug不存在';
    } catch (PDOException $e) {
        $error = '查询失败';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $bug) {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $bug_type = trim($_POST['bug_type'] ?? '');
    $severity = trim($_POST['severity'] ?? '');
    $status = trim($_POST['status'] ?? 'open');
    $admin_comment = trim($_POST['admin_comment'] ?? '');

    if ($title === '' || $description === '' || $bug_type === '') {
        $error = '标题、描述和类型不能为空';
    } elseif (!in_array($status, ['open', 'confirmed', 'rewarded', 'resolved', 'rejected'])) {
        $error = '无效的状态';
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE `bug_reports` SET `title` = :title, `description` = :description, `bug_type` = :bug_type, `severity` = :severity, `status` = :status, `admin_comment` = :admin_comment WHERE `id` = :id");
            $stmt->execute([
                ':title' => $title, ':description' => $description,
                ':bug_type' => $bug_type, ':severity' => $severity,
                ':status' => $status, ':admin_comment' => $admin_comment,
                ':id' => $bugId,
            ]);
            header('Location: admin_bugs.php');
            exit;
        } catch (PDOException $e) {
            $error = '更新失败';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>编辑bug #<?php echo $bug ? $bug['id'] : ''; ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-row { margin-bottom: 14px; }
        .form-row label { display: block; margin-bottom: 6px; font-weight: 500; color: var(--text-light); font-size: 13px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>编辑bug #<?php echo $bug ? $bug['id'] : ''; ?></h1>
    <p class="page-nav">
        <a href="admin_bugs.php" class="btn btn-secondary btn-sm">返回管理</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>

    <?php if ($bug): ?>
    <div class="card" style="max-width:640px;">
        <form method="post" action="bug_edit.php?id=<?php echo $bugId; ?>">
            <div class="form-row">
                <label>标题</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($bug['title']); ?>" required>
            </div>
            <div class="form-row">
                <label>详细描述</label>
                <textarea name="description" rows="6" required><?php echo htmlspecialchars($bug['description']); ?></textarea>
            </div>
            <div class="form-row">
                <label>bug类型</label>
                <select name="bug_type" required>
                    <?php foreach (['安全漏洞','功能bug','性能问题','界面问题','其他'] as $t): ?>
                        <option value="<?php echo $t; ?>" <?php echo $bug['bug_type'] === $t ? 'selected' : ''; ?>><?php echo $t; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row">
                <label>严重程度</label>
                <select name="severity">
                    <?php foreach (['一般','中等','高危'] as $s): ?>
                        <option value="<?php echo $s; ?>" <?php echo $bug['severity'] === $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row">
                <label>状态</label>
                <select name="status">
                    <option value="open" <?php echo $bug['status'] === 'open' ? 'selected' : ''; ?>>待处理</option>
                    <option value="confirmed" <?php echo $bug['status'] === 'confirmed' ? 'selected' : ''; ?>>已确认</option>
                    <option value="resolved" <?php echo $bug['status'] === 'resolved' ? 'selected' : ''; ?>>已解决</option>
                    <option value="rejected" <?php echo $bug['status'] === 'rejected' ? 'selected' : ''; ?>>已拒绝</option>
                    <option value="rewarded" <?php echo $bug['status'] === 'rewarded' ? 'selected' : ''; ?>>已奖励（旧状态）</option>
                </select>
            </div>
            <div class="form-row">
                <label>管理员留言（所有人可见）</label>
                <textarea name="admin_comment" rows="4" placeholder="可填写处理说明、拒绝原因等"><?php echo htmlspecialchars($bug['admin_comment'] ?? ''); ?></textarea>
            </div>
            <button type="submit" class="btn">保存修改</button>
        </form>
    </div>
    <?php endif; ?>
</body>
</html>