<?php
// =============================================
// 文件名：bug_list.php
// 用途：公开的bug列表
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$isAdmin = isset($_SESSION['admin']);
$homeLink = $isAdmin ? 'admin_index.php' : 'user_index.php';

$error = '';
$bugs = [];

try {
    $stmt = $pdo->query("SELECT `id`, `title`, `bug_type`, `severity`, `status`, `reporter_name`, `created_at` FROM `bug_reports` ORDER BY `created_at` DESC, `id` DESC");
    $bugs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '查询失败，请稍后再试';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>bug列表</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>bug报告列表</h1>
    <p class="page-nav">
        <a href="bug_report.php" class="btn btn-sm">提交新bug</a>
        <a href="<?php echo $homeLink; ?>" class="btn btn-secondary btn-sm">返回首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>

    <?php if (empty($bugs)): ?>
        <p class="text-mute">暂无bug报告</p>
    <?php else: ?>
        <table>
            <tr>
                <th style="width:80px;">编号</th>
                <th>标题</th>
                <th style="width:120px;">类型</th>
                <th style="width:100px;">严重程度</th>
                <th style="width:100px;">状态</th>
                <th style="width:120px;">报告人</th>
                <th style="width:160px;">提交时间</th>
                <th style="width:80px;">查看</th>
            </tr>
            <?php foreach ($bugs as $bug): ?>
            <tr>
                <td>#<?php echo $bug['id']; ?></td>
                <td><?php echo htmlspecialchars($bug['title']); ?></td>
                <td><?php echo htmlspecialchars($bug['bug_type']); ?></td>
                <td><?php echo htmlspecialchars($bug['severity']); ?></td>
                <td>
                    <?php
                    if ($bug['status'] === 'open') echo '待处理';
                    elseif ($bug['status'] === 'confirmed') echo '已确认';
                    elseif ($bug['status'] === 'rewarded') echo '已奖励';
                    elseif ($bug['status'] === 'resolved') echo '已解决';
                    elseif ($bug['status'] === 'rejected') echo '已拒绝';
                    ?>
                </td>
                <td><?php echo htmlspecialchars($bug['reporter_name']); ?></td>
                <td><?php echo htmlspecialchars($bug['created_at']); ?></td>
                <td><a href="bug_view.php?id=<?php echo $bug['id']; ?>">查看</a></td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</body>
</html>