<?php
// =============================================
// 文件名：bug_report.php
// 用途：用户提交bug报告
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$currentUser = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$isAdmin = isset($_SESSION['admin']);
$homeLink = $isAdmin ? 'admin_index.php' : 'user_index.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $bug_type = trim($_POST['bug_type'] ?? '');
    $severity = trim($_POST['severity'] ?? '一般');

    if ($title === '' || $description === '' || $bug_type === '') {
        $error = '请填写标题、详细描述和bug类型';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO `bug_reports` (`reporter_name`, `title`, `description`, `bug_type`, `severity`) VALUES (:reporter, :title, :description, :bug_type, :severity)");
            $stmt->execute([
                ':reporter' => $currentUser,
                ':title' => $title,
                ':description' => $description,
                ':bug_type' => $bug_type,
                ':severity' => $severity,
            ]);
            $newId = $pdo->lastInsertId();
            $success = 'bug报告提交成功，编号：#' . $newId;
        } catch (PDOException $e) {
            $error = '提交失败，请稍后再试';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>提交bug报告</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-row { margin-bottom: 14px; }
        .form-row label { display: block; margin-bottom: 6px; font-weight: 500; color: var(--text-light); font-size: 13px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>提交bug报告</h1>
    <p class="page-nav">
        <a href="bug_list.php" class="btn btn-secondary btn-sm">查看所有bug</a>
        <a href="<?php echo $homeLink; ?>" class="btn btn-secondary btn-sm">返回首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:640px;">
        <form method="post" action="bug_report.php">
            <div class="form-row">
                <label>bug标题</label>
                <input type="text" name="title" required>
            </div>
            <div class="form-row">
                <label>详细描述</label>
                <textarea name="description" rows="6" required></textarea>
            </div>
            <div class="form-row">
                <label>bug类型</label>
                <select name="bug_type" required>
                    <option value="安全漏洞">安全漏洞</option>
                    <option value="功能bug">功能bug</option>
                    <option value="性能问题">性能问题</option>
                    <option value="界面问题">界面问题</option>
                    <option value="其他">其他</option>
                </select>
            </div>
            <div class="form-row">
                <label>严重程度</label>
                <select name="severity">
                    <option value="一般">一般</option>
                    <option value="中等">中等</option>
                    <option value="高危">高危</option>
                </select>
            </div>
            <button type="submit" class="btn">提交报告</button>
        </form>
    </div>
</body>
</html>