<?php
// =============================================
// 文件名：bug_view.php
// 用途：查看单个bug详情，所有登录用户可查看
// 修改：显示管理员留言、支持已拒绝状态
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$isAdmin = isset($_SESSION['admin']);
$homeLink = $isAdmin ? 'admin_index.php' : 'user_index.php';

$bugId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$bug = null;
$error = '';

if ($bugId <= 0) {
    $error = '无效的bug编号';
} else {
    try {
        $stmt = $pdo->prepare("SELECT `id`, `reporter_name`, `title`, `description`, `bug_type`, `severity`, `status`, `points_awarded`, `admin_comment`, `created_at`, `updated_at` FROM `bug_reports` WHERE `id` = :id");
        $stmt->execute([':id' => $bugId]);
        $bug = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$bug) $error = 'bug不存在';
    } catch (PDOException $e) {
        $error = '查询失败';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>bug详情 #<?php echo $bug ? $bug['id'] : ''; ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        .bug-detail { border:1px solid #ccc; padding:15px; background:#fafafa; }
        .admin-comment { margin-top:15px; padding:10px; border-left:3px solid #007bff; background:#f0f8ff; }
        .error { color: red; }
        a { color: blue; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <p><a href="bug_list.php">返回列表</a> | <a href="<?php echo $homeLink; ?>">返回首页</a></p>
    <hr>
    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>

    <?php if ($bug): ?>
        <h1>bug详情 #<?php echo $bug['id']; ?></h1>
        <div class="bug-detail">
            <p><strong>标题：</strong><?php echo htmlspecialchars($bug['title']); ?></p>
            <p><strong>类型：</strong><?php echo htmlspecialchars($bug['bug_type']); ?></p>
            <p><strong>严重程度：</strong><?php echo htmlspecialchars($bug['severity']); ?></p>
            <p><strong>状态：</strong>
                <?php
                if ($bug['status'] === 'open') echo '待处理';
                elseif ($bug['status'] === 'confirmed') echo '已确认';
                elseif ($bug['status'] === 'rewarded') echo '已奖励';
                elseif ($bug['status'] === 'resolved') echo '已解决';
                elseif ($bug['status'] === 'rejected') echo '已拒绝';
                ?>
            </p>
            <p><strong>报告人：</strong><?php echo htmlspecialchars($bug['reporter_name']); ?></p>
            <p><strong>提交时间：</strong><?php echo htmlspecialchars($bug['created_at']); ?></p>
            <p><strong>最后更新：</strong><?php echo htmlspecialchars($bug['updated_at']); ?></p>
            <?php if ($bug['points_awarded'] > 0): ?>
                <p><strong>奖励积分：</strong><?php echo $bug['points_awarded']; ?></p>
            <?php endif; ?>
            <p><strong>详细描述：</strong></p>
            <div><?php echo nl2br(htmlspecialchars($bug['description'])); ?></div>

            <?php if (!empty($bug['admin_comment'])): ?>
                <div class="admin-comment">
                    <strong>管理员留言：</strong>
                    <div><?php echo nl2br(htmlspecialchars($bug['admin_comment'])); ?></div>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</body>
</html>