<?php
// =============================================
// 文件名：chat_message_edit.php
// 用途：管理员编辑聊天室消息内容
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$message = null;

if ($id <= 0) {
    $error = '无效的消息ID';
} else {
    try {
        $stmt = $pdo->prepare("SELECT `id`, `content` FROM `chat_messages` WHERE `id` = :id");
        $stmt->execute([':id' => $id]);
        $message = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$message) $error = '消息不存在';
    } catch (PDOException $e) {
        $error = '查询失败';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $message) {
    $content = trim($_POST['content'] ?? '');
    if ($content === '') {
        $error = '内容不能为空';
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE `chat_messages` SET `content` = :content WHERE `id` = :id");
            $stmt->execute([':content' => $content, ':id' => $id]);
            header('Location: admin_chat_messages.php');
            exit;
        } catch (PDOException $e) {
            $error = '更新失败';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>编辑聊天消息</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        form { max-width: 500px; }
        label { display: block; margin: 10px 0 5px; }
        textarea { width: 100%; height: 100px; }
        button { padding: 8px 20px; cursor: pointer; margin-top: 15px; }
        .error { color: red; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>编辑聊天消息</h1>
    <p><a href="admin_chat_messages.php">返回消息管理</a></p>
    <hr>
    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($message): ?>
    <form method="post" action="chat_message_edit.php?id=<?php echo $id; ?>">
        <label>消息内容：</label>
        <textarea name="content" required><?php echo htmlspecialchars($message['content']); ?></textarea>
        <button type="submit">保存修改</button>
    </form>
    <?php endif; ?>
</body>
</html>