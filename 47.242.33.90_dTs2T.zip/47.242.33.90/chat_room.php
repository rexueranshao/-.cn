<?php
// =============================================
// 文件名：chat_room.php
// 用途：聊天室展示页（全 AJAX，无重定向，自动滚动到底部）
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';
require_once 'ai_functions.php';

$currentUser = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$currentUserId = $_SESSION['user_id'] ?? 0;
$roomId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($roomId <= 0) {
    die('<p style="font-family:Arial;margin:40px;">无效的聊天室ID，请返回 <a href="chat_rooms.php">聊天室列表</a></p>');
}

// ---------- AJAX 拉取新消息 ----------
if (isset($_GET['ajax']) && $_GET['ajax'] == 1) {
    header('Content-Type: application/json; charset=utf-8');
    $lastId = intval($_GET['last_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT cm.id, cm.user_name, cm.content, cm.image_url, cm.message_type, cm.extra_data, cm.created_at,
                                  u.avatar, u.avatar_frame, u.name_color
                           FROM chat_messages cm
                           LEFT JOIN users u ON cm.user_name = u.name
                           WHERE cm.room_id = :r AND cm.id > :l AND cm.status = 'normal'
                           ORDER BY cm.id ASC LIMIT 200");
    $stmt->execute([':r' => $roomId, ':l' => $lastId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $out = [];
    foreach ($rows as $m) {
        $out[] = [
            'id' => $m['id'],
            'user_name' => $m['user_name'],
            'content' => $m['content'],
            'image_url' => $m['image_url'],
            'message_type' => $m['message_type'],
            'extra_data' => $m['extra_data'],
            'created_at' => $m['created_at'],
            'avatar_html' => avatarHtml($m['avatar'], $m['avatar_frame'], $m['user_name']),
            'name_html' => nameHtml($m['user_name'], $m['name_color'])
        ];
    }
    echo json_encode(['messages' => $out], JSON_UNESCAPED_UNICODE);
    exit;
}

// ---------- 领取红包 ----------
if (isset($_GET['action']) && $_GET['action'] === 'claim' && isset($_GET['packet_id'])) {
    header('Content-Type: application/json; charset=utf-8');
    $packetId = intval($_GET['packet_id']);
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT id, sender_id, total_points, status FROM red_packets WHERE id = :id FOR UPDATE");
        $stmt->execute([':id' => $packetId]);
        $p = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$p || $p['status'] !== 'active') { $pdo->rollBack(); echo json_encode(['code'=>400,'message'=>'红包已被领取']); exit; }
        $stmt = $pdo->prepare("SELECT id FROM users WHERE name = :n");
        $stmt->execute([':n' => $currentUser]);
        $uid = $stmt->fetchColumn();
        if ($uid == $p['sender_id']) { $pdo->rollBack(); echo json_encode(['code'=>400,'message'=>'不能领自己的红包']); exit; }
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM red_packet_claims WHERE packet_id = :p AND user_id = :u");
        $stmt->execute([':p' => $packetId, ':u' => $uid]);
        if ($stmt->fetchColumn() > 0) { $pdo->rollBack(); echo json_encode(['code'=>400,'message'=>'已领取过']); exit; }
        $pdo->prepare("INSERT INTO red_packet_claims (packet_id, user_id, claimed_points) VALUES (:p, :u, :pt)")
            ->execute([':p' => $packetId, ':u' => $uid, ':pt' => $p['total_points']]);
        $pdo->prepare("UPDATE users SET points = points + :p WHERE id = :u")->execute([':p' => $p['total_points'], ':u' => $uid]);
        $pdo->prepare("UPDATE red_packets SET status = 'claimed' WHERE id = :id")->execute([':id' => $packetId]);
        $pdo->commit();
        echo json_encode(['code'=>0,'message'=>'领取成功','data'=>['points'=>$p['total_points']]], JSON_UNESCAPED_UNICODE);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['code'=>500,'message'=>'领取失败']);
    }
    exit;
}

// ---------- 房间信息 ----------
$stmt = $pdo->prepare("SELECT name FROM chat_rooms WHERE id = :id");
$stmt->execute([':id' => $roomId]);
$roomName = $stmt->fetchColumn();
if (!$roomName) die('聊天室不存在');

// ---------- 历史消息 ----------
$stmt = $pdo->prepare("SELECT cm.id, cm.user_name, cm.content, cm.image_url, cm.message_type, cm.extra_data, cm.created_at,
                              u.avatar, u.avatar_frame, u.name_color
                       FROM chat_messages cm
                       LEFT JOIN users u ON cm.user_name = u.name
                       WHERE cm.room_id = :r AND cm.status = 'normal'
                       ORDER BY cm.id ASC");
$stmt->execute([':r' => $roomId]);
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
$lastId = empty($messages) ? 0 : end($messages)['id'];

// ---------- 标记已读 ----------
if ($currentUserId > 0) {
    $pdo->prepare("INSERT INTO chat_reads (user_id, room_id, last_read_message_id) VALUES (:u, :r, :l)
                   ON DUPLICATE KEY UPDATE last_read_message_id = :l")
        ->execute([':u' => $currentUserId, ':r' => $roomId, ':l' => $lastId]);
}

// ---------- 辅助函数 ----------
function avatarHtml($url, $frame, $name) {
    $f = $frame ? htmlspecialchars($frame) : '';
    if ($url) {
        return '<img src="'.htmlspecialchars($url).'" class="chat-avatar '.$f.'" style="width:30px;height:30px;border-radius:50%;object-fit:cover;border:2px solid #ddd;">';
    }
    return '<span class="chat-avatar '.$f.'" style="display:inline-block;width:30px;height:30px;border-radius:50%;background:#ccc;text-align:center;line-height:30px;color:#fff;font-size:15px;border:2px solid #ddd;">'.htmlspecialchars(mb_substr($name,0,1)).'</span>';
}
function nameHtml($name, $color) {
    $c = $color ? htmlspecialchars($color) : '#0f6bff';
    return '<a href="user_view.php?name='.urlencode($name).'" class="user-name" style="color:'.$c.';">'.htmlspecialchars($name).'</a>';
}
function renderMsg($m, $roomId) {
    $html = '<div class="msg" data-msg-id="'.$m['id'].'">';
    $html .= avatarHtml($m['avatar'], $m['avatar_frame'], $m['user_name']);
    $html .= ' ' . nameHtml($m['user_name'], $m['name_color']);
    $html .= ' <span style="font-size:12px;color:#999;">'.htmlspecialchars($m['created_at']).'</span>';
    $html .= ' <a href="report.php?type=chat_message&id='.$m['id'].'" style="font-size:12px;color:#999;margin-left:8px;">举报</a>';
    if ($m['message_type'] === 'red_packet') {
        $extra = json_decode($m['extra_data'], true);
        $pid = $extra['packet_id'] ?? 0;
        $html .= '<div style="background:#ffe0e0;padding:5px 10px;display:inline-block;margin-top:5px;border-radius:6px;">💰 '.htmlspecialchars($m['content']).' ';
        if ($pid) $html .= '<a href="javascript:claimPacket('.$pid.')">领取红包</a>';
        $html .= '</div>';
    } else {
        if (!empty($m['content'])) $html .= '<div style="margin-top:4px;">'.nl2br(htmlspecialchars($m['content'])).'</div>';
        if (!empty($m['image_url'])) {
            $html .= '<a href="'.htmlspecialchars($m['image_url']).'" target="_blank"><img src="'.htmlspecialchars($m['image_url']).'" style="max-width:200px;max-height:200px;border-radius:6px;display:block;margin-top:5px;"></a>';
        }
    }
    $html .= '</div>';
    return $html;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($roomName); ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .chat-box {
            height: 480px;
            overflow-y: auto;
            border: 1px solid var(--border);
            background: #fff;
            border-radius: var(--radius);
            padding: 16px;
            margin-bottom: 18px;
            box-shadow: var(--shadow-sm);
        }
        .msg { margin-bottom: 12px; padding-bottom: 10px; border-bottom: 1px solid #f1f4f9; }
        .msg:last-child { border-bottom: none; }
        .toast { position:fixed; top:20px; left:50%; transform:translateX(-50%); background:#333; color:#fff; padding:10px 20px; border-radius:6px; font-size:14px; opacity:0; transition:opacity .3s; z-index:9999; }
        .toast.show { opacity:1; }
        .toast.error { background:var(--danger); }
        .toast.success { background:var(--success); }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1><?php echo htmlspecialchars($roomName); ?></h1>
    <p class="page-nav">
        <a href="chat_rooms.php" class="btn btn-secondary btn-sm">返回列表</a>
        <a href="user_index.php" class="btn btn-secondary btn-sm">首页</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <div id="chat-box" class="chat-box">
        <?php foreach ($messages as $m) echo renderMsg($m, $roomId); ?>
    </div>

    <div class="card">
        <textarea id="msgInput" placeholder="输入消息...（Enter 发送，Shift+Enter 换行）" rows="3"></textarea>
        <div class="flex mt-10">
            <input type="file" id="imgInput" accept="image/*" style="flex:1;min-width:200px;">
            <button id="sendBtn" class="btn">发送</button>
        </div>
    </div>

    <div class="card">
        <h3>发积分红包</h3>
        <div class="flex">
            <input type="number" id="packetPoints" placeholder="积分数量" min="1" style="max-width:200px;">
            <button id="packetBtn" class="btn btn-warning">发红包</button>
        </div>
    </div>

    <div id="toast" class="toast"></div>

<script>
(function(){
    var roomId = <?php echo $roomId; ?>;
    var lastId = <?php echo $lastId; ?>;
    var chatBox = document.getElementById('chat-box');
    var toastEl = document.getElementById('toast');
    var toastTimer;

    function toast(msg, type) {
        toastEl.textContent = msg;
        toastEl.className = 'toast show ' + (type || '');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function(){ toastEl.className = 'toast'; }, 2000);
    }

    function scrollBottom() {
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    window.addEventListener('load', scrollBottom);

    function appendMessage(m) {
        var div = document.createElement('div');
        div.className = 'msg';
        div.setAttribute('data-msg-id', m.id);
        var html = m.avatar_html + ' ' + m.name_html +
            ' <span style="font-size:12px;color:#999;">' + m.created_at + '</span>' +
            ' <a href="report.php?type=chat_message&id=' + m.id + '" style="font-size:12px;color:#999;margin-left:8px;">举报</a>';
        if (m.message_type === 'red_packet') {
            var extra = m.extra_data ? JSON.parse(m.extra_data) : {};
            var pid = extra.packet_id || 0;
            html += '<div style="background:#ffe0e0;padding:5px 10px;display:inline-block;margin-top:5px;border-radius:6px;">💰 ' + m.content + ' ';
            if (pid) html += '<a href="javascript:claimPacket(' + pid + ')">领取红包</a>';
            html += '</div>';
        } else {
            if (m.content) html += '<div style="margin-top:4px;">' + m.content + '</div>';
            if (m.image_url) html += '<a href="' + m.image_url + '" target="_blank"><img src="' + m.image_url + '" style="max-width:200px;max-height:200px;border-radius:6px;display:block;margin-top:5px;"></a>';
        }
        div.innerHTML = html;
        chatBox.appendChild(div);
        if (m.id > lastId) lastId = m.id;
    }

    var isLoading = false;
    function poll() {
        if (isLoading) return;
        isLoading = true;
        fetch('chat_room.php?ajax=1&id=' + roomId + '&last_id=' + lastId)
            .then(function(r){ return r.json(); })
            .then(function(data){
                isLoading = false;
                if (data.messages && data.messages.length) {
                    var atBottom = chatBox.scrollTop + chatBox.clientHeight >= chatBox.scrollHeight - 30;
                    data.messages.forEach(appendMessage);
                    if (atBottom) scrollBottom();
                }
            })
            .catch(function(){ isLoading = false; });
    }
    setInterval(poll, 2000);

    document.getElementById('sendBtn').addEventListener('click', function(){
        var btn = this;
        var content = document.getElementById('msgInput').value.trim();
        var imgFile = document.getElementById('imgInput').files[0];
        if (!content && !imgFile) { toast('请输入文字或选择图片', 'error'); return; }

        var fd = new FormData();
        fd.append('room_id', roomId);
        fd.append('content', content);
        if (imgFile) fd.append('image', imgFile);

        btn.disabled = true;
        fetch('chat_send.php', { method: 'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(res){
                btn.disabled = false;
                if (res.code === 0) {
                    document.getElementById('msgInput').value = '';
                    document.getElementById('imgInput').value = '';
                    toast(res.message || '发送成功', 'success');
                    poll();
                    scrollBottom();
                } else {
                    toast(res.message || '发送失败', 'error');
                }
            })
            .catch(function(){ btn.disabled = false; toast('网络错误', 'error'); });
    });

    document.getElementById('msgInput').addEventListener('keydown', function(e){
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            document.getElementById('sendBtn').click();
        }
    });

    document.getElementById('packetBtn').addEventListener('click', function(){
        var btn = this;
        var points = document.getElementById('packetPoints').value;
        if (!points || points <= 0) { toast('请输入积分', 'error'); return; }

        var fd = new FormData();
        fd.append('room_id', roomId);
        fd.append('action', 'packet');
        fd.append('points', points);

        btn.disabled = true;
        fetch('chat_send.php', { method: 'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(res){
                btn.disabled = false;
                if (res.code === 0) {
                    document.getElementById('packetPoints').value = '';
                    toast('红包已发送', 'success');
                    poll();
                    scrollBottom();
                } else {
                    toast(res.message || '发送失败', 'error');
                }
            })
            .catch(function(){ btn.disabled = false; toast('网络错误', 'error'); });
    });

    window.claimPacket = function(packetId) {
        fetch('chat_room.php?id=' + roomId + '&action=claim&packet_id=' + packetId)
            .then(function(r){ return r.json(); })
            .then(function(res){
                if (res.code === 0) {
                    toast('领取成功 +' + res.data.points + ' 积分', 'success');
                } else {
                    toast(res.message || '领取失败', 'error');
                }
            });
    };
})();
</script>
</body>
</html>