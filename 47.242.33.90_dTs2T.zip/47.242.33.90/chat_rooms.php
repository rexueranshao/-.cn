<?php
// =============================================
// 文件名：chat_rooms.php
// 用途：聊天室列表页
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$currentUserId = $_SESSION['user_id'] ?? 0;
$error = '';
$rooms = [];

try {
    $sql = "SELECT cr.id, cr.name,
                   (SELECT COUNT(*) FROM chat_messages cm 
                    WHERE cm.room_id = cr.id 
                    AND cm.id > COALESCE((SELECT last_read_message_id FROM chat_reads WHERE user_id = :uid AND room_id = cr.id), 0)
                   ) AS unread_count
            FROM chat_rooms cr
            ORDER BY cr.id ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':uid' => $currentUserId]);
    $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '聊天室查询失败，请稍后再试';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>聊天室列表</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .room-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 14px; }
        .room-item {
            position: relative;
            display: flex;
            align-items: center;
            padding: 18px 22px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            text-decoration: none;
            color: var(--text);
            font-weight: 500;
            font-size: 15px;
            transition: all .2s;
            box-shadow: var(--shadow-sm);
        }
        .room-item:hover { border-color: var(--accent); color: var(--accent); opacity: 1; text-decoration: none; transform: translateY(-2px); box-shadow: var(--shadow); }
        .room-item .badge-num {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--danger);
            color: #fff;
            border-radius: 10px;
            min-width: 20px;
            height: 20px;
            line-height: 20px;
            padding: 0 6px;
            font-size: 11px;
            font-weight: 700;
            text-align: center;
            border: 2px solid var(--bg);
        }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>聊天室</h1>
    <p class="page-nav">
        <a href="user_index.php" class="btn btn-secondary btn-sm">返回首页</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>

    <?php if (empty($rooms)): ?>
        <p class="text-mute">暂无聊天室</p>
    <?php else: ?>
        <div class="room-list">
            <?php foreach ($rooms as $room): ?>
                <a href="chat_room.php?id=<?php echo $room['id']; ?>" class="room-item">
                    <?php echo htmlspecialchars($room['name']); ?>
                    <?php if ($room['unread_count'] > 0): ?>
                        <span class="badge-num"><?php echo $room['unread_count'] > 99 ? '99+' : $room['unread_count']; ?></span>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</body>
</html>