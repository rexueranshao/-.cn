<?php
// =============================================
// 文件名：chat_send.php
// 用途：聊天室消息/红包发送接口（纯 JSON，无重定向）
// =============================================
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once 'config.php';
require_once 'ai_functions.php';
require_once 'upload_functions.php';

function json_out($code, $msg, $data = null) {
    echo json_encode(['code' => $code, 'message' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    json_out(401, '未登录');
}
$currentUser = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';

$roomId = isset($_POST['room_id']) ? intval($_POST['room_id']) : 0;
if ($roomId <= 0) json_out(400, '缺少房间ID');

// ---------- 发红包 ----------
if (isset($_POST['action']) && $_POST['action'] === 'packet') {
    $points = intval($_POST['points'] ?? 0);
    if ($points <= 0) json_out(400, '积分必须大于0');

    $stmt = $pdo->prepare("SELECT id, points FROM users WHERE name = :name");
    $stmt->execute([':name' => $currentUser]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) json_out(403, '用户不存在');
    if ($user['points'] < $points) json_out(400, '积分不足');

    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE users SET points = points - :p WHERE id = :id")
            ->execute([':p' => $points, ':id' => $user['id']]);
        $pdo->prepare("INSERT INTO red_packets (sender_id, room_id, total_points, status) VALUES (:s, :r, :p, 'active')")
            ->execute([':s' => $user['id'], ':r' => $roomId, ':p' => $points]);
        $packetId = $pdo->lastInsertId();
        $extra = json_encode(['packet_id' => $packetId]);
        $pdo->prepare("INSERT INTO chat_messages (room_id, user_name, content, message_type, extra_data, status) VALUES (:r, :u, :c, 'red_packet', :e, 'normal')")
            ->execute([':r' => $roomId, ':u' => $currentUser, ':c' => '发了一个积分红包', ':e' => $extra]);
        $pdo->commit();
        json_out(0, '红包发送成功', ['packet_id' => $packetId]);
    } catch (Exception $e) {
        $pdo->rollBack();
        json_out(500, '发送失败');
    }
}

// ---------- 发消息（文字 + 可选图片） ----------
$content = trim($_POST['content'] ?? '');
$imageUrl = '';

if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
    $up = handle_image_upload($_FILES['image'], 'chat');
    if (!$up['success']) json_out(400, $up['error']);
    $imageUrl = $up['url'];
}

if ($content === '' && $imageUrl === '') {
    json_out(400, '请输入文字或选择图片');
}

// AI 审核
$aiSafe = true; $aiReason = 'ok';
if ($content !== '') {
    $ai = ai_check_content($content);
    $aiSafe = $ai['safe'];
    $aiReason = $ai['reason'];
}

if (!$aiSafe) {
    $_SESSION['chat_reject_count'] = ($_SESSION['chat_reject_count'] ?? 0) + 1;
    if ($_SESSION['chat_reject_count'] < 2) {
        json_out(400, '文字可能违规：' . $aiReason . '（再试一次可提交人工复议）');
    }
    $_SESSION['chat_reject_count'] = 0;
    try {
        $pdo->prepare("INSERT INTO chat_messages (room_id, user_name, content, image_url, message_type, status, ai_safe, ai_reason) VALUES (:r, :u, :c, :i, 'text', 'pending_manual', 0, :ar)")
            ->execute([':r' => $roomId, ':u' => $currentUser, ':c' => $content, ':i' => $imageUrl, ':ar' => $aiReason]);
        json_out(0, '已提交人工复议，等待管理员审核', ['pending_manual' => true]);
    } catch (PDOException $e) {
        json_out(500, '写入失败');
    }
}

try {
    $pdo->prepare("INSERT INTO chat_messages (room_id, user_name, content, image_url, message_type, status, ai_safe, ai_reason) VALUES (:r, :u, :c, :i, 'text', 'normal', 1, :ar)")
        ->execute([':r' => $roomId, ':u' => $currentUser, ':c' => $content, ':i' => $imageUrl, ':ar' => $aiReason]);
    json_out(0, '发送成功', ['message_id' => $pdo->lastInsertId()]);
} catch (PDOException $e) {
    json_out(500, '写入失败');
}