<?php
// =============================================
// 文件名：cloud.php
// 用途：云盘主页（私人/公共空间分离，用户可移动/重命名）
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';
require_once 'config_oss.php';

$currentUser   = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$currentUserId = $_SESSION['user_id'] ?? 0;
$isAdmin       = isset($_SESSION['admin']);

$space = ($_GET['space'] ?? 'private') === 'public' ? 'public' : 'private';
$isPublicSpace = ($space === 'public');
$folderId = intval($_GET['folder'] ?? 0);

// 面包屑
$breadcrumb = [];
if ($folderId > 0) {
    $id = $folderId;
    $guard = 0;
    while ($id > 0 && $guard++ < 50) {
        $stmt = $pdo->prepare("SELECT id, original_name, parent_id, user_id, is_public, is_folder FROM cloud_files WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row || !$row['is_folder']) break;
        if ($isPublicSpace) {
            if (!$row['is_public']) break;
        } else {
            if ($row['is_public'] || (!$isAdmin && $row['user_id'] != $currentUserId)) {
                die('无权限访问该文件夹');
            }
        }
        array_unshift($breadcrumb, $row);
        $id = $row['parent_id'];
    }
}

// 全局统计
$stmt = $pdo->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(file_size),0) AS total FROM cloud_files WHERE is_folder = 0");
$globalStats = $stmt->fetch(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT COUNT(*) AS cnt, COALESCE(SUM(file_size),0) AS total FROM cloud_files WHERE user_id = :uid AND is_folder = 0");
$stmt->execute([':uid' => $currentUserId]);
$myStats = $stmt->fetch(PDO::FETCH_ASSOC);

$userUsages = $pdo->query("
    SELECT user_name, SUM(file_size) AS total, COUNT(*) AS cnt 
    FROM cloud_files WHERE is_folder = 0 
    GROUP BY user_name ORDER BY total DESC
")->fetchAll(PDO::FETCH_ASSOC);
$totalCloudSize = (int)$globalStats['total'];

// 动态刻度
$GB = 1024 * 1024 * 1024;
$maxUsed = 0;
foreach ($userUsages as $u) if ((int)$u['total'] > $maxUsed) $maxUsed = (int)$u['total'];
$scaleOptions = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000];
$scaleGB = 10000;
foreach ($scaleOptions as $opt) {
    if ($maxUsed <= $opt * $GB * 0.8) { $scaleGB = $opt; break; }
}
$scaleBytes = $scaleGB * $GB;
foreach ($userUsages as &$u) {
    $u['height_pct'] = $scaleBytes > 0 ? min(100, $u['total'] / $scaleBytes * 100) : 0;
    $u['share_pct']  = $totalCloudSize > 0 ? $u['total'] / $totalCloudSize * 100 : 0;
}
unset($u);

function scaleLabel($gb) { return $gb >= 1000 ? ($gb / 1000) . ' TB' : $gb . ' GB'; }
$palette = ['#0f6bff', '#00b894', '#e67e22', '#9b59b6', '#1abc9c', '#e74c3c', '#3498db', '#f39c12', '#2ecc71', '#e84393', '#16a085', '#d35400'];

// 当前目录内容
if ($isPublicSpace) {
    $stmt = $pdo->prepare("SELECT id, user_id, user_name, original_name, file_size, is_folder, parent_id, is_public, created_at FROM cloud_files WHERE parent_id = :pid AND is_public = 1 ORDER BY is_folder DESC, id DESC LIMIT 1000");
    $stmt->execute([':pid' => $folderId]);
} else {
    if ($isAdmin) {
        $stmt = $pdo->prepare("SELECT id, user_id, user_name, original_name, file_size, is_folder, parent_id, is_public, created_at FROM cloud_files WHERE parent_id = :pid AND is_public = 0 ORDER BY is_folder DESC, id DESC LIMIT 1000");
        $stmt->execute([':pid' => $folderId]);
    } else {
        $stmt = $pdo->prepare("SELECT id, user_id, user_name, original_name, file_size, is_folder, parent_id, is_public, created_at FROM cloud_files WHERE parent_id = :pid AND is_public = 0 AND user_id = :uid ORDER BY is_folder DESC, id DESC LIMIT 1000");
        $stmt->execute([':pid' => $folderId, ':uid' => $currentUserId]);
    }
}
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 目标文件夹
function collectUserFolders($pdo, $userId, $isPublic, $pid = 0, $prefix = '') {
    $result = [];
    if ($isPublic) {
        $stmt = $pdo->prepare("SELECT id, original_name FROM cloud_files WHERE is_folder = 1 AND is_public = 1 AND parent_id = :pid ORDER BY id ASC");
        $stmt->execute([':pid' => $pid]);
    } else {
        $stmt = $pdo->prepare("SELECT id, original_name FROM cloud_files WHERE is_folder = 1 AND is_public = 0 AND user_id = :uid AND parent_id = :pid ORDER BY id ASC");
        $stmt->execute([':uid' => $userId, ':pid' => $pid]);
    }
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $result[] = ['id' => $row['id'], 'label' => $prefix . $row['original_name']];
        $result = array_merge($result, collectUserFolders($pdo, $userId, $isPublic, $row['id'], $prefix . '　'));
    }
    return $result;
}
$allFolders = collectUserFolders($pdo, $currentUserId, $isPublicSpace);

function formatBytes($bytes, $precision = 2) {
    if ($bytes <= 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    $i = floor(log($bytes, 1024));
    if ($i >= count($units)) $i = count($units) - 1;
    return round($bytes / pow(1024, $i), $precision) . ' ' . $units[$i];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>云盘</title>
<link rel="stylesheet" href="style.css">
<style>
    .disk-panel { display: flex; gap: 40px; align-items: flex-start; background: #fff; border: 1px solid var(--border); border-radius: var(--radius); padding: 24px 28px; margin-bottom: 22px; box-shadow: var(--shadow-sm); }
    .cylinder-wrap { display: flex; align-items: stretch; gap: 12px; flex: 0 0 auto; }
    .cylinder { position: relative; width: 100px; height: 320px; }
    .cyl-shadow { position: absolute; bottom: -12px; left: -10px; right: -10px; height: 20px; background: radial-gradient(ellipse at center, rgba(20,32,60,.18), transparent 70%); filter: blur(4px); z-index: 0; pointer-events: none; }
    .cyl-body { position: absolute; top: 14px; bottom: 14px; left: 0; right: 0; background: #eef1f6; border-radius: 0 0 50px 50px / 0 0 12px 12px; overflow: hidden; box-shadow: inset 0 0 12px rgba(0,0,0,.06); z-index: 1; }
    .cyl-body::before { content: ""; position: absolute; top: 0; bottom: 0; left: 0; width: 30%; background: linear-gradient(90deg, rgba(0,0,0,.08), transparent); pointer-events: none; z-index: 3; }
    .cyl-body::after { content: ""; position: absolute; top: 0; bottom: 0; right: 0; width: 20%; background: linear-gradient(270deg, rgba(255,255,255,.4), transparent); pointer-events: none; z-index: 3; }
    .cyl-fill { position: absolute; bottom: 0; left: 0; right: 0; display: flex; flex-direction: column-reverse; z-index: 2; }
    .cyl-fill .seg { width: 100%; position: relative; transition: filter .2s; box-shadow: inset 0 1px 0 rgba(255,255,255,.5); }
    .cyl-fill .seg:hover { filter: brightness(1.15); }
    .cyl-fill .seg::after { content: ""; position: absolute; inset: 0; background: linear-gradient(90deg, rgba(0,0,0,.16), transparent 30%, rgba(255,255,255,.2) 75%, rgba(0,0,0,.1)); pointer-events: none; }
    .cyl-top { position: absolute; top: 0; left: 0; right: 0; height: 26px; background: linear-gradient(180deg, #f8fafc, #dde4ee); border-radius: 50%; z-index: 4; box-shadow: inset 0 -3px 6px rgba(0,0,0,.08); }
    .cyl-bottom { position: absolute; bottom: 0; left: 0; right: 0; height: 26px; background: linear-gradient(0deg, #c9d1dc, #d9dfe8); border-radius: 50%; z-index: 0; box-shadow: inset 0 3px 6px rgba(0,0,0,.1); }
    .cyl-empty-tip { position: absolute; top: 50%; left: 0; right: 0; text-align: center; transform: translateY(-50%); color: #b8c0cc; font-size: 12px; z-index: 5; }
    .scale-rail { display: flex; flex-direction: column; justify-content: space-between; padding: 14px 0; font-size: 11px; color: var(--text-mute); height: 320px; font-family: "SF Mono", Consolas, monospace; }
    .scale-rail span { display: flex; align-items: center; gap: 6px; }
    .scale-rail span::before { content: ""; display: inline-block; width: 10px; height: 1px; background: #cbd3df; }
    .legend-panel { flex: 1; min-width: 0; }
    .legend-section { margin-bottom: 20px; }
    .legend-section h3 { font-size: 14px; color: var(--text-light); margin: 0 0 10px; font-weight: 700; }
    .legend-row { display: flex; align-items: center; gap: 10px; padding: 6px 0; font-size: 13.5px; border-bottom: 1px dashed #eef1f6; }
    .legend-row:last-child { border-bottom: none; }
    .legend-row .swatch { width: 14px; height: 14px; border-radius: 4px; flex: none; box-shadow: 0 1px 2px rgba(0,0,0,.08); }
    .legend-row .name { flex: 1; color: var(--text); font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .legend-row .value { font-family: "SF Mono", Consolas, monospace; color: var(--text-light); font-size: 12.5px; }
    .legend-row .pct { color: var(--text-mute); font-size: 12px; min-width: 56px; text-align: right; }
    .legend-row.total { font-weight: 700; padding-top: 10px; border-top: 1px solid var(--border); }
    .legend-row.total .name { color: var(--accent); }
    .legend-row.total .value { color: var(--accent); }

    .space-tabs { display: flex; gap: 0; background: #fff; border: 1px solid var(--border); border-radius: var(--radius); padding: 5px; margin-bottom: 16px; width: fit-content; box-shadow: var(--shadow-sm); }
    .space-tab { display: inline-flex; align-items: center; gap: 8px; padding: 9px 24px; font-size: 14px; font-weight: 600; color: var(--text-light); text-decoration: none; border-radius: 6px; transition: all .2s; }
    .space-tab:hover { color: var(--accent); background: var(--accent-soft); opacity: 1; text-decoration: none; }
    .space-tab.active { color: #fff; background: linear-gradient(135deg, #4b8dff, #0f6bff); box-shadow: 0 4px 12px rgba(15,107,255,.3); }
    .space-tab svg { width: 16px; height: 16px; }

    .progress-wrap { width: 100%; margin-top: 12px; display: none; }
    .progress-info { display: flex; justify-content: space-between; font-size: 13px; color: var(--text-light); margin-bottom: 6px; }
    .progress-bar { width: 100%; height: 10px; background: #e6ecf5; border-radius: 6px; overflow: hidden; }
    .progress-fill { width: 0%; height: 100%; border-radius: 6px; background: linear-gradient(90deg, #4b8dff, #0f6bff); background-size: 40px 100%; animation: stripe 1s linear infinite; transition: width .15s ease; }
    @keyframes stripe { 0% { background-position: 0 0; } 100% { background-position: 40px 0; } }
    .progress-fill.done { background: linear-gradient(90deg, #00b894, #159a52); animation: none; }
    .progress-fill.error { background: linear-gradient(90deg, #ff6b6b, #d63031); animation: none; }
    .progress-detail { display: flex; justify-content: space-between; font-size: 12px; color: var(--text-mute); margin-top: 6px; }

    .toolbar { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; background: #f5f8ff; border: 1px dashed #93b8ff; border-radius: var(--radius); padding: 14px 18px; margin-bottom: 16px; }

    .modal-mask { display: none; position: fixed; inset: 0; background: rgba(15,23,42,.5); z-index: 1000; align-items: center; justify-content: center; }
    .modal-mask.show { display: flex; }
    .modal { background: #fff; border-radius: 12px; padding: 22px 26px; width: 480px; max-width: calc(100vw - 40px); box-shadow: 0 20px 60px rgba(15,23,42,.3); }
    .modal h3 { margin: 0 0 14px; }
    .modal input[type="text"] { width: 100%; padding: 10px 12px; }
    .modal select { width: 100%; }
    .modal .actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; }
    .modal .hint { font-size: 12px; color: var(--text-mute); margin-top: 8px; }

    @media (max-width: 720px) {
        .disk-panel { flex-direction: column; align-items: center; gap: 20px; }
        .legend-panel { width: 100%; }
    }
</style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>云盘</h1>
    <p class="page-nav">
        <a href="user_index.php" class="btn btn-secondary btn-sm">返回首页</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <div class="disk-panel">
        <div class="cylinder-wrap">
            <div class="cylinder">
                <div class="cyl-shadow"></div>
                <div class="cyl-body">
                    <?php if (empty($userUsages)): ?>
                        <div class="cyl-empty-tip">暂无文件</div>
                    <?php else: ?>
                        <div class="cyl-fill" style="height:100%;">
                            <?php
                            $revUsages = array_reverse($userUsages);
                            foreach ($revUsages as $i => $u):
                                $idx = count($userUsages) - 1 - $i;
                                $h = $u['height_pct'];
                                if ($h > 0 && $h < 0.3) $h = 0.3;
                                $color = $palette[$idx % count($palette)];
                            ?>
                                <div class="seg" style="height:<?php echo $h; ?>%; background:<?php echo $color; ?>;"
                                     title="<?php echo htmlspecialchars($u['user_name']); ?>：<?php echo formatBytes($u['total']); ?>（占总 <?php echo round($u['share_pct'], 1); ?>%）"></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="cyl-top"></div>
                <div class="cyl-bottom"></div>
            </div>
            <div class="scale-rail">
                <span><?php echo scaleLabel($scaleGB); ?></span>
                <span><?php echo scaleLabel($scaleGB * 0.75); ?></span>
                <span><?php echo scaleLabel($scaleGB * 0.5); ?></span>
                <span><?php echo scaleLabel($scaleGB * 0.25); ?></span>
                <span>0</span>
            </div>
        </div>

        <div class="legend-panel">
            <div class="legend-section">
                <h3>云盘概况</h3>
                <div class="legend-row">
                    <span class="swatch" style="background:var(--accent);"></span>
                    <span class="name">云盘总占用</span>
                    <span class="value"><?php echo formatBytes($totalCloudSize); ?></span>
                    <span class="pct">无上限</span>
                </div>
                <div class="legend-row">
                    <span class="swatch" style="background:#eef1f6;border:1px solid #d8dfe8;"></span>
                    <span class="name">当前刻度</span>
                    <span class="value">0 ~ <?php echo scaleLabel($scaleGB); ?></span>
                    <span class="pct">满柱</span>
                </div>
                <div class="legend-row total">
                    <span class="swatch" style="background:var(--success);"></span>
                    <span class="name">我的占用</span>
                    <span class="value"><?php echo formatBytes($myStats['total']); ?></span>
                    <span class="pct"><?php echo (int)$myStats['cnt']; ?> 个</span>
                </div>
                <p class="text-mute mt-10">刻度会自动适配最大用户的占用。</p>
            </div>

            <div class="legend-section">
                <h3>各用户占用</h3>
                <?php if (empty($userUsages)): ?>
                    <p class="text-mute">暂无文件</p>
                <?php else: ?>
                    <?php foreach ($userUsages as $i => $u):
                        $color = $palette[$i % count($palette)];
                    ?>
                        <div class="legend-row">
                            <span class="swatch" style="background:<?php echo $color; ?>;"></span>
                            <span class="name"><?php echo htmlspecialchars($u['user_name']); ?></span>
                            <span class="value"><?php echo formatBytes($u['total']); ?></span>
                            <span class="pct"><?php echo round($u['share_pct'], 1); ?>%</span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="space-tabs">
        <a href="cloud.php?space=private" class="space-tab <?php echo !$isPublicSpace ? 'active' : ''; ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            私人空间
        </a>
        <a href="cloud.php?space=public" class="space-tab <?php echo $isPublicSpace ? 'active' : ''; ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
            公共空间
        </a>
    </div>

    <div class="card" style="padding:12px 18px;">
        <a href="cloud.php?space=<?php echo $space; ?>" class="btn btn-sm btn-outline"><?php echo $isPublicSpace ? '公共空间' : '私人空间'; ?></a>
        <?php foreach ($breadcrumb as $b): ?>
            <span style="color:#cbd3df;margin:0 6px;">/</span>
            <a href="cloud.php?space=<?php echo $space; ?>&folder=<?php echo $b['id']; ?>" class="btn btn-sm btn-outline"><?php echo htmlspecialchars($b['original_name']); ?></a>
        <?php endforeach; ?>
        <?php if ($folderId > 0): ?>
            <span style="color:#cbd3df;margin:0 6px;">/</span>
            <span class="text-mute">当前目录</span>
        <?php endif; ?>
    </div>

    <div class="toolbar">
        <input type="file" id="uploadFile" style="flex:1;min-width:200px;padding:6px;border:1px solid var(--border-strong);border-radius:6px;background:#fff;">
        <button type="button" id="uploadBtn" class="btn">上传到<?php echo $isPublicSpace ? '公共' : '私人'; ?>空间</button>
        <button type="button" id="newFolderBtn" class="btn btn-secondary">新建文件夹</button>
        <span class="text-mute" style="margin-left:auto;">OSS 分片上传，支持断点续传</span>

        <div class="progress-wrap" id="progressWrap">
            <div class="progress-info">
                <span id="progressName">--</span>
                <span id="progressPct">0%</span>
            </div>
            <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
            <div class="progress-detail">
                <span id="progressSize">0 B / 0 B</span>
                <span id="progressSpeed">0 B/s</span>
                <span id="progressEta">--</span>
            </div>
        </div>
    </div>

    <div class="card" style="padding:0;overflow:hidden;">
        <?php if (empty($items)): ?>
            <div style="padding:40px;text-align:center;color:var(--text-mute);">当前目录为空</div>
        <?php else: ?>
            <table>
                <tr>
                    <th style="width:40%;">名称</th>
                    <th style="width:10%;">大小</th>
                    <th style="width:10%;">上传者</th>
                    <th style="width:9%;">类型</th>
                    <th style="width:13%;">时间</th>
                    <th>操作</th>
                </tr>
                <?php foreach ($items as $it): ?>
                    <tr>
                        <td>
                            <?php if ($it['is_folder']): ?>
                                <a href="cloud.php?space=<?php echo $space; ?>&folder=<?php echo $it['id']; ?>" style="display:flex;align-items:center;gap:8px;font-weight:600;">
                                    📁 <?php echo htmlspecialchars($it['original_name']); ?>
                                </a>
                            <?php else: ?>
                                <span style="display:flex;align-items:center;gap:8px;">
                                    📄 <?php echo htmlspecialchars($it['original_name']); ?>
                                </span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $it['is_folder'] ? '-' : formatBytes($it['file_size']); ?></td>
                        <td><?php echo htmlspecialchars($it['user_name']); ?></td>
                        <td>
                            <?php if ($it['is_folder']): ?>
                                <span class="badge badge-folder">文件夹</span>
                            <?php elseif ($it['is_public']): ?>
                                <span class="badge badge-public">公共</span>
                            <?php else: ?>
                                <span class="badge badge-private">私人</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($it['created_at']); ?></td>
                        <td>
                            <?php if (!$it['is_folder']): ?>
                                <a href="cloud_download.php?id=<?php echo $it['id']; ?>" class="btn btn-sm btn-success">下载</a>
                            <?php endif; ?>
                            <?php if ($isAdmin || $it['user_id'] == $currentUserId): ?>
                                <button type="button" class="btn btn-sm btn-warning" onclick="togglePublic(<?php echo $it['id']; ?>, <?php echo $it['is_public']; ?>, <?php echo $it['is_folder']; ?>)">
                                    <?php echo $it['is_public'] ? '转私人' : '转公共'; ?>
                                </button>
                                <button type="button" class="btn btn-sm" onclick="moveItem(<?php echo $it['id']; ?>, '<?php echo htmlspecialchars(addslashes($it['original_name'])); ?>', <?php echo $it['is_folder']; ?>)">移动</button>
                                <button type="button" class="btn btn-sm btn-purple" onclick="renameItem(<?php echo $it['id']; ?>, '<?php echo htmlspecialchars(addslashes($it['original_name'])); ?>')">重命名</button>
                                <button type="button" class="btn btn-sm btn-danger" onclick="deleteItem(<?php echo $it['id']; ?>, <?php echo $it['is_folder']; ?>)">删除</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>

    <div class="modal-mask" id="moveModal">
        <div class="modal">
            <h3>移动到…</h3>
            <p class="text-mute" id="moveItemName" style="margin:0 0 12px;"></p>
            <select id="moveTarget">
                <option value="0">— 当前空间根目录 —</option>
                <?php foreach ($allFolders as $f): ?>
                    <option value="<?php echo $f['id']; ?>"><?php echo htmlspecialchars($f['label']); ?></option>
                <?php endforeach; ?>
            </select>
            <div class="actions">
                <button type="button" class="btn btn-secondary" onclick="closeMoveModal()">取消</button>
                <button type="button" class="btn" onclick="confirmMove()">确认移动</button>
            </div>
        </div>
    </div>

    <div class="modal-mask" id="renameModal">
        <div class="modal">
            <h3>重命名</h3>
            <p class="text-mute" id="renameItemName" style="margin:0 0 12px;"></p>
            <input type="text" id="renameInput" maxlength="200" placeholder="请输入新名称">
            <p class="hint">名称不能包含 <code>/</code>，长度不超过 200 字</p>
            <div class="actions">
                <button type="button" class="btn btn-secondary" onclick="closeRenameModal()">取消</button>
                <button type="button" class="btn" onclick="confirmRename()">确认重命名</button>
            </div>
        </div>
    </div>

<script>
(function(){
    var CHUNK_SIZE = 10 * 1024 * 1024;
    var folderId = <?php echo $folderId; ?>;
    var isPublicSpace = <?php echo $isPublicSpace ? '1' : '0'; ?>;
    var spaceName = '<?php echo $space; ?>';
    var moveId = 0;
    var renameId = 0;

    var fileInput = document.getElementById('uploadFile');
    var uploadBtn = document.getElementById('uploadBtn');
    var newFolderBtn = document.getElementById('newFolderBtn');
    var progWrap = document.getElementById('progressWrap');
    var progFill = document.getElementById('progressFill');
    var progPct = document.getElementById('progressPct');
    var progName = document.getElementById('progressName');
    var progSize = document.getElementById('progressSize');
    var progSpeed = document.getElementById('progressSpeed');
    var progEta = document.getElementById('progressEta');

    function formatBytes(b, p) {
        if (b <= 0) return '0 B';
        p = p === undefined ? 2 : p;
        var u = ['B', 'KB', 'MB', 'GB', 'TB'], i = Math.floor(Math.log(b) / Math.log(1024));
        if (i >= u.length) i = u.length - 1;
        return (b / Math.pow(1024, i)).toFixed(p) + ' ' + u[i];
    }
    function formatEta(s) {
        if (!isFinite(s) || s <= 0) return '--';
        if (s < 60) return Math.ceil(s) + ' 秒';
        if (s < 3600) return Math.ceil(s / 60) + ' 分钟';
        return (s / 3600).toFixed(1) + ' 小时';
    }
    function post(url, data) {
        var body = new URLSearchParams(data).toString();
        return fetch(url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: body
        }).then(function(r) { return r.json(); });
    }

    uploadBtn.addEventListener('click', function(){
        var file = fileInput.files[0];
        if (!file) { alert('请选择文件'); return; }
        uploadBtn.disabled = true;
        uploadBtn.textContent = '上传中…';
        progWrap.style.display = 'block';
        progFill.className = 'progress-fill';
        progFill.style.width = '0%';
        progPct.textContent = '0%';
        progName.textContent = file.name;
        progSize.textContent = '0 B / ' + formatBytes(file.size);
        progSpeed.textContent = '0 B/s';
        progEta.textContent = '--';

        doUpload(file, isPublicSpace).then(function(){
            progFill.classList.add('done');
            progFill.style.width = '100%';
            progPct.textContent = '100%';
            progEta.textContent = '完成';
            setTimeout(function(){ location.reload(); }, 800);
        }).catch(function(err){
            progFill.classList.add('error');
            alert('上传失败：' + err.message);
            uploadBtn.disabled = false;
            uploadBtn.textContent = '上传到' + (isPublicSpace ? '公共' : '私人') + '空间';
        });
    });

    function doUpload(file, isPublic) {
        var totalChunks = Math.ceil(file.size / CHUNK_SIZE);
        var uploadId, objectKey, fileId;
        return post('cloud_api.php?action=init_upload', {
            file_name: file.name, file_size: file.size, total_chunks: totalChunks,
            parent_id: folderId, is_public: isPublic ? 1 : 0
        }).then(function(res){
            if (res.code !== 0) throw new Error(res.message);
            uploadId = res.data.upload_id;
            objectKey = res.data.object_key;
            fileId = res.data.file_id;
            return fetch('cloud_api.php?action=list_parts&upload_id=' + encodeURIComponent(uploadId) + '&object_key=' + encodeURIComponent(objectKey)).then(function(r){ return r.json(); });
        }).then(function(res){
            var existMap = {};
            if (res.code === 0 && res.data.parts) res.data.parts.forEach(function(p){ existMap[p.part_number] = p.etag; });
            var etags = [];
            var uploadedBytes = 0, lastTime = Date.now(), lastBytes = 0;
            var chain = Promise.resolve();
            for (var i = 1; i <= totalChunks; i++) {
                (function(partNumber){
                    chain = chain.then(function(){
                        if (existMap[partNumber]) {
                            etags.push({part_number: partNumber, etag: existMap[partNumber]});
                            uploadedBytes += Math.min(CHUNK_SIZE, file.size - (partNumber - 1) * CHUNK_SIZE);
                            updateProgress(); return;
                        }
                        var start = (partNumber - 1) * CHUNK_SIZE;
                        var end = Math.min(start + CHUNK_SIZE, file.size);
                        var chunk = file.slice(start, end);
                        return uploadChunk(chunk, partNumber, uploadId, objectKey).then(function(resp){
                            if (resp.code !== 0) throw new Error(resp.message || '分片上传失败');
                            etags.push({part_number: partNumber, etag: resp.data.etag});
                            uploadedBytes += chunk.size;
                            updateProgress();
                        });
                    });
                })(i);
            }
            function updateProgress() {
                var pct = uploadedBytes / file.size * 100;
                progFill.style.width = pct.toFixed(1) + '%';
                progPct.textContent = pct.toFixed(1) + '%';
                progSize.textContent = formatBytes(uploadedBytes) + ' / ' + formatBytes(file.size);
                var now = Date.now();
                if (now - lastTime > 500) {
                    var sp = (uploadedBytes - lastBytes) / ((now - lastTime) / 1000);
                    lastTime = now; lastBytes = uploadedBytes;
                    progSpeed.textContent = formatBytes(sp, 1) + '/s';
                    if (sp > 0) progEta.textContent = '剩余 ' + formatEta((file.size - uploadedBytes) / sp);
                }
            }
            return chain.then(function(){
                return post('cloud_api.php?action=complete_upload', {
                    upload_id: uploadId, object_key: objectKey, file_id: fileId, parts: JSON.stringify(etags)
                });
            }).then(function(res){ if (res.code !== 0) throw new Error(res.message); });
        });
    }

    function uploadChunk(chunk, partNumber, uploadId, objectKey) {
        return new Promise(function(resolve, reject){
            var fd = new FormData();
            fd.append('chunk', chunk);
            fd.append('upload_id', uploadId);
            fd.append('object_key', objectKey);
            fd.append('part_number', partNumber);
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'cloud_api.php?action=upload_part', true);
            xhr.onload = function(){ try { resolve(JSON.parse(xhr.responseText)); } catch(e) { reject(new Error('服务器返回异常')); } };
            xhr.onerror = function(){ reject(new Error('网络错误')); };
            xhr.send(fd);
        });
    }

    newFolderBtn.addEventListener('click', function(){
        var name = prompt('请输入文件夹名称：');
        if (!name) return;
        post('cloud_api.php?action=create_folder', {
            name: name, parent_id: folderId, is_public: isPublicSpace ? 1 : 0
        }).then(function(res){
            if (res.code === 0) location.reload(); else alert(res.message);
        });
    });

    window.togglePublic = function(id, currentPublic, isFolder) {
        var toPublic = !currentPublic;
        var msg = toPublic ? (isFolder ? '确定将该文件夹及内部所有内容设为公共？' : '确定将该文件设为公共？') : (isFolder ? '确定将该文件夹及内部所有内容设为私人？' : '确定将该文件设为私人？');
        if (!confirm(msg)) return;
        post('cloud_api.php?action=toggle_public', { id: id }).then(function(res){
            if (res.code === 0) location.reload(); else alert(res.message);
        });
    };

    window.moveItem = function(id, name, isFolder) {
        moveId = id;
        document.getElementById('moveItemName').textContent = (isFolder ? '📁 ' : '📄 ') + name;
        document.getElementById('moveTarget').value = '0';
        document.getElementById('moveModal').classList.add('show');
    };
    window.closeMoveModal = function() {
        document.getElementById('moveModal').classList.remove('show');
        moveId = 0;
    };
    window.confirmMove = function() {
        var target = document.getElementById('moveTarget').value;
        if (moveId <= 0) return;
        post('cloud_api.php?action=move', { id: moveId, target_folder_id: target, space: spaceName }).then(function(res){
            if (res.code === 0) { closeMoveModal(); location.reload(); }
            else alert(res.message);
        });
    };

    window.renameItem = function(id, oldName) {
        renameId = id;
        document.getElementById('renameItemName').textContent = '原名：' + oldName;
        var input = document.getElementById('renameInput');
        input.value = oldName;
        document.getElementById('renameModal').classList.add('show');
        setTimeout(function(){ input.focus(); input.select(); }, 50);
    };
    window.closeRenameModal = function() {
        document.getElementById('renameModal').classList.remove('show');
        renameId = 0;
    };
    window.confirmRename = function() {
        var name = document.getElementById('renameInput').value.trim();
        if (!name) { alert('请输入新名称'); return; }
        if (name.indexOf('/') !== -1) { alert('名称不能包含 /'); return; }
        if (name.length > 200) { alert('名称不能超过 200 字'); return; }
        if (renameId <= 0) return;
        post('cloud_api.php?action=rename', { id: renameId, name: name }).then(function(res){
            if (res.code === 0) { closeRenameModal(); location.reload(); }
            else alert(res.message);
        });
    };
    document.getElementById('renameInput').addEventListener('keydown', function(e){
        if (e.key === 'Enter') { e.preventDefault(); confirmRename(); }
        if (e.key === 'Escape') { closeRenameModal(); }
    });

    window.deleteItem = function(id, isFolder) {
        var msg = isFolder ? '确定删除该文件夹及里面所有内容？' : '确定删除该文件？';
        if (!confirm(msg)) return;
        post('cloud_api.php?action=delete', { id: id }).then(function(res){
            if (res.code === 0) location.reload(); else alert(res.message);
        });
    };
})();
</script>
</body>
</html>