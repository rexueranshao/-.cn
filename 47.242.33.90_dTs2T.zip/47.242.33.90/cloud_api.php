<?php
// =============================================
// 文件名：cloud_api.php
// 用途：云盘所有 AJAX 接口（OSS 版）
// =============================================
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once 'config.php';
require_once 'config_oss.php';

use OSS\Core\OssException;
use OSS\OssClient;

function json_out($code, $msg, $data = null) {
    while (ob_get_level()) @ob_end_clean();
    echo json_encode(['code' => $code, 'message' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    json_out(401, '未登录');
}

$currentUser   = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$currentUserId = $_SESSION['user_id'] ?? 0;
$isAdmin       = isset($_SESSION['admin']);
$action        = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    $ossClient = getOssClient();
    $bucket    = getBucketName();
} catch (Exception $e) {
    json_out(500, 'OSS 初始化失败：' . $e->getMessage());
}

switch ($action) {

case 'init_upload':
    $originalName = basename($_POST['file_name'] ?? '');
    $fileSize     = intval($_POST['file_size'] ?? 0);
    $isPublic     = (isset($_POST['is_public']) && $_POST['is_public'] == '1') ? 1 : 0;
    $parentId     = intval($_POST['parent_id'] ?? 0);

    if ($originalName === '' || $fileSize <= 0) json_out(400, '参数缺失');

    $ext        = pathinfo($originalName, PATHINFO_EXTENSION);
    $storedName = md5(uniqid('', true) . $originalName . microtime(true)) . ($ext ? '.' . strtolower($ext) : '');
    $objectKey  = 'cloud/' . date('Y/m/') . $storedName;

    try {
        $uploadId = $ossClient->initiateMultipartUpload($bucket, $objectKey);
    } catch (OssException $e) {
        json_out(500, 'OSS 初始化失败：' . $e->getMessage());
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO cloud_files (user_id, user_name, original_name, stored_path, file_size, file_type, is_folder, parent_id, is_public) VALUES (:uid, :un, :on, :sp, :sz, '', 0, :pid, :ip)");
        $stmt->execute([
            ':uid' => $currentUserId, ':un' => $currentUser,
            ':on'  => $originalName, ':sp' => $objectKey, ':sz' => $fileSize,
            ':pid' => $parentId, ':ip' => $isPublic,
        ]);
        $fileId = $pdo->lastInsertId();
    } catch (PDOException $e) {
        try { $ossClient->abortMultipartUpload($bucket, $objectKey, $uploadId); } catch (Exception $e2) {}
        json_out(500, '数据库写入失败：' . $e->getMessage());
    }

    json_out(0, '初始化成功', [
        'upload_id' => $uploadId, 'object_key' => $objectKey, 'file_id' => $fileId,
    ]);
    break;

case 'upload_part':
    $uploadId   = $_POST['upload_id'] ?? '';
    $objectKey  = $_POST['object_key'] ?? '';
    $partNumber = intval($_POST['part_number'] ?? 0);

    if ($uploadId === '' || $objectKey === '' || $partNumber < 1 || $partNumber > 10000) json_out(400, '参数缺失');
    if (!isset($_FILES['chunk']) || $_FILES['chunk']['error'] !== UPLOAD_ERR_OK) json_out(400, '分片接收失败');

    $tmpFile = $_FILES['chunk']['tmp_name'];

    try {
        $result = $ossClient->uploadPart($bucket, $objectKey, $uploadId, [
            OssClient::OSS_FILE_UPLOAD => $tmpFile,
            OssClient::OSS_PART_NUM    => $partNumber,
        ]);
        $etag = '';
        if (is_array($result)) $etag = $result['etag'] ?? ($result['ETag'] ?? '');
        elseif (is_object($result) && method_exists($result, 'getETag')) $etag = $result->getETag();
        elseif (is_string($result)) $etag = $result;
    } catch (OssException $e) {
        json_out(500, '上传分片失败：' . $e->getMessage());
    }

    json_out(0, 'ok', ['part_number' => $partNumber, 'etag' => $etag]);
    break;

case 'list_parts':
    $uploadId  = $_GET['upload_id'] ?? '';
    $objectKey = $_GET['object_key'] ?? '';
    if ($uploadId === '' || $objectKey === '') json_out(400, '参数缺失');

    try {
        $result = $ossClient->listParts($bucket, $objectKey, $uploadId);
        $parts  = [];
        if (is_object($result) && method_exists($result, 'getParts')) {
            foreach ($result->getParts() as $p) {
                $parts[] = ['part_number' => intval($p->getPartNumber()), 'etag' => $p->getETag()];
            }
        }
    } catch (OssException $e) {
        json_out(500, '获取分片列表失败：' . $e->getMessage());
    }

    json_out(0, 'ok', ['parts' => $parts]);
    break;

case 'complete_upload':
    $uploadId  = $_POST['upload_id'] ?? '';
    $objectKey = $_POST['object_key'] ?? '';
    $fileId    = intval($_POST['file_id'] ?? 0);
    $partsJson = $_POST['parts'] ?? '[]';

    if ($uploadId === '' || $objectKey === '' || $fileId <= 0) json_out(400, '参数缺失');

    $parts = json_decode($partsJson, true);
    if (!is_array($parts) || empty($parts)) json_out(400, '分片列表为空');

    usort($parts, function($a, $b) { return intval($a['part_number']) - intval($b['part_number']); });

    $uploadParts = [];
    foreach ($parts as $p) {
        $etag = trim((string)$p['etag']);
        if ($etag === '') json_out(400, '分片 ' . $p['part_number'] . ' 缺少 ETag');
        if ($etag[0] !== '"') $etag = '"' . $etag . '"';
        $uploadParts[] = ['PartNumber' => intval($p['part_number']), 'ETag' => $etag];
    }

    try {
        $ossClient->completeMultipartUpload($bucket, $objectKey, $uploadId, $uploadParts);
    } catch (OssException $e) {
        $pdo->prepare("DELETE FROM cloud_files WHERE id = :id AND user_id = :uid")
            ->execute([':id' => $fileId, ':uid' => $currentUserId]);
        json_out(500, '完成上传失败：' . $e->getMessage());
    }

    json_out(0, '上传完成', ['file_id' => $fileId, 'object_key' => $objectKey]);
    break;

case 'abort_upload':
    $uploadId  = $_POST['upload_id'] ?? '';
    $objectKey = $_POST['object_key'] ?? '';
    $fileId    = intval($_POST['file_id'] ?? 0);
    if ($uploadId !== '' && $objectKey !== '') {
        try { $ossClient->abortMultipartUpload($bucket, $objectKey, $uploadId); } catch (Exception $e) {}
    }
    if ($fileId > 0) {
        $pdo->prepare("DELETE FROM cloud_files WHERE id = :id AND user_id = :uid")
            ->execute([':id' => $fileId, ':uid' => $currentUserId]);
    }
    json_out(0, '已取消');
    break;

case 'create_folder':
    $name     = trim($_POST['name'] ?? '');
    $parentId = intval($_POST['parent_id'] ?? 0);
    $isPublic = intval($_POST['is_public'] ?? 0);

    if ($name === '' || mb_strlen($name) > 100) json_out(400, '文件夹名无效');
    if (strpos($name, '/') !== false) json_out(400, '名称不能包含 /');

    if ($parentId > 0) {
        $stmt = $pdo->prepare("SELECT user_id, is_public FROM cloud_files WHERE id = :id AND is_folder = 1");
        $stmt->execute([':id' => $parentId]);
        $parent = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$parent) json_out(404, '父文件夹不存在');
        if ($parent['is_public'] != $isPublic) json_out(400, '空间类型不匹配');
        if (!$isAdmin && !$isPublic && $parent['user_id'] != $currentUserId) json_out(403, '无权限');
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO cloud_files (user_id, user_name, original_name, stored_path, file_size, file_type, is_folder, parent_id, is_public) VALUES (:uid, :un, :name, '', 0, '', 1, :pid, :ip)");
        $stmt->execute([
            ':uid' => $currentUserId, ':un' => $currentUser,
            ':name' => $name, ':pid' => $parentId, ':ip' => $isPublic,
        ]);
        json_out(0, '创建成功', ['id' => $pdo->lastInsertId()]);
    } catch (PDOException $e) {
        json_out(500, '创建失败');
    }
    break;

case 'delete':
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) json_out(400, '参数错误');

    $stmt = $pdo->prepare("SELECT id, user_id, is_folder, stored_path FROM cloud_files WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$item) json_out(404, '不存在');
    if (!$isAdmin && $item['user_id'] != $currentUserId) json_out(403, '无权限');

    if ($item['is_folder']) {
        deleteFolderRecursive($pdo, $ossClient, $bucket, $id);
    } else {
        if (!empty($item['stored_path'])) {
            try { $ossClient->deleteObject($bucket, $item['stored_path']); } catch (Exception $e) {}
        }
        $pdo->prepare("DELETE FROM cloud_files WHERE id = :id")->execute([':id' => $id]);
    }
    json_out(0, '删除成功');
    break;

case 'toggle_public':
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) json_out(400, '参数错误');

    $stmt = $pdo->prepare("SELECT user_id, is_public, is_folder FROM cloud_files WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$item) json_out(404, '不存在');
    if (!$isAdmin && $item['user_id'] != $currentUserId) json_out(403, '无权限');

    $newVal = $item['is_public'] ? 0 : 1;
    try {
        $pdo->beginTransaction();
        $pdo->prepare("UPDATE cloud_files SET is_public = :ip WHERE id = :id")
            ->execute([':ip' => $newVal, ':id' => $id]);
        if ($item['is_folder']) togglePublicRecursive($pdo, $id, $newVal);
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        json_out(500, '操作失败');
    }
    json_out(0, '已更新', ['is_public' => $newVal]);
    break;

case 'rename':
    $id   = intval($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    if ($id <= 0 || $name === '' || mb_strlen($name) > 200) json_out(400, '参数错误');
    if (strpos($name, '/') !== false) json_out(400, '名称不能包含 /');

    $stmt = $pdo->prepare("SELECT user_id FROM cloud_files WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$item) json_out(404, '不存在');
    if (!$isAdmin && $item['user_id'] != $currentUserId) json_out(403, '无权限');

    $pdo->prepare("UPDATE cloud_files SET original_name = :n WHERE id = :id")
        ->execute([':n' => $name, ':id' => $id]);
    json_out(0, '已重命名');
    break;

case 'move':
    $id             = intval($_POST['id'] ?? 0);
    $targetFolderId = intval($_POST['target_folder_id'] ?? 0);
    $space          = $_POST['space'] ?? 'private';

    if ($id <= 0) json_out(400, '参数错误');
    if ($id == $targetFolderId) json_out(400, '不能移动到自身');

    $stmt = $pdo->prepare("SELECT id, user_id, is_folder, is_public FROM cloud_files WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$item) json_out(404, '不存在');

    if (!$isAdmin) {
        if ($space === 'private') {
            if ($item['is_public'] != 0 || $item['user_id'] != $currentUserId) json_out(403, '无权限移动该文件');
        } else {
            if ($item['is_public'] != 1 || $item['user_id'] != $currentUserId) json_out(403, '无权限移动该文件');
        }
    }

    if ($targetFolderId > 0) {
        $stmt = $pdo->prepare("SELECT id, user_id, is_public FROM cloud_files WHERE id = :id AND is_folder = 1");
        $stmt->execute([':id' => $targetFolderId]);
        $target = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$target) json_out(404, '目标文件夹不存在');

        if (!$isAdmin) {
            if ($space === 'private') {
                if ($target['is_public'] != 0 || $target['user_id'] != $currentUserId) json_out(403, '目标文件夹无权限');
            } else {
                if ($target['is_public'] != 1) json_out(403, '目标文件夹无权限');
            }
        } else {
            if ($space === 'private' && $target['is_public'] != 0) json_out(400, '私人空间目标必须是私人文件夹');
            if ($space === 'public' && $target['is_public'] != 1) json_out(400, '公共空间目标必须是公共文件夹');
        }

        if ($item['is_folder'] && isDescendant($pdo, $targetFolderId, $id)) json_out(400, '不能移动到自己的子文件夹');

        $newUserId   = $target['user_id'];
        $newIsPublic = $target['is_public'];
    } else {
        $newUserId   = $item['user_id'];
        $newIsPublic = $item['is_public'];
    }

    try {
        $pdo->beginTransaction();
        $pdo->prepare("UPDATE cloud_files SET parent_id = :pid, user_id = :uid, is_public = :ip WHERE id = :id")
            ->execute([':pid' => $targetFolderId, ':uid' => $newUserId, ':ip' => $newIsPublic, ':id' => $id]);
        if ($item['is_folder']) updateFolderOwnership($pdo, $id, $newUserId, $newIsPublic);
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        json_out(500, '移动失败：' . $e->getMessage());
    }
    json_out(0, '移动成功');
    break;

default:
    json_out(404, '未知操作：' . $action);
}

function isDescendant($pdo, $childId, $ancestorId) {
    $id = $childId;
    $guard = 0;
    while ($id > 0 && $guard++ < 100) {
        if ($id == $ancestorId) return true;
        $stmt = $pdo->prepare("SELECT parent_id FROM cloud_files WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) break;
        $id = intval($row['parent_id']);
    }
    return false;
}

function updateFolderOwnership($pdo, $folderId, $newUserId, $newIsPublic) {
    $stmt = $pdo->prepare("SELECT id, is_folder FROM cloud_files WHERE parent_id = :pid");
    $stmt->execute([':pid' => $folderId]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $child) {
        $pdo->prepare("UPDATE cloud_files SET user_id = :uid, is_public = :ip WHERE id = :id")
            ->execute([':uid' => $newUserId, ':ip' => $newIsPublic, ':id' => $child['id']]);
        if ($child['is_folder']) updateFolderOwnership($pdo, $child['id'], $newUserId, $newIsPublic);
    }
}

function deleteFolderRecursive($pdo, $ossClient, $bucket, $folderId) {
    $stmt = $pdo->prepare("SELECT id, is_folder, stored_path FROM cloud_files WHERE parent_id = :pid");
    $stmt->execute([':pid' => $folderId]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $child) {
        if ($child['is_folder']) {
            deleteFolderRecursive($pdo, $ossClient, $bucket, $child['id']);
        } else {
            if (!empty($child['stored_path'])) {
                try { $ossClient->deleteObject($bucket, $child['stored_path']); } catch (Exception $e) {}
            }
        }
        $pdo->prepare("DELETE FROM cloud_files WHERE id = :id")->execute([':id' => $child['id']]);
    }
    $pdo->prepare("DELETE FROM cloud_files WHERE id = :id")->execute([':id' => $folderId]);
}

function togglePublicRecursive($pdo, $folderId, $newVal) {
    $stmt = $pdo->prepare("SELECT id, is_folder FROM cloud_files WHERE parent_id = :pid");
    $stmt->execute([':pid' => $folderId]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $child) {
        $pdo->prepare("UPDATE cloud_files SET is_public = :ip WHERE id = :id")
            ->execute([':ip' => $newVal, ':id' => $child['id']]);
        if ($child['is_folder']) togglePublicRecursive($pdo, $child['id'], $newVal);
    }
}