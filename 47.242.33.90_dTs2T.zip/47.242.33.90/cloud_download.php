<?php
// =============================================
// 文件名：cloud_download.php
// 用途：生成 OSS 私有文件临时下载链接并跳转
// =============================================
session_start();
require_once 'config.php';
require_once 'config_oss.php';

use OSS\Core\OssException;

if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    die('未登录');
}
$isAdmin = isset($_SESSION['admin']);
$currentUserId = $_SESSION['user_id'] ?? 0;

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) die('无效的ID');

$stmt = $pdo->prepare("SELECT user_id, original_name, stored_path, is_public, is_folder FROM cloud_files WHERE id = :id");
$stmt->execute([':id' => $id]);
$file = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$file) die('文件不存在');
if ($file['is_folder']) die('文件夹无法下载');
if (!$file['is_public'] && !$isAdmin && $file['user_id'] != $currentUserId) die('无权限下载');
if (empty($file['stored_path'])) die('文件路径为空');

$client = getOssClient();
$bucket = getBucketName();
$expire = getOssUrlExpire();

try {
    $signedUrl = $client->signUrl($bucket, $file['stored_path'], $expire, 'GET');
} catch (OssException $e) {
    die('生成下载链接失败：' . $e->getMessage());
}

header('Location: ' . $signedUrl);
exit;