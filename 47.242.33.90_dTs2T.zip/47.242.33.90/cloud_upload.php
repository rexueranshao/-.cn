<?php
// =============================================
// 文件名：cloud_upload.php
// 用途：云盘文件上传接口（返回 JSON，支持任意大小）
// =============================================
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once 'config.php';

function json_out($code, $msg, $data = null) {
    echo json_encode(['code' => $code, 'message' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    json_out(401, '未登录');
}
$currentUser = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$currentUserId = $_SESSION['user_id'] ?? 0;

$storageDir = '/data/cloud/files';
$diskPath = '/data';

if (!is_dir($storageDir)) {
    if (!@mkdir($storageDir, 0755, true)) {
        json_out(500, '无法创建存储目录');
    }
}

if (empty($_FILES) && empty($_POST) && isset($_SERVER['CONTENT_LENGTH']) && $_SERVER['CONTENT_LENGTH'] > 0) {
    $limit = ini_get('post_max_size');
    json_out(413, '文件超出服务器 post_max_size 限制（当前 ' . $limit . '），请管理员调整 PHP 配置');
}

if (!isset($_FILES['file'])) {
    json_out(400, '没有收到文件');
}

$file = $_FILES['file'];

$maxBytes = 50 * 1024 * 1024 * 1024; // 50 GB
if ($file['size'] > $maxBytes) {
    json_out(413, '文件超过 50 GB 限制');
}

if ($file['error'] !== UPLOAD_ERR_OK) {
    $errMap = [
        UPLOAD_ERR_INI_SIZE   => '文件超出 upload_max_filesize 限制（当前 ' . ini_get('upload_max_filesize') . '）',
        UPLOAD_ERR_FORM_SIZE  => '文件超出表单限制',
        UPLOAD_ERR_PARTIAL    => '文件上传不完整，请重试',
        UPLOAD_ERR_NO_TMP_DIR => '服务器缺少临时目录',
        UPLOAD_ERR_CANT_WRITE => '服务器无法写入临时文件',
        UPLOAD_ERR_EXTENSION  => 'PHP 扩展阻止了上传',
    ];
    json_out(400, $errMap[$file['error']] ?? ('上传错误码：' . $file['error']));
}

$free = @disk_free_space($diskPath);
if ($free !== false && $free < $file['size'] + 1024 * 1024 * 1024) {
    json_out(507, '磁盘空间不足');
}

$originalName = basename($file['name']);
$ext = pathinfo($originalName, PATHINFO_EXTENSION);
$storedName = md5(uniqid('', true) . $originalName . microtime(true)) . ($ext ? '.' . strtolower($ext) : '');
$subDir = date('Y/m');
$targetDir = $storageDir . '/' . $subDir;
if (!is_dir($targetDir)) @mkdir($targetDir, 0755, true);

$targetPath = $targetDir . '/' . $storedName;
$relativePath = $subDir . '/' . $storedName;

if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
    json_out(500, '文件保存失败，请检查 /data/cloud/files 目录权限');
}

$isPublic = (isset($_POST['is_public']) && $_POST['is_public'] == '1') ? 1 : 0;

try {
    $stmt = $pdo->prepare("INSERT INTO cloud_files (user_id, user_name, original_name, stored_path, file_size, file_type, is_public) VALUES (:uid, :un, :on, :sp, :sz, :ft, :ip)");
    $stmt->execute([
        ':uid' => $currentUserId,
        ':un'  => $currentUser,
        ':on'  => $originalName,
        ':sp'  => $relativePath,
        ':sz'  => $file['size'],
        ':ft'  => $file['type'] ?? '',
        ':ip'  => $isPublic,
    ]);
} catch (PDOException $e) {
    @unlink($targetPath);
    json_out(500, '数据库写入失败：' . $e->getMessage());
}

json_out(0, '上传成功：' . $originalName, [
    'name' => $originalName,
    'size' => $file['size'],
    'id'   => $pdo->lastInsertId(),
]);