<?php
// =============================================
// 文件名：config.php
// 用途：数据库连接配置 + 自动注入网站图标 + 全站背景图片（负 z-index 模糊层）
// 修改：背景层使用负 z-index，避免滚动断层和内容遮挡
// =============================================

// 数据库配置
$db_host = '127.0.0.1';
$db_name = '论坛';
$db_user = '论坛';
$db_pass = 'Wangzikang8188';
$db_charset = 'utf8mb4';

// 使用PDO连接数据库
try {
    $pdo = new PDO(
        "mysql:host={$db_host};dbname={$db_name};charset={$db_charset}",
        $db_user,
        $db_pass
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('数据库连接失败，请检查配置');
}

// ---------- 查询网站图标和登录背景设置 ----------
$GLOBALS['site_favicon'] = '';
$GLOBALS['login_bg'] = '';
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'site_favicon' LIMIT 1");
    $favicon = $stmt->fetchColumn();
    if ($favicon !== false) {
        $GLOBALS['site_favicon'] = $favicon;
    }

    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'login_bg' LIMIT 1");
    $bg = $stmt->fetchColumn();
    if ($bg !== false) {
        $GLOBALS['login_bg'] = $bg;
    }
} catch (PDOException $e) {
    // 表不存在或查询失败时忽略
}

// ---------- 输出缓冲自动注入 favicon 和全局背景 ----------
function inject_favicon_callback($buffer) {
    $favicon = $GLOBALS['site_favicon'] ?? '';
    $loginBg = $GLOBALS['login_bg'] ?? '';
    $cssInject = '';
    $bodyInject = '';

    // 1. 注入网站图标
    if ($favicon !== '') {
        $mime = 'image/png';
        $ext = pathinfo($favicon, PATHINFO_EXTENSION);
        switch (strtolower($ext)) {
            case 'svg':
                $mime = 'image/svg+xml';
                break;
            case 'ico':
                $mime = 'image/x-icon';
                break;
            case 'jpg':
            case 'jpeg':
                $mime = 'image/jpeg';
                break;
            case 'gif':
                $mime = 'image/gif';
                break;
            case 'webp':
                $mime = 'image/webp';
                break;
            default:
                $mime = 'image/png';
        }
        $faviconPath = __DIR__ . '/' . $favicon;
        $version = '';
        if (file_exists($faviconPath)) {
            $version = '?v=' . filemtime($faviconPath);
        }
        $faviconUrl = htmlspecialchars($favicon, ENT_QUOTES, 'UTF-8') . $version;
        $cssInject .= '<link rel="icon" type="' . $mime . '" href="' . $faviconUrl . '">' .
                      '<link rel="apple-touch-icon" sizes="180x180" href="' . $faviconUrl . '">';
    }

    // 2. 全站背景图片（非登录页）
    if ($loginBg !== '') {
        $bgUrl = htmlspecialchars($loginBg, ENT_QUOTES, 'UTF-8');
        $currentScript = basename($_SERVER['SCRIPT_NAME'] ?? '');

        if ($currentScript !== 'login.php') {
            // 非登录页：注入负 z-index 背景层，确保内容始终在上方
            $cssInject .= '<style>
                body {
                    background: transparent;
                }
                #bg-blur-layer {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-image: url(\'' . $bgUrl . '\');
                    background-size: cover;
                    background-position: center;
                    background-repeat: no-repeat;
                    filter: blur(10px);
                    z-index: -1;
                    pointer-events: none;
                }
                /* 可选：给文字加一点阴影增强可读性 */
                h1, h2, h3, h4, h5, p, span, a, td, th, li, label {
                    text-shadow: 0 0 2px rgba(255, 255, 255, 0.3);
                }
            </style>';
            $bodyInject = '<div id="bg-blur-layer"></div>';
        }
    }

    // 注入 CSS 到 </head> 前
    if ($cssInject !== '') {
        if (($pos = stripos($buffer, '</head>')) !== false) {
            $buffer = substr_replace($buffer, $cssInject, $pos, 0);
        } else {
            if (($pos2 = stripos($buffer, '<html')) !== false) {
                $end = strpos($buffer, '>', $pos2);
                if ($end !== false) {
                    $buffer = substr_replace($buffer, '<head>' . $cssInject . '</head>', $end + 1, 0);
                }
            }
        }
    }

    // 注入背景 div 到 <body> 标签后
    if ($bodyInject !== '') {
        if (($pos = stripos($buffer, '<body')) !== false) {
            $end = strpos($buffer, '>', $pos);
            if ($end !== false) {
                $buffer = substr_replace($buffer, $bodyInject, $end + 1, 0);
            }
        }
    }

    return $buffer;
}
ob_start('inject_favicon_callback');