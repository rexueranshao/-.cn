<?php
// =============================================
// 文件名：config_oss.php
// 用途：阿里云 OSS 配置
// =============================================

$autoload = __DIR__ . '/vendor/autoload.php';
if (file_exists($autoload)) require_once $autoload;

use OSS\OssClient;
use OSS\Core\OssException;

// ============ 修改以下 4 项 ============
$OSS_ACCESS_KEY_ID     = 'LTAI5t79oGxEyJZzqtWaCu8e';
$OSS_ACCESS_KEY_SECRET = '3aMzS5mW5z5c9Gu59fEAfcgoeu7M9O';
$OSS_ENDPOINT          = 'oss-cn-hongkong.aliyuncs.com';
$OSS_BUCKET            = 'rexueranshao';
$OSS_URL_EXPIRE        = 3600; // 私有文件临时链接有效期（秒）
// =====================================

function getOssClient() {
    global $OSS_ACCESS_KEY_ID, $OSS_ACCESS_KEY_SECRET, $OSS_ENDPOINT;
    static $client = null;
    if ($client === null) {
        $client = new OssClient($OSS_ACCESS_KEY_ID, $OSS_ACCESS_KEY_SECRET, $OSS_ENDPOINT);
        $client->setTimeout(3600);
        $client->setConnectTimeout(60);
    }
    return $client;
}

function getBucketName() {
    global $OSS_BUCKET;
    return $OSS_BUCKET;
}

function getOssUrlExpire() {
    global $OSS_URL_EXPIRE;
    return $OSS_URL_EXPIRE;
}