<?php
// =============================================
// 文件名：delete_account.php
// 用途：普通用户注销自己的账号
// =============================================
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$currentUser = $_SESSION['user'];

try {
    $stmt = $pdo->prepare("DELETE FROM `users` WHERE `name` = :name");
    $stmt->execute([':name' => $currentUser]);
} catch (PDOException $e) {}

session_unset();
session_destroy();
header('Location: login.php');
exit;
?>