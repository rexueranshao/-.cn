<?php
// =============================================
// 文件名：forum.php
// 用途：论坛帖子列表页
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$currentUser = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$isAdmin = isset($_SESSION['admin']);
$homeLink = $isAdmin ? 'admin_index.php' : 'user_index.php';

// 批量删除
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'bulk_delete' && $isAdmin) {
    if (isset($_POST['ids']) && is_array($_POST['ids'])) {
        $ids = array_map('intval', $_POST['ids']);
        if (!empty($ids)) {
            try {
                $pdo->beginTransaction();
                foreach ($ids as $postId) {
                    $stmt = $pdo->prepare("DELETE FROM `forum_replies` WHERE `post_id` = :pid");
                    $stmt->execute([':pid' => $postId]);
                    $stmt = $pdo->prepare("DELETE FROM `forum_posts` WHERE `id` = :pid");
                    $stmt->execute([':pid' => $postId]);
                }
                $pdo->commit();
                $success = '已批量删除 ' . count($ids) . ' 篇帖子';
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = '批量删除失败，请稍后再试';
            }
        }
    }
}

// 删除单个帖子
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && $isAdmin) {
    $postId = intval($_GET['id']);
    if ($postId > 0) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("DELETE FROM `forum_replies` WHERE `post_id` = :pid");
            $stmt->execute([':pid' => $postId]);
            $stmt = $pdo->prepare("DELETE FROM `forum_posts` WHERE `id` = :pid");
            $stmt->execute([':pid' => $postId]);
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
        }
    }
    header('Location: forum.php');
    exit;
}

$error = '';
$success = '';
$posts = [];

try {
    $sql = "SELECT p.id, p.title, p.content, p.user_name, p.created_at,
                   u.avatar, u.avatar_frame, u.name_color,
                   p.is_pinned, p.pinned_until,
                   (SELECT COUNT(*) FROM forum_replies r WHERE r.post_id = p.id) AS reply_count,
                   (SELECT MAX(created_at) FROM forum_replies r WHERE r.post_id = p.id) AS last_reply_time
            FROM forum_posts p
            LEFT JOIN users u ON p.user_name = u.name
            WHERE p.status = 'normal'
            ORDER BY (p.is_pinned = 1 AND p.pinned_until > NOW()) DESC, 
                     p.pinned_until DESC, 
                     p.created_at DESC, p.id DESC";
    $stmt = $pdo->query($sql);
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '论坛帖子查询失败，请稍后再试';
}

function isPinned($post) {
    return $post['is_pinned'] == 1 && strtotime($post['pinned_until']) > time();
}

function displayAvatar($avatarUrl, $avatarFrame, $userName, $size = 'small') {
    $width = $size === 'small' ? 30 : 60;
    $style = "display:inline-block;width:{$width}px;height:{$width}px;border-radius:50%;background:#ccc;text-align:center;line-height:{$width}px;color:#fff;font-size:".($width*0.5)."px;";
    if (!empty($avatarUrl)) {
        return '<img src="'.htmlspecialchars($avatarUrl).'" alt="头像" class="avatar '.htmlspecialchars($avatarFrame).'" style="width:'.$width.'px;height:'.$width.'px;border-radius:50%;object-fit:cover;border:2px solid #ddd;">';
    } else {
        $frameClass = !empty($avatarFrame) ? htmlspecialchars($avatarFrame) : '';
        return '<span class="avatar '.$frameClass.'" style="'.$style.'">'.htmlspecialchars(mb_substr($userName,0,1)).'</span>';
    }
}

// 截取内容摘要（最多 80 字）
function excerpt($text, $len = 80) {
    $text = trim(strip_tags($text));
    $text = preg_replace('/\s+/', ' ', $text);
    if (mb_strlen($text, 'UTF-8') > $len) {
        return mb_substr($text, 0, $len, 'UTF-8') . '...';
    }
    return $text;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>论坛</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .post-card {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 18px 22px;
            margin-bottom: 14px;
            box-shadow: var(--shadow-sm);
            transition: box-shadow .2s, border-color .2s;
        }
        .post-card:hover {
            border-color: #cfe0ff;
            box-shadow: 0 6px 20px rgba(15,107,255,.08);
        }
        .post-title {
            font-size: 17px;
            font-weight: 600;
            margin: 0 0 10px;
            line-height: 1.5;
        }
        .post-title a {
            color: var(--text);
            text-decoration: none;
        }
        .post-title a:hover {
            color: var(--accent);
            text-decoration: none;
            opacity: 1;
        }
        .post-excerpt {
            color: var(--text-light);
            font-size: 13.5px;
            line-height: 1.7;
            margin: 10px 0 14px;
            padding: 12px 14px;
            background: #f7f9fc;
            border-radius: 8px;
            border-left: 3px solid var(--accent-soft);
        }
        .post-meta {
            color: var(--text-light);
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 12px;
        }
        .post-meta .sep { color: #d8dfe8; }
        .pinned-badge {
            display: inline-block;
            background: #ffe0e0;
            color: var(--danger);
            border-radius: 6px;
            padding: 2px 8px;
            font-size: 11.5px;
            font-weight: 600;
        }
        .post-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            padding-top: 12px;
            border-top: 1px solid #f1f4f9;
            align-items: center;
        }
        .post-actions .btn-view {
            background: var(--accent);
            color: #fff !important;
        }
        .post-actions .btn-view:hover {
            background: var(--accent-hover);
        }
        .admin-checkbox {
            float: left;
            margin-right: 12px;
            margin-top: 6px;
        }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>论坛</h1>
    <p class="page-nav">
        <a href="<?php echo $homeLink; ?>" class="btn btn-secondary btn-sm">返回首页</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
        <?php if ($isAdmin): ?>
            <a href="admin_manual_review.php" class="btn btn-warning btn-sm">人工复议</a>
        <?php endif; ?>
        <a href="forum_post.php" class="btn btn-sm">发帖</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <?php if (empty($posts)): ?>
        <p class="text-mute">暂无帖子</p>
    <?php else: ?>
        <?php if ($isAdmin): ?>
            <form method="post" action="forum.php" onsubmit="return confirm('确定删除选中的帖子吗？');">
                <input type="hidden" name="action" value="bulk_delete">
                <p class="mb-10">
                    <button type="submit" class="btn btn-danger btn-sm">批量删除选中</button>
                </p>
        <?php endif; ?>

        <?php foreach ($posts as $post): ?>
            <div class="post-card">
                <?php if ($isAdmin): ?>
                    <input type="checkbox" name="ids[]" value="<?php echo $post['id']; ?>" class="admin-checkbox">
                <?php endif; ?>

                <h3 class="post-title">
                    <?php if (isPinned($post)): ?>
                        <span class="pinned-badge">置顶</span>
                    <?php endif; ?>
                    <a href="forum_view.php?id=<?php echo $post['id']; ?>">
                        <?php echo htmlspecialchars($post['title']); ?>
                    </a>
                </h3>

                <div class="post-excerpt">
                    <?php echo htmlspecialchars(excerpt($post['content'] ?? '', 100)); ?>
                </div>

                <div class="post-meta">
                    <?php echo displayAvatar($post['avatar'], $post['avatar_frame'], $post['user_name'], 'small'); ?>
                    <a href="user_view.php?name=<?php echo urlencode($post['user_name']); ?>" class="user-name" style="color:<?php echo htmlspecialchars($post['name_color'] ?: '#0f6bff'); ?>;">
                        <?php echo htmlspecialchars($post['user_name']); ?>
                    </a>
                    <span class="sep">|</span>
                    <span>回复数：<?php echo $post['reply_count']; ?></span>
                    <span class="sep">|</span>
                    <span>发帖：<?php echo htmlspecialchars($post['created_at']); ?></span>
                    <?php if ($post['last_reply_time']): ?>
                        <span class="sep">|</span>
                        <span>最后回复：<?php echo htmlspecialchars($post['last_reply_time']); ?></span>
                    <?php endif; ?>
                    <?php if (isPinned($post)): ?>
                        <span class="sep">|</span>
                        <span>置顶至：<?php echo htmlspecialchars($post['pinned_until']); ?></span>
                    <?php endif; ?>
                </div>

                <div class="post-actions">
                    <a href="forum_view.php?id=<?php echo $post['id']; ?>" class="btn btn-sm btn-view">📖 查看全文</a>
                    <a href="report.php?type=forum_post&id=<?php echo $post['id']; ?>" class="btn btn-sm btn-outline">举报</a>
                    <?php if ($isAdmin || $post['user_name'] === $currentUser): ?>
                        <a href="pin_post.php?post_id=<?php echo $post['id']; ?>" class="btn btn-sm btn-warning">置顶</a>
                    <?php endif; ?>
                    <?php if ($isAdmin): ?>
                        <a href="forum_edit.php?id=<?php echo $post['id']; ?>" class="btn btn-sm">编辑</a>
                        <a href="forum.php?action=delete&id=<?php echo $post['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定删除该帖子？');">删除</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if ($isAdmin): ?>
            </form>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>