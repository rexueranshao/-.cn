<?php
// =============================================
// 文件名：forum_edit.php
// 用途：管理员编辑帖子
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$postId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$post = null;

if ($postId <= 0) {
    $error = '无效的帖子ID';
} else {
    try {
        $stmt = $pdo->prepare("SELECT `id`, `title`, `content` FROM `forum_posts` WHERE `id` = :id");
        $stmt->execute([':id' => $postId]);
        $post = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$post) $error = '帖子不存在';
    } catch (PDOException $e) {
        $error = '查询失败';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $post) {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if ($title === '' || $content === '') {
        $error = '标题和内容不能为空';
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE `forum_posts` SET `title` = :title, `content` = :content WHERE `id` = :id");
            $stmt->execute([':title' => $title, ':content' => $content, ':id' => $postId]);
            header('Location: forum_view.php?id=' . $postId);
            exit;
        } catch (PDOException $e) {
            $error = '更新失败';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>编辑帖子</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-row { margin-bottom: 12px; }
        .form-row label { display: block; margin-bottom: 5px; font-weight: 500; color: var(--text-light); font-size: 13px; }
    </style>
</head>
<body>
    <h1>编辑帖子</h1>
    <p class="page-nav">
        <a href="forum_view.php?id=<?php echo $postId; ?>" class="btn btn-secondary btn-sm">返回帖子</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>

    <?php if ($post): ?>
        <div class="card" style="max-width:720px;">
            <form method="post">
                <div class="form-row">
                    <label>标题</label>
                    <input type="text" name="title" value="<?php echo htmlspecialchars($post['title']); ?>" required>
                </div>
                <div class="form-row">
                    <label>内容</label>
                    <textarea name="content" rows="10" required><?php echo htmlspecialchars($post['content']); ?></textarea>
                </div>
                <button type="submit" class="btn">保存修改</button>
            </form>
        </div>
    <?php endif; ?>
</body>
</html>