<?php
// =============================================
// 文件名：forum_edit_reply.php
// 用途：管理员编辑回复
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$replyId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$postId = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;
$error = '';
$reply = null;

if ($replyId <= 0) {
    $error = '无效的回复ID';
} else {
    try {
        $stmt = $pdo->prepare("SELECT `id`, `content` FROM `forum_replies` WHERE `id` = :id");
        $stmt->execute([':id' => $replyId]);
        $reply = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$reply) $error = '回复不存在';
    } catch (PDOException $e) {
        $error = '查询失败';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $reply) {
    $content = trim($_POST['content'] ?? '');
    if ($content === '') {
        $error = '回复内容不能为空';
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE `forum_replies` SET `content` = :content WHERE `id` = :id");
            $stmt->execute([':content' => $content, ':id' => $replyId]);
            header('Location: forum_view.php?id=' . $postId);
            exit;
        } catch (PDOException $e) {
            $error = '更新失败';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>编辑回复</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>编辑回复</h1>
    <p class="page-nav">
        <a href="forum_view.php?id=<?php echo $postId; ?>" class="btn btn-secondary btn-sm">返回帖子</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>

    <?php if ($reply): ?>
        <div class="card" style="max-width:640px;">
            <form method="post">
                <textarea name="content" rows="6" required><?php echo htmlspecialchars($reply['content']); ?></textarea>
                <p class="mt-20"><button type="submit" class="btn">保存修改</button></p>
            </form>
        </div>
    <?php endif; ?>
</body>
</html>