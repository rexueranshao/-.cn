<?php
// =============================================
// 文件名：forum_post.php
// 用途：论坛发帖页面（AI审核 + 图片上传）
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';
require_once 'ai_functions.php';
require_once 'upload_functions.php';

$currentUser = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $imageUrl = '';

    if (isset($_FILES['post_image']) && $_FILES['post_image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $uploadResult = handle_image_upload($_FILES['post_image'], 'forum');
        if (!$uploadResult['success']) {
            $error = $uploadResult['error'];
        } else {
            $imageUrl = $uploadResult['url'];
        }
    }

    if (!$error && ($title === '' || $content === '')) {
        $error = '请输入帖子标题和内容';
    }

    if (!$error) {
        $fullText = $title . "\n" . $content;
        $aiResult = ai_check_content($fullText);
        if ($aiResult['safe']) {
            try {
                $stmt = $pdo->prepare("INSERT INTO forum_posts (user_name, title, content, image_url, status, ai_safe, ai_reason) VALUES (:user, :title, :content, :image_url, 'normal', 1, :ai_reason)");
                $stmt->execute([
                    ':user' => $currentUser, ':title' => $title, ':content' => $content,
                    ':image_url' => $imageUrl, ':ai_reason' => $aiResult['reason']
                ]);
                header('Location: forum.php');
                exit;
            } catch (PDOException $e) {
                $error = '发帖失败，请稍后再试';
            }
        } else {
            $_SESSION['forum_reject_count'] = ($_SESSION['forum_reject_count'] ?? 0) + 1;
            if ($_SESSION['forum_reject_count'] >= 2) {
                try {
                    $stmt = $pdo->prepare("INSERT INTO forum_posts (user_name, title, content, image_url, status, ai_safe, ai_reason) VALUES (:user, :title, :content, :image_url, 'pending_manual', 0, :ai_reason)");
                    $stmt->execute([
                        ':user' => $currentUser, ':title' => $title, ':content' => $content,
                        ':image_url' => $imageUrl, ':ai_reason' => $aiResult['reason']
                    ]);
                    $_SESSION['forum_reject_count'] = 0;
                    $success = '内容已提交人工复议，请等待管理员审核';
                } catch (PDOException $e) {
                    $error = '提交人工复议失败，请稍后再试';
                }
            } else {
                $error = '内容可能包含违规信息：' . $aiResult['reason'] . '，请修改后重试（还有 ' . (2 - $_SESSION['forum_reject_count']) . ' 次机会）';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>发帖</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-row { margin-bottom: 12px; }
        .form-row label { display: block; margin-bottom: 5px; font-weight: 500; color: var(--text-light); font-size: 13px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>发帖</h1>
    <p class="page-nav">
        <a href="forum.php" class="btn btn-secondary btn-sm">返回论坛</a>
        <a href="user_index.php" class="btn btn-secondary btn-sm">返回首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:680px;">
        <form method="post" action="forum_post.php" enctype="multipart/form-data">
            <div class="form-row">
                <label>标题</label>
                <input type="text" name="title" value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>" required>
            </div>
            <div class="form-row">
                <label>内容</label>
                <textarea name="content" rows="10" required><?php echo isset($_POST['content']) ? htmlspecialchars($_POST['content']) : ''; ?></textarea>
            </div>
            <div class="form-row">
                <label>上传图片（可选）</label>
                <input type="file" name="post_image" accept="image/*">
            </div>
            <button type="submit" class="btn">发布帖子</button>
        </form>
    </div>
</body>
</html>