<?php
// =============================================
// 文件名：forum_view.php
// 用途：帖子详情及回复
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';
require_once 'ai_functions.php';

$currentUser = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$isAdmin = isset($_SESSION['admin']);
$postId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$success = '';
$post = null;
$replies = [];

// 删除回复（仅管理员）
if (isset($_GET['action']) && $_GET['action'] === 'delete_reply' && isset($_GET['reply_id']) && $isAdmin) {
    $replyId = intval($_GET['reply_id']);
    if ($replyId > 0) {
        try {
            $stmt = $pdo->prepare("DELETE FROM `forum_replies` WHERE `id` = :rid");
            $stmt->execute([':rid' => $replyId]);
        } catch (PDOException $e) {}
    }
    header('Location: forum_view.php?id=' . $postId);
    exit;
}

if ($postId <= 0) {
    $error = '无效的帖子ID';
} else {
    try {
        $stmt = $pdo->prepare("SELECT p.id, p.user_name, p.title, p.content, p.image_url, p.created_at,
                                      u.avatar, u.avatar_frame, u.name_color, u.signature
                               FROM forum_posts p
                               LEFT JOIN users u ON p.user_name = u.name
                               WHERE p.id = :id AND p.status = 'normal'");
        $stmt->execute([':id' => $postId]);
        $post = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$post) $error = '帖子不存在或已被删除';
    } catch (PDOException $e) {
        $error = '帖子查询失败';
    }

    if ($post) {
        // 回复提交
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_content'])) {
            $replyContent = trim($_POST['reply_content'] ?? '');
            if ($replyContent === '') {
                $error = '回复内容不能为空';
            } else {
                $aiResult = ai_check_content($replyContent);
                if ($aiResult['safe']) {
                    try {
                        $stmt = $pdo->prepare("INSERT INTO forum_replies (post_id, user_name, content, status, ai_safe, ai_reason) VALUES (:post_id, :user_name, :content, 'normal', 1, :ai_reason)");
                        $stmt->execute([
                            ':post_id' => $postId,
                            ':user_name' => $currentUser,
                            ':content' => $replyContent,
                            ':ai_reason' => $aiResult['reason']
                        ]);
                        header("Location: forum_view.php?id={$postId}");
                        exit;
                    } catch (PDOException $e) {
                        $error = '回复失败，请稍后再试';
                    }
                } else {
                    $_SESSION['reply_reject_count'] = ($_SESSION['reply_reject_count'] ?? 0) + 1;
                    if ($_SESSION['reply_reject_count'] >= 2) {
                        try {
                            $stmt = $pdo->prepare("INSERT INTO forum_replies (post_id, user_name, content, status, ai_safe, ai_reason) VALUES (:post_id, :user_name, :content, 'pending_manual', 0, :ai_reason)");
                            $stmt->execute([
                                ':post_id' => $postId,
                                ':user_name' => $currentUser,
                                ':content' => $replyContent,
                                ':ai_reason' => $aiResult['reason']
                            ]);
                            $_SESSION['reply_reject_count'] = 0;
                            $success = '回复已提交人工复议，请等待管理员审核';
                        } catch (PDOException $e) {
                            $error = '提交失败';
                        }
                    } else {
                        $error = '回复可能包含违规信息：' . $aiResult['reason'] . '，请修改后重试';
                    }
                }
            }
        }

        // 查询回复
        try {
            $sql = "SELECT r.id, r.user_name, r.content, r.created_at,
                           u.avatar, u.avatar_frame, u.name_color
                    FROM forum_replies r
                    LEFT JOIN users u ON r.user_name = u.name
                    WHERE r.post_id = :post_id AND r.status = 'normal'
                    ORDER BY r.created_at ASC, r.id ASC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':post_id' => $postId]);
            $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $error = '回复查询失败';
        }
    }
}

function displayAvatar($avatarUrl, $avatarFrame, $userName, $size = 'small') {
    $width = $size === 'small' ? 30 : 60;
    $style = "display:inline-block;width:{$width}px;height:{$width}px;border-radius:50%;background:#ccc;text-align:center;line-height:{$width}px;color:#fff;font-size:".($width*0.5)."px;";
    if (!empty($avatarUrl)) {
        return '<img src="'.htmlspecialchars($avatarUrl).'" alt="头像" class="avatar '.htmlspecialchars($avatarFrame).'" style="width:'.$width.'px;height:'.$width.'px;border-radius:50%;object-fit:cover;border:2px solid #ddd;">';
    } else {
        $frameClass = !empty($avatarFrame) ? htmlspecialchars($avatarFrame) : '';
        return '<span class="avatar '.$frameClass.'" style="'.$style.'">'.htmlspecialchars(mb_substr($userName,0,1)).'</span>';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $post ? htmlspecialchars($post['title']) : '帖子详情'; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>帖子详情</h1>
    <p class="page-nav">
        <a href="forum.php" class="btn btn-secondary btn-sm">返回论坛</a>
        <a href="user_index.php" class="btn btn-secondary btn-sm">返回首页</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <?php if ($post): ?>
        <div class="card">
            <h2><?php echo htmlspecialchars($post['title']); ?></h2>
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;color:#64748b;font-size:13px;">
                <?php echo displayAvatar($post['avatar'], $post['avatar_frame'], $post['user_name'], 'large'); ?>
                <a href="user_view.php?name=<?php echo urlencode($post['user_name']); ?>" class="user-name" style="color:<?php echo htmlspecialchars($post['name_color'] ?: '#0f6bff'); ?>;">
                    <?php echo htmlspecialchars($post['user_name']); ?>
                </a>
                <span>发帖时间：<?php echo htmlspecialchars($post['created_at']); ?></span>
                <a href="report.php?type=forum_post&id=<?php echo $post['id']; ?>">举报</a>
            </div>
            <div class="mt-10"><?php echo nl2br(htmlspecialchars($post['content'])); ?></div>
            <?php if (!empty($post['image_url'])): ?>
                <img src="<?php echo htmlspecialchars($post['image_url']); ?>" alt="图片" style="max-width:400px;max-height:300px;border-radius:6px;display:block;margin-top:10px;">
            <?php endif; ?>
        </div>

        <div class="card">
            <h2>回复（<?php echo count($replies); ?>）</h2>
            <?php if (empty($replies)): ?>
                <p class="text-mute">暂无回复</p>
            <?php else: ?>
                <?php foreach ($replies as $reply): ?>
                    <div style="border-bottom:1px solid #eef1f6;padding:12px 0;">
                        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;color:#64748b;font-size:13px;">
                            <?php echo displayAvatar($reply['avatar'], $reply['avatar_frame'], $reply['user_name'], 'small'); ?>
                            <a href="user_view.php?name=<?php echo urlencode($reply['user_name']); ?>" class="user-name" style="color:<?php echo htmlspecialchars($reply['name_color'] ?: '#0f6bff'); ?>;">
                                <?php echo htmlspecialchars($reply['user_name']); ?>
                            </a>
                            <span><?php echo htmlspecialchars($reply['created_at']); ?></span>
                            <a href="report.php?type=forum_reply&id=<?php echo $reply['id']; ?>">举报</a>
                        </div>
                        <div class="mt-10"><?php echo nl2br(htmlspecialchars($reply['content'])); ?></div>
                        <?php if ($isAdmin): ?>
                            <div class="mt-10 flex">
                                <a href="forum_edit_reply.php?id=<?php echo $reply['id']; ?>&post_id=<?php echo $postId; ?>" class="btn btn-sm">编辑</a>
                                <a href="forum_view.php?id=<?php echo $postId; ?>&action=delete_reply&reply_id=<?php echo $reply['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('确定删除该回复？');">删除</a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="card">
            <h2>发表回复</h2>
            <form method="post" action="forum_view.php?id=<?php echo $postId; ?>">
                <textarea name="reply_content" placeholder="写下你的回复..." rows="4" required></textarea>
                <p class="mt-10"><button type="submit" class="btn">发表回复</button></p>
            </form>
        </div>
    <?php endif; ?>
</body>
</html>