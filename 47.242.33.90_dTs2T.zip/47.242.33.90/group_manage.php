<?php
// =============================================
// 文件名：group_manage.php
// 用途：管理员用户组管理（创建、删除、查看成员、批量删除）
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

// 批量删除
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'bulk_delete') {
    if (isset($_POST['ids']) && is_array($_POST['ids'])) {
        $ids = array_map('intval', $_POST['ids']);
        if (!empty($ids)) {
            try {
                $pdo->beginTransaction();
                foreach ($ids as $groupId) {
                    $stmt = $pdo->prepare("UPDATE `users` SET `group_id` = NULL WHERE `group_id` = :gid");
                    $stmt->execute([':gid' => $groupId]);
                    $stmt = $pdo->prepare("DELETE FROM `user_group_relation` WHERE `group_id` = :gid");
                    $stmt->execute([':gid' => $groupId]);
                    $stmt = $pdo->prepare("DELETE FROM `user_groups` WHERE `id` = :gid");
                    $stmt->execute([':gid' => $groupId]);
                }
                $pdo->commit();
                $success = '已批量删除 ' . count($ids) . ' 个用户组，相关用户已移至未分组';
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = '批量删除失败，请重试';
            }
        }
    }
}

// 创建新组
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_group') {
    $group_name = trim($_POST['group_name'] ?? '');
    if ($group_name === '') {
        $error = '请输入组名称';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM `user_groups` WHERE `name` = :name");
            $stmt->execute([':name' => $group_name]);
            if ($stmt->fetchColumn() > 0) {
                $error = '该组名已存在';
            } else {
                $stmt = $pdo->prepare("INSERT INTO `user_groups` (`name`) VALUES (:name)");
                $stmt->execute([':name' => $group_name]);
                $success = '用户组创建成功';
            }
        } catch (PDOException $e) {
            $error = '数据库操作失败，请重试';
        }
    }
}

// 删除单个组
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $groupId = intval($_GET['id']);
    if ($groupId > 0) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("UPDATE `users` SET `group_id` = NULL WHERE `group_id` = :gid");
            $stmt->execute([':gid' => $groupId]);
            $stmt = $pdo->prepare("DELETE FROM `user_group_relation` WHERE `group_id` = :gid");
            $stmt->execute([':gid' => $groupId]);
            $stmt = $pdo->prepare("DELETE FROM `user_groups` WHERE `id` = :gid");
            $stmt->execute([':gid' => $groupId]);
            $pdo->commit();
            $success = '用户组已删除，相关用户已移至未分组';
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = '删除失败，请重试';
        }
    }
    header('Location: group_manage.php');
    exit;
}

// 组列表
$groups = [];
try {
    $sql = "SELECT g.id, g.name, g.created_at, COUNT(u.id) AS member_count 
            FROM `user_groups` g 
            LEFT JOIN `users` u ON u.group_id = g.id 
            GROUP BY g.id, g.name, g.created_at 
            ORDER BY g.id ASC";
    $stmt = $pdo->query($sql);
    $groups = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '用户组查询失败';
}

// 组内成员
$groupMembers = [];
$currentGroupName = '';
if (isset($_GET['view_group']) && intval($_GET['view_group']) > 0) {
    $viewGroupId = intval($_GET['view_group']);
    try {
        $stmt = $pdo->prepare("SELECT `name` FROM `user_groups` WHERE `id` = :gid");
        $stmt->execute([':gid' => $viewGroupId]);
        $grp = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($grp) {
            $currentGroupName = $grp['name'];
            $stmt = $pdo->prepare("SELECT `id`, `name` FROM `users` WHERE `group_id` = :gid ORDER BY `id` ASC");
            $stmt->execute([':gid' => $viewGroupId]);
            $groupMembers = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $stmt = $pdo->prepare("SELECT u.id, u.name FROM `user_group_relation` r JOIN `users` u ON r.user_id = u.id WHERE r.group_id = :gid ORDER BY u.id ASC");
            $stmt->execute([':gid' => $viewGroupId]);
            $additionalMembers = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $existingIds = array_column($groupMembers, 'id');
            foreach ($additionalMembers as $am) {
                if (!in_array($am['id'], $existingIds)) $groupMembers[] = $am;
            }
        }
    } catch (PDOException $e) {}
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户组管理</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>用户组管理</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
        <a href="user_manage.php" class="btn btn-secondary btn-sm">用户管理</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:600px;">
        <h2>创建新用户组</h2>
        <form method="post" action="group_manage.php" class="flex">
            <input type="hidden" name="action" value="create_group">
            <label style="font-size:13px;color:var(--text-light);">组名称</label>
            <input type="text" name="group_name" required style="max-width:240px;">
            <button type="submit" class="btn">创建</button>
        </form>
    </div>

    <div class="card" style="padding:0;overflow:hidden;">
        <div style="padding:16px 20px;border-bottom:1px solid var(--border);">
            <h2 style="margin:0;">现有用户组</h2>
        </div>
        <?php if (empty($groups)): ?>
            <p class="text-mute" style="padding:30px;text-align:center;">暂无用户组</p>
        <?php else: ?>
            <form method="post" action="group_manage.php" onsubmit="return confirm('确定删除选中的用户组吗？相关用户将变为未分组。');">
                <input type="hidden" name="action" value="bulk_delete">
                <table>
                    <tr>
                        <th style="width:40px;"><input type="checkbox" onclick="toggleAll(this)"></th>
                        <th style="width:60px;">ID</th>
                        <th>组名称</th>
                        <th style="width:100px;">成员数量</th>
                        <th style="width:170px;">创建时间</th>
                        <th style="width:170px;">操作</th>
                    </tr>
                    <?php foreach ($groups as $group): ?>
                    <tr>
                        <td><input type="checkbox" name="ids[]" value="<?php echo $group['id']; ?>"></td>
                        <td><?php echo $group['id']; ?></td>
                        <td><?php echo htmlspecialchars($group['name']); ?></td>
                        <td><?php echo $group['member_count']; ?></td>
                        <td><?php echo htmlspecialchars($group['created_at']); ?></td>
                        <td>
                            <a href="group_manage.php?view_group=<?php echo $group['id']; ?>" class="btn btn-sm btn-outline">查看成员</a>
                            <a href="group_manage.php?action=delete&id=<?php echo $group['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定删除该组吗？');">删除</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
                <div style="padding:14px 20px;border-top:1px solid var(--border);">
                    <button type="submit" class="btn btn-danger btn-sm">批量删除选中</button>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <?php if (isset($_GET['view_group']) && $currentGroupName !== ''): ?>
    <div class="card">
        <h2>组「<?php echo htmlspecialchars($currentGroupName); ?>」的成员（含附加组）</h2>
        <?php if (empty($groupMembers)): ?>
            <p class="text-mute">该组暂无成员。</p>
        <?php else: ?>
            <table>
                <tr><th style="width:80px;">ID</th><th>姓名</th></tr>
                <?php foreach ($groupMembers as $member): ?>
                <tr>
                    <td><?php echo $member['id']; ?></td>
                    <td><?php echo htmlspecialchars($member['name']); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <script>
        function toggleAll(source) {
            var checkboxes = document.querySelectorAll('input[name="ids[]"]');
            checkboxes.forEach(function(cb) { cb.checked = source.checked; });
        }
    </script>
</body>
</html>