<?php
// =============================================
// 文件名：login.php
// 用途：统一登录页（毛玻璃背景、居中卡片、选项卡动画）
// =============================================
session_start();
require_once 'config.php';

$error = '';
$success = '';
$reg_name = '';
$reg_relationship = 'stranger';
$activeTab = 'user-login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // 普通用户注册
    if ($action === 'user_register') {
        $name = trim($_POST['name'] ?? '');
        $password = $_POST['password'] ?? '';
        $inviteCode = trim($_POST['invite_code'] ?? '');
        $relationship = $_POST['relationship'] ?? 'stranger';

        $reg_name = $name;
        $reg_relationship = $relationship;
        $activeTab = 'user-register';

        if ($name === '' || $password === '' || $inviteCode === '') {
            $error = '请输入姓名、密码和邀请码';
        } elseif (!in_array($relationship, ['stranger', 'friend', 'classmate'])) {
            $error = '请选择正确的关系类型';
        } else {
            try {
                $stmt = $pdo->prepare("SELECT `id`, `max_uses`, `used_count` FROM `invite_codes` WHERE `code` = :code LIMIT 1");
                $stmt->execute([':code' => $inviteCode]);
                $invite = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$invite) {
                    $error = '邀请码无效';
                } elseif ($invite['used_count'] >= $invite['max_uses']) {
                    $error = '邀请码已用完';
                } else {
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM `users` WHERE `name` = :name");
                    $stmt->execute([':name' => $name]);
                    if ($stmt->fetchColumn() > 0) {
                        $error = '该姓名已注册，请直接登录';
                    } else {
                        $pdo->beginTransaction();
                        $groupName = ($relationship === 'friend') ? '朋友' : (($relationship === 'classmate') ? '同学' : '');
                        $groupId = null;
                        if ($groupName !== '') {
                            $stmt = $pdo->prepare("SELECT `id` FROM `user_groups` WHERE `name` = :gname");
                            $stmt->execute([':gname' => $groupName]);
                            $groupId = $stmt->fetchColumn();
                            if (!$groupId) {
                                $stmt = $pdo->prepare("INSERT INTO `user_groups` (`name`) VALUES (:gname)");
                                $stmt->execute([':gname' => $groupName]);
                                $groupId = $pdo->lastInsertId();
                            }
                        }
                        $stmt = $pdo->prepare("INSERT INTO `users` (`name`, `password`, `group_id`) VALUES (:name, :password, :group_id)");
                        $stmt->execute([
                            ':name' => $name, ':password' => md5($password), ':group_id' => $groupId
                        ]);
                        $newUserId = $pdo->lastInsertId();
                        $stmt = $pdo->prepare("UPDATE `invite_codes` SET `used_count` = `used_count` + 1 WHERE `id` = :id");
                        $stmt->execute([':id' => $invite['id']]);
                        $pdo->commit();

                        $_SESSION['user'] = $name;
                        $_SESSION['user_id'] = $newUserId;
                        $_SESSION['user_group'] = $groupName;
                        $_SESSION['user_group_ids'] = $groupId ? [$groupId] : [];
                        $_SESSION['user_group_names'] = $groupName ? [$groupName] : [];
                        header('Location: user_index.php');
                        exit;
                    }
                }
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = '系统错误，请稍后再试';
            }
        }
    }

    // 普通用户登录
    if ($action === 'user_login') {
        $name = trim($_POST['name'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($name === '' || $password === '') {
            $error = '请输入姓名和密码';
            $activeTab = 'user-login';
        } else {
            try {
                $stmt = $pdo->prepare("SELECT u.`id`, u.`password`, u.`group_id`, g.`name` AS group_name FROM `users` u LEFT JOIN `user_groups` g ON u.group_id = g.id WHERE u.name = :name LIMIT 1");
                $stmt->execute([':name' => $name]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$user || md5($password) !== $user['password']) {
                    $error = '姓名或密码错误';
                    $activeTab = 'user-login';
                } else {
                    $allGroupIds = [];
                    $allGroupNames = [];
                    if (!empty($user['group_id'])) {
                        $allGroupIds[] = (int)$user['group_id'];
                        if (!empty($user['group_name'])) $allGroupNames[] = $user['group_name'];
                    }
                    $stmt = $pdo->prepare("SELECT g.id, g.name FROM user_group_relation r JOIN user_groups g ON r.group_id = g.id WHERE r.user_id = :uid");
                    $stmt->execute([':uid' => $user['id']]);
                    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $g) {
                        if (!in_array((int)$g['id'], $allGroupIds)) {
                            $allGroupIds[] = (int)$g['id'];
                            $allGroupNames[] = $g['name'];
                        }
                    }

                    $_SESSION['user'] = $name;
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_group'] = $user['group_name'] ?? '';
                    $_SESSION['user_group_ids'] = $allGroupIds;
                    $_SESSION['user_group_names'] = $allGroupNames;
                    header('Location: user_index.php');
                    exit;
                }
            } catch (PDOException $e) {
                $error = '系统错误，请稍后再试';
                $activeTab = 'user-login';
            }
        }
    }

    // 管理员登录
    if ($action === 'admin_login') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($username === '' || $password === '') {
            $error = '请输入账号和密码';
            $activeTab = 'admin-login';
        } else {
            try {
                $stmt = $pdo->prepare("SELECT `username`, `password` FROM `admin` WHERE `username` = :username LIMIT 1");
                $stmt->execute([':username' => $username]);
                $admin = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$admin || md5($password) !== $admin['password']) {
                    $error = '账号或密码错误';
                    $activeTab = 'admin-login';
                } else {
                    $_SESSION['admin'] = $admin['username'];
                    header('Location: admin_index.php');
                    exit;
                }
            } catch (PDOException $e) {
                $error = '系统错误，请稍后再试';
                $activeTab = 'admin-login';
            }
        }
    }
}

// 读取设置
$siteFavicon = '';
$loginBg = '';
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'site_favicon' LIMIT 1");
    $siteFavicon = $stmt->fetchColumn();
    if ($siteFavicon === false) $siteFavicon = '';

    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'login_bg' LIMIT 1");
    $loginBg = $stmt->fetchColumn();
    if ($loginBg === false) $loginBg = '';
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录</title>
    <?php if ($siteFavicon !== ''): ?>
        <link rel="icon" href="<?php echo htmlspecialchars($siteFavicon, ENT_QUOTES, 'UTF-8'); ?>">
        <link rel="apple-touch-icon" href="<?php echo htmlspecialchars($siteFavicon, ENT_QUOTES, 'UTF-8'); ?>">
    <?php endif; ?>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", Arial, sans-serif; min-height: 100vh; display: flex; align-items: center; justify-content: center; background: #f0f2f5; position: relative; overflow-x: hidden; }
        .bg-layer { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; background-size: cover; background-position: center; filter: blur(8px); transform: scale(1.1); }
        .no-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .login-container { position: relative; z-index: 1; width: 100%; max-width: 430px; padding: 20px; }
        .login-card { background: rgba(255,255,255,0.65); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border-radius: 20px; border:1px solid rgba(255,255,255,0.4); box-shadow:0 12px 40px rgba(0,0,0,0.12); padding:32px 28px; }
        .login-card h1 { text-align:center; margin-bottom:24px; color:#1f2937; font-size: 22px; }
        .tab { display:flex; justify-content:center; gap:8px; margin-bottom:24px; flex-wrap: wrap; }
        .tab button { padding:8px 16px; border:1px solid rgba(255,255,255,0.5); border-radius:20px; cursor:pointer; font-size:13px; color:#333; background:rgba(255,255,255,0.4); transition:all 0.2s; font-family: inherit; }
        .tab button:hover { background:rgba(255,255,255,0.7); }
        .tab button.active-tab { background:#0f6bff; border-color:#0f6bff; color:#fff; font-weight:600; box-shadow: 0 4px 12px rgba(15,107,255,.35); }
        .tab-content { position:relative; }
        .tab-panel { display:none; }
        .tab-panel.active { display:block; animation: fadeInUp 0.3s; }
        @keyframes fadeInUp { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
        .tab-panel h2 { text-align:center; margin-bottom:18px; color:#444; font-size: 16px; }
        form { display:flex; flex-direction:column; gap:14px; }
        label { font-size:13px; color:#4b5563; display: block; }
        label input, label select { margin-top: 6px; }
        input[type="text"], input[type="password"], select {
            padding:11px 14px;
            border:1px solid rgba(255,255,255,0.6);
            border-radius:10px;
            background:rgba(255,255,255,0.7);
            font-size:14px;
            width:100%;
            outline:none;
            font-family: inherit;
            transition: all .2s;
        }
        input:focus, select:focus { background:#fff; border-color:#0f6bff; box-shadow: 0 0 0 3px rgba(15,107,255,.15); }
        button[type="submit"] {
            padding:11px;
            background:#0f6bff;
            color:white;
            border:none;
            border-radius:10px;
            cursor:pointer;
            font-size:15px;
            font-family: inherit;
            font-weight: 600;
            transition: background .2s;
            margin-top: 6px;
        }
        button[type="submit"]:hover { background:#0a54c4; }
        .error { color:#d63031; text-align:center; padding: 8px; background: rgba(255,235,235,.6); border-radius: 8px; font-size: 13px; }
        .success { color:#00b894; text-align:center; padding: 8px; background: rgba(230,255,240,.6); border-radius: 8px; font-size: 13px; }
        @media (max-width:480px) {
            .login-card { padding:22px 18px; }
            .tab button { padding:6px 10px; font-size:12px; }
        }
    </style>
    <script>
        function showTab(tabId) {
            document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
            document.querySelectorAll('.tab button').forEach(b => b.classList.remove('active-tab'));
            document.getElementById(tabId).classList.add('active');
            var btnMap = {'user-login':0,'user-register':1,'admin-login':2};
            var btns = document.querySelectorAll('.tab button');
            btns[btnMap[tabId]].classList.add('active-tab');
        }
        window.onload = function() { showTab('<?php echo $activeTab; ?>'); };
    </script>
</head>
<body>
    <?php if ($loginBg !== ''): ?>
        <div class="bg-layer" style="background-image:url('<?php echo htmlspecialchars($loginBg, ENT_QUOTES, 'UTF-8'); ?>')"></div>
    <?php else: ?>
        <div class="bg-layer no-bg"></div>
    <?php endif; ?>
    <div class="login-container">
        <div class="login-card">
            <h1>登录</h1>
            <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
            <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>
            <div class="tab">
                <button onclick="showTab('user-login')" class="active-tab">普通用户登录</button>
                <button onclick="showTab('user-register')">普通用户注册</button>
                <button onclick="showTab('admin-login')">管理员登录</button>
            </div>
            <div class="tab-content">
                <div id="user-login" class="tab-panel">
                    <h2>普通用户登录</h2>
                    <form method="post" action="login.php">
                        <input type="hidden" name="action" value="user_login">
                        <label>姓名<input type="text" name="name" required></label>
                        <label>密码<input type="password" name="password" required></label>
                        <button type="submit">登录</button>
                    </form>
                </div>
                <div id="user-register" class="tab-panel">
                    <h2>普通用户注册</h2>
                    <form method="post" action="login.php">
                        <input type="hidden" name="action" value="user_register">
                        <label>姓名<input type="text" name="name" value="<?php echo htmlspecialchars($reg_name); ?>" required></label>
                        <label>密码<input type="password" name="password" required></label>
                        <label>邀请码<input type="text" name="invite_code" required></label>
                        <label>与管理员的关系
                            <select name="relationship" required>
                                <option value="stranger" <?php echo $reg_relationship === 'stranger' ? 'selected' : ''; ?>>陌生人</option>
                                <option value="friend" <?php echo $reg_relationship === 'friend' ? 'selected' : ''; ?>>朋友</option>
                                <option value="classmate" <?php echo $reg_relationship === 'classmate' ? 'selected' : ''; ?>>同学</option>
                            </select>
                        </label>
                        <button type="submit">注册</button>
                    </form>
                </div>
                <div id="admin-login" class="tab-panel">
                    <h2>管理员登录</h2>
                    <form method="post" action="login.php">
                        <input type="hidden" name="action" value="admin_login">
                        <label>账号<input type="text" name="username" required></label>
                        <label>密码<input type="password" name="password" required></label>
                        <button type="submit">登录</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>