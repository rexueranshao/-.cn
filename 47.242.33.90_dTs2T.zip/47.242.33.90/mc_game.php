<?php
// =============================================
// 文件名：mc_game.php
// 用途：MC游戏联机板块（服务器列表 + 评论）
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$currentUser = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$isAdmin = isset($_SESSION['admin']);
$error = '';
$success = '';

// 处理评论提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_comment') {
    $serverId = intval($_POST['server_id'] ?? 0);
    $content = trim($_POST['content'] ?? '');
    if ($serverId <= 0) {
        $error = '无效的服务器';
    } elseif ($content === '') {
        $error = '评论内容不能为空';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO `mc_server_comments` (`server_id`, `user_name`, `content`) VALUES (:server_id, :user_name, :content)");
            $stmt->execute([
                ':server_id' => $serverId,
                ':user_name' => $currentUser,
                ':content' => $content
            ]);
            $success = '评论发表成功';
        } catch (PDOException $e) {
            $error = '评论发表失败，请稍后再试';
        }
    }
}

// 管理员删除评论
if ($isAdmin && isset($_GET['action']) && $_GET['action'] === 'delete_comment' && isset($_GET['comment_id'])) {
    $commentId = intval($_GET['comment_id']);
    if ($commentId > 0) {
        try {
            $stmt = $pdo->prepare("DELETE FROM `mc_server_comments` WHERE `id` = :id");
            $stmt->execute([':id' => $commentId]);
            $success = '评论已删除';
        } catch (PDOException $e) {
            $error = '删除失败，请重试';
        }
    }
    header('Location: mc_game.php');
    exit;
}

// 查询服务器列表
$servers = [];
try {
    $stmt = $pdo->query("SELECT * FROM `mc_servers` ORDER BY `id` ASC");
    $servers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '服务器列表查询失败，请稍后再试';
}

// 查询评论分组
$comments = [];
try {
    $stmt = $pdo->query("SELECT * FROM `mc_server_comments` ORDER BY `created_at` ASC, `id` ASC");
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $c) {
        $comments[$c['server_id']][] = $c;
    }
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MC游戏联机</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .server-card { background: #fff; border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; margin-bottom: 20px; box-shadow: var(--shadow-sm); }
        .server-card img { max-width: 100%; max-height: 200px; border-radius: 8px; }
        .server-title { font-size: 1.35em; font-weight: 700; margin: 12px 0; }
        .server-address { background: #eef1f6; padding: 5px 12px; border-radius: 6px; display: inline-block; font-family: "SF Mono", Consolas, monospace; font-size: 13px; }
        .comment-section { margin-top: 20px; border-top: 1px solid var(--border); padding-top: 14px; }
        .comment-item { padding: 10px 0; border-bottom: 1px solid #f1f4f9; }
        .comment-item:last-child { border-bottom: none; }
        .comment-item .user { font-weight: 600; }
        .comment-item .time { font-size: 12px; color: #9aa4b5; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>MC游戏联机</h1>
    <p class="page-nav">
        <a href="user_index.php" class="btn btn-secondary btn-sm">返回首页</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <?php if (empty($servers)): ?>
        <p class="text-mute">暂无服务器信息，请管理员添加。</p>
    <?php else: ?>
        <?php foreach ($servers as $s): ?>
        <div class="server-card">
            <?php if ($s['server_image']): ?>
                <img src="<?php echo htmlspecialchars($s['server_image']); ?>" alt="宣传图">
            <?php endif; ?>
            <div class="server-title"><?php echo htmlspecialchars($s['server_name']); ?>（编号：<?php echo htmlspecialchars($s['server_number']); ?>）</div>
            <p><?php echo nl2br(htmlspecialchars($s['description'])); ?></p>
            <p><strong>服务器地址：</strong>
                <span class="server-address" id="addr-<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['server_address']); ?></span>
                <button type="button" class="btn btn-sm" style="margin-left:8px;" onclick="copyAddress(<?php echo $s['id']; ?>)">复制地址</button>
            </p>
            <?php if ($s['requirements']): ?>
                <p><strong>加入要求：</strong><br><?php echo nl2br(htmlspecialchars($s['requirements'])); ?></p>
            <?php endif; ?>
            <?php if ($s['modpack_url']): ?>
                <p><strong>整合包下载：</strong><a href="<?php echo htmlspecialchars($s['modpack_url']); ?>" target="_blank">点击下载整合包</a></p>
            <?php endif; ?>

            <div class="comment-section">
                <h3>评论（<?php echo isset($comments[$s['id']]) ? count($comments[$s['id']]) : 0; ?>）</h3>
                <?php if (!empty($comments[$s['id']])): ?>
                    <?php foreach ($comments[$s['id']] as $comment): ?>
                        <div class="comment-item">
                            <span class="user"><?php echo htmlspecialchars($comment['user_name']); ?></span>
                            <span class="time"><?php echo htmlspecialchars($comment['created_at']); ?></span>
                            <?php if ($isAdmin): ?>
                                <a href="mc_game.php?action=delete_comment&comment_id=<?php echo $comment['id']; ?>" style="font-size:12px;color:var(--danger);margin-left:8px;" onclick="return confirm('确定删除该评论？');">删除</a>
                            <?php endif; ?>
                            <div class="mt-10"><?php echo nl2br(htmlspecialchars($comment['content'])); ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-mute">暂无评论，来发表第一条吧。</p>
                <?php endif; ?>

                <form method="post" action="mc_game.php" class="mt-10">
                    <input type="hidden" name="action" value="add_comment">
                    <input type="hidden" name="server_id" value="<?php echo $s['id']; ?>">
                    <textarea name="content" rows="2" placeholder="写下你的评论..." required></textarea>
                    <p class="mt-10"><button type="submit" class="btn btn-sm">发表评论</button></p>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <script>
        function copyAddress(id) {
            var text = document.getElementById('addr-' + id).innerText;
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(function() {
                    alert('地址已复制');
                }).catch(function() {
                    fallbackCopy(text);
                });
            } else {
                fallbackCopy(text);
            }
        }
        function fallbackCopy(text) {
            var temp = document.createElement('textarea');
            temp.value = text;
            document.body.appendChild(temp);
            temp.select();
            document.execCommand('copy');
            document.body.removeChild(temp);
            alert('地址已复制');
        }
    </script>
</body>
</html>