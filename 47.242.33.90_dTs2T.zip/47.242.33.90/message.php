<?php
// =============================================
// 文件名：message.php
// 用途：普通用户留言页
// =============================================
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$currentUser = $_SESSION['user'];
$error = '';
$success = '';

// 提交留言
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['content'])) {
    $content = trim($_POST['content'] ?? '');
    if ($content === '') {
        $error = '留言内容不能为空';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO `messages` (`user_name`, `content`) VALUES (:user_name, :content)");
            $stmt->execute([':user_name' => $currentUser, ':content' => $content]);
            $success = '留言提交成功！';
        } catch (PDOException $e) {
            $error = '提交失败，请稍后再试';
        }
    }
}

// 删除自己的留言
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $deleteId = intval($_GET['id']);
    if ($deleteId > 0) {
        try {
            $stmt = $pdo->prepare("DELETE FROM `messages` WHERE `id` = :id AND `user_name` = :user_name");
            $stmt->execute([':id' => $deleteId, ':user_name' => $currentUser]);
            $success = '留言已删除';
        } catch (PDOException $e) {
            $error = '删除失败，请稍后再试';
        }
    }
    header('Location: message.php');
    exit;
}

// 查询我的留言
$myMessages = [];
try {
    $stmt = $pdo->prepare("SELECT `id`, `content`, `created_at` FROM `messages` WHERE `user_name` = :user_name ORDER BY `created_at` DESC, `id` DESC");
    $stmt->execute([':user_name' => $currentUser]);
    $myMessages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '留言查询失败，请稍后再试';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>留言板</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>留言板</h1>
    <p class="page-nav">
        <a href="user_index.php" class="btn btn-secondary btn-sm">返回首页</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card">
        <h2>提交留言</h2>
        <form method="post" action="message.php">
            <textarea name="content" placeholder="请输入功能建议、bug提交等内容..." rows="4" required></textarea>
            <p class="mt-10"><button type="submit" class="btn">提交留言</button></p>
        </form>
    </div>

    <div class="card">
        <h2>我的留言</h2>
        <?php if (empty($myMessages)): ?>
            <p class="text-mute">暂无留言记录。</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>留言内容</th>
                    <th style="width:180px;">提交时间</th>
                    <th style="width:80px;">操作</th>
                </tr>
                <?php foreach ($myMessages as $msg): ?>
                <tr>
                    <td><?php echo htmlspecialchars($msg['content']); ?></td>
                    <td><?php echo htmlspecialchars($msg['created_at']); ?></td>
                    <td>
                        <a href="message.php?action=delete&id=<?php echo $msg['id']; ?>" 
                           onclick="return confirm('确定要删除这条留言吗？');">删除</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>