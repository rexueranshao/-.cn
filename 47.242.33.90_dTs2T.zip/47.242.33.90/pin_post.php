<?php
// =============================================
// 文件名：pin_post.php
// 用途：帖子置顶操作
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$currentUser = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$isAdmin = isset($_SESSION['admin']);
$postId = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;
$error = '';
$success = '';

$post = null;
if ($postId > 0) {
    try {
        $stmt = $pdo->prepare("SELECT `id`, `user_name`, `title`, `is_pinned`, `pinned_until` FROM `forum_posts` WHERE `id` = :id");
        $stmt->execute([':id' => $postId]);
        $post = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$post) $error = '帖子不存在';
    } catch (PDOException $e) {
        $error = '查询失败，请稍后再试';
    }
} else {
    $error = '无效的帖子ID';
}

if ($post && !$isAdmin && $post['user_name'] !== $currentUser) {
    $error = '您没有权限置顶此帖子';
}

$userPoints = 0;
if (!$isAdmin && $post) {
    try {
        $stmt = $pdo->prepare("SELECT `points` FROM `users` WHERE `name` = :name");
        $stmt->execute([':name' => $currentUser]);
        $userPoints = (int)$stmt->fetchColumn();
    } catch (PDOException $e) {
        $error = '获取积分失败';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $post && !$error) {
    $days = intval($_POST['days'] ?? 0);
    $priceMap = [1 => 100, 3 => 280, 7 => 600];
    if (!isset($priceMap[$days])) {
        $error = '请选择有效的置顶天数';
    } else {
        $price = $priceMap[$days];
        if (!$isAdmin && $userPoints < $price) {
            $error = '积分不足，需要' . $price . '积分，当前积分' . $userPoints;
        } else {
            try {
                $pdo->beginTransaction();
                if (!$isAdmin) {
                    $stmt = $pdo->prepare("UPDATE `users` SET `points` = `points` - :price WHERE `name` = :name");
                    $stmt->execute([':price' => $price, ':name' => $currentUser]);
                }
                $stmt = $pdo->prepare("UPDATE `forum_posts` SET `is_pinned` = 1, `pinned_until` = DATE_ADD(NOW(), INTERVAL :days DAY) WHERE `id` = :id");
                $stmt->execute([':days' => $days, ':id' => $postId]);
                $pdo->commit();
                $success = '置顶成功，到期时间已更新';
                $stmt = $pdo->prepare("SELECT `is_pinned`, `pinned_until` FROM `forum_posts` WHERE `id` = :id");
                $stmt->execute([':id' => $postId]);
                $newInfo = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($newInfo) {
                    $post['is_pinned'] = $newInfo['is_pinned'];
                    $post['pinned_until'] = $newInfo['pinned_until'];
                }
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = '置顶失败，请稍后再试';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>帖子置顶</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <p class="page-nav">
        <a href="forum.php" class="btn btn-secondary btn-sm">返回论坛</a>
        <a href="user_index.php" class="btn btn-secondary btn-sm">返回首页</a>
    </p>

    <h1>帖子置顶</h1>
    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <?php if ($post && !$error): ?>
        <div class="card" style="max-width:520px;">
            <p>帖子标题：<strong><?php echo htmlspecialchars($post['title']); ?></strong></p>
            <?php if ($post['is_pinned'] && strtotime($post['pinned_until']) > time()): ?>
                <p class="text-mute">当前置顶到期时间：<?php echo htmlspecialchars($post['pinned_until']); ?></p>
            <?php endif; ?>
            <form method="post" action="pin_post.php?post_id=<?php echo $postId; ?>">
                <div style="margin-bottom:14px;">
                    <label style="display:block;margin-bottom:6px;font-size:13px;color:var(--text-light);">选择置顶天数</label>
                    <select name="days" required>
                        <option value="1">1 天（100 积分）</option>
                        <option value="3">3 天（280 积分）</option>
                        <option value="7">7 天（600 积分）</option>
                    </select>
                </div>
                <?php if ($isAdmin): ?>
                    <p class="text-mute">管理员置顶不消耗积分</p>
                <?php else: ?>
                    <p class="text-mute">当前积分：<?php echo $userPoints; ?></p>
                <?php endif; ?>
                <p class="mt-20"><button type="submit" class="btn">确认置顶</button></p>
            </form>
        </div>
    <?php endif; ?>
</body>
</html>