<?php
// =============================================
// 文件名：program_list.php
// 用途：管理员查看全部节目报名数据
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

// 删除
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $deleteId = intval($_GET['id']);
    if ($deleteId > 0) {
        try {
            $stmt = $pdo->prepare("DELETE FROM `program_registrations` WHERE `id` = :id");
            $stmt->execute([':id' => $deleteId]);
        } catch (PDOException $e) {}
    }
    header('Location: program_list.php');
    exit;
}

$records = [];
$error = '';
try {
    $stmt = $pdo->query("SELECT * FROM `program_registrations` ORDER BY `created_at` DESC, `id` DESC");
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '数据查询失败，请检查表是否存在。';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>节目列表浏览</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>节目报名列表</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
        <a href="program_signup.php" class="btn btn-sm">新增报名</a>
    </p>

    <?php if ($error): ?>
        <p class="error"><?php echo htmlspecialchars($error); ?></p>
    <?php elseif (empty($records)): ?>
        <p class="text-mute">暂无报名数据。</p>
    <?php else: ?>
        <table>
            <tr>
                <th style="width:60px;">序号</th>
                <th style="width:110px;">姓名</th>
                <th>节目名称</th>
                <th style="width:100px;">节目类型</th>
                <th style="width:100px;">预估时长</th>
                <th>道具需求</th>
                <th>备注</th>
                <th style="width:160px;">提交时间</th>
                <th style="width:80px;">操作</th>
            </tr>
            <?php foreach ($records as $row): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['program_name']); ?></td>
                <td><?php echo htmlspecialchars($row['program_type']); ?></td>
                <td><?php echo htmlspecialchars($row['duration']); ?></td>
                <td><?php echo htmlspecialchars($row['props']); ?></td>
                <td><?php echo htmlspecialchars($row['remark']); ?></td>
                <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                <td>
                    <a href="program_list.php?action=delete&id=<?php echo $row['id']; ?>" 
                       onclick="return confirm('确定要删除该条报名记录吗？');">删除</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</body>
</html>