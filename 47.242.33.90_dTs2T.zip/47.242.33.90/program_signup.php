<?php
// =============================================
// 文件名：program_signup.php
// 用途：管理员新增节目报名页
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $program_name = trim($_POST['program_name'] ?? '');
    $program_type = trim($_POST['program_type'] ?? '');
    $duration = trim($_POST['duration'] ?? '');
    $props = trim($_POST['props'] ?? '');
    $remark = trim($_POST['remark'] ?? '');

    if ($name === '' || $program_name === '' || $program_type === '' || $duration === '') {
        $error = '请填写所有必填项（姓名、节目名称、节目类型、预估时长）';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO `program_registrations` (`name`, `program_name`, `program_type`, `duration`, `props`, `remark`) VALUES (:name, :program_name, :program_type, :duration, :props, :remark)");
            $stmt->execute([
                ':name' => $name, ':program_name' => $program_name,
                ':program_type' => $program_type, ':duration' => $duration,
                ':props' => $props, ':remark' => $remark,
            ]);
            $success = '报名成功！';
        } catch (PDOException $e) {
            $error = '数据库写入失败，请检查表是否存在或字段是否匹配。';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>节目新增报名</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-row { margin-bottom: 12px; }
        .form-row label { display: block; margin-bottom: 5px; font-weight: 500; color: var(--text-light); font-size: 13px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>节目新增报名</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
        <a href="program_list.php" class="btn btn-secondary btn-sm">查看节目列表</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:640px;">
        <form method="post" action="program_signup.php">
            <div class="form-row">
                <label>报名人姓名</label>
                <input type="text" name="name" required>
            </div>
            <div class="form-row">
                <label>节目名称</label>
                <input type="text" name="program_name" required>
            </div>
            <div class="form-row">
                <label>节目类型</label>
                <input type="text" name="program_type" required placeholder="如：歌舞、小品、魔术等">
            </div>
            <div class="form-row">
                <label>预估时长</label>
                <input type="text" name="duration" required placeholder="如：5分钟、3-5分钟">
            </div>
            <div class="form-row">
                <label>道具需求</label>
                <textarea name="props" rows="3"></textarea>
            </div>
            <div class="form-row">
                <label>备注</label>
                <textarea name="remark" rows="3"></textarea>
            </div>
            <button type="submit" class="btn">提交报名</button>
        </form>
    </div>
</body>
</html>