<?php
// =============================================
// 文件名：report.php
// 用途：处理用户举报（AI检测，支持人工复议）
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';
require_once 'ai_functions.php';

$currentUser = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$currentUserId = $_SESSION['user_id'] ?? 0;

$targetType = $_GET['type'] ?? '';
$targetId = intval($_GET['id'] ?? 0);
$confirmManual = isset($_GET['confirm']) && $_GET['confirm'] == '1';

$error = '';
$success = '';
$showManualButton = false;

if (!in_array($targetType, ['chat_message','forum_post','forum_reply']) || $targetId <= 0) {
    $error = '无效的举报目标';
} else {
    $content = '';
    if ($targetType == 'chat_message') {
        $stmt = $pdo->prepare("SELECT content FROM chat_messages WHERE id = :id");
    } elseif ($targetType == 'forum_post') {
        $stmt = $pdo->prepare("SELECT CONCAT(title, '\n', content) AS content FROM forum_posts WHERE id = :id");
    } else {
        $stmt = $pdo->prepare("SELECT content FROM forum_replies WHERE id = :id");
    }
    $stmt->execute([':id' => $targetId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        $error = '举报目标不存在';
    } else {
        $content = $row['content'] ?? '';

        if ($confirmManual) {
            try {
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("INSERT INTO reports (target_type, target_id, reporter_user_id, reason, ai_safe, ai_reason, status) VALUES (:type, :target, :reporter, :reason, NULL, NULL, 'pending_manual')");
                $stmt->execute([
                    ':type' => $targetType, ':target' => $targetId,
                    ':reporter' => $currentUserId, ':reason' => '用户坚持举报并申请人工复议'
                ]);
                if ($targetType == 'chat_message') {
                    $stmt = $pdo->prepare("UPDATE chat_messages SET status = 'pending_manual' WHERE id = :id");
                } elseif ($targetType == 'forum_post') {
                    $stmt = $pdo->prepare("UPDATE forum_posts SET status = 'pending_manual' WHERE id = :id");
                } else {
                    $stmt = $pdo->prepare("UPDATE forum_replies SET status = 'pending_manual' WHERE id = :id");
                }
                $stmt->execute([':id' => $targetId]);
                $pdo->commit();
                $success = '已提交人工复议，请等待管理员处理';
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = '提交失败，请稍后再试';
            }
        } else {
            $aiResult = ai_check_content($content);
            if ($aiResult['safe']) {
                $showManualButton = true;
                $success = 'AI审核结果：内容安全。如果您仍认为该内容违规，可以申请人工复议。';
            } else {
                try {
                    $pdo->beginTransaction();
                    $stmt = $pdo->prepare("INSERT INTO reports (target_type, target_id, reporter_user_id, reason, ai_safe, ai_reason, status) VALUES (:type, :target, :reporter, :reason, 0, :ai_reason, 'resolved_unsafe')");
                    $stmt->execute([
                        ':type' => $targetType, ':target' => $targetId,
                        ':reporter' => $currentUserId, ':reason' => '用户举报',
                        ':ai_reason' => $aiResult['reason']
                    ]);
                    if ($targetType == 'chat_message') {
                        $stmt = $pdo->prepare("UPDATE chat_messages SET status = 'rejected' WHERE id = :id");
                    } elseif ($targetType == 'forum_post') {
                        $stmt = $pdo->prepare("UPDATE forum_posts SET status = 'rejected' WHERE id = :id");
                    } else {
                        $stmt = $pdo->prepare("UPDATE forum_replies SET status = 'rejected' WHERE id = :id");
                    }
                    $stmt->execute([':id' => $targetId]);
                    $pdo->commit();
                    $success = '举报成功，内容已下架';
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $error = '处理失败，请稍后再试';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>举报结果</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <div class="card" style="max-width:600px;">
        <h1 style="border:none;padding:0;">举报处理</h1>
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
            <p class="mt-20"><a href="javascript:history.back()" class="btn btn-secondary">返回</a></p>
        <?php else: ?>
            <p class="success"><?php echo htmlspecialchars($success); ?></p>
            <?php if ($showManualButton): ?>
                <p class="mt-20">如果您坚持认为该内容违规，可以申请人工复议：</p>
                <p class="mt-10"><a href="report.php?type=<?php echo urlencode($targetType); ?>&id=<?php echo $targetId; ?>&confirm=1" class="btn btn-warning">申请人工复议</a></p>
            <?php endif; ?>
            <p class="mt-20"><a href="javascript:history.back()" class="btn btn-secondary">返回</a></p>
        <?php endif; ?>
    </div>
</body>
</html>