<?php
session_start();

if (isset($_GET['getdata'])) {
    header('Content-Type: application/json');

    // 1分钟系统负载
    $loadRaw = explode(' ', trim(file_get_contents('/proc/loadavg')));
    $load1 = $loadRaw[0];

    // 内存信息
    $meminfo = file_get_contents('/proc/meminfo');
    preg_match('/MemTotal:\s+(\d+)/', $meminfo, $total);
    preg_match('/MemAvailable:\s+(\d+)/', $meminfo, $avail);
    $memTotal = round((int)$total[1] / 1024, 2);
    $memUsed = round(((int)$total[1] - (int)$avail[1]) / 1024, 2);

    // CPU使用率计算
    $stat = file_get_contents('/proc/stat');
    preg_match('/^cpu\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)/', $stat, $cpu);
    $idle = $cpu[4] + $cpu[5];
    $totalCpu = array_sum(array_slice($cpu, 1, 7));
    
    $cpuUsage = 0;
    if (isset($_SESSION['last_cpu']) && isset($_SESSION['last_idle'])) {
        $deltaTotal = $totalCpu - $_SESSION['last_cpu'];
        $deltaIdle = $idle - $_SESSION['last_idle'];
        if ($deltaTotal > 0) {
            $cpuUsage = round((1 - $deltaIdle / $deltaTotal) * 100, 2);
        }
    }
    $_SESSION['last_cpu'] = $totalCpu;
    $_SESSION['last_idle'] = $idle;

    // 历史数据存入session
    if (!isset($_SESSION['history'])) {
        $_SESSION['history'] = [];
    }
    $_SESSION['history'][] = [
        'time' => time(),
        'mem'  => $memUsed,
        'cpu'  => $cpuUsage,
        'load' => $load1
    ];

    // 只保留24小时内数据
    $cutoff = time() - 86400;
    $_SESSION['history'] = array_values(array_filter(
        $_SESSION['history'],
        fn($item) => $item['time'] > $cutoff
    ));

    echo json_encode([
        'total' => $memTotal,
        'used'  => $memUsed,
        'cpu'   => $cpuUsage,
        'load'  => $load1,
        'list'  => $_SESSION['history']
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>服务器实时监控</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { padding: 20px; font-family: system-ui, sans-serif; background: #f5f5f5; }
    .header { margin-bottom: 16px; }
    .info { margin-bottom: 12px; color: #333; font-size: 14px; line-height: 1.8; }
    .btns { margin: 12px 0; }
    .btns button {
        padding: 6px 14px; margin-right: 8px; border: 1px solid #ddd;
        background: #fff; border-radius: 4px; cursor: pointer;
    }
    .btns button.active { background: #1677ff; color: #fff; border-color: #1677ff; }
    .chart-box { background: #fff; padding: 16px; border-radius: 8px; height: 420px; }
    #monitorChart { width: 100%; height: 100%; }
</style>
</head>
<body>

<div class="header">
    <h2>服务器实时监控</h2>
</div>

<div class="info">
    内存总量：<span id="memTotal">-</span> MB<br>
    已用内存：<span id="memUsed">-</span> MB<br>
    CPU使用率：<span id="cpuVal">-</span> %<br>
    1分钟负载：<span id="loadVal">-</span>
</div>

<div class="btns">
    <button data-range="30" class="active">实时</button>
    <button data-range="1800">半小时</button>
    <button data-range="3600">1小时</button>
    <button data-range="21600">6小时</button>
    <button data-range="86400">24小时</button>
</div>

<div class="chart-box">
    <canvas id="monitorChart"></canvas>
</div>

<script>
let chart = null;
let currentRange = 30; // 默认实时30秒

function initChart() {
    const ctx = document.getElementById('monitorChart').getContext('2d');
    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: '已用内存 (MB)',
                    data: [],
                    borderColor: '#1677ff',
                    backgroundColor: 'rgba(22, 119, 255, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.25,
                    pointRadius: 3,
                    pointHoverRadius: 5,
                    pointBackgroundColor: '#1677ff',
                    yAxisID: 'y'
                },
                {
                    label: 'CPU使用率 (%)',
                    data: [],
                    borderColor: '#ff7d00',
                    backgroundColor: 'rgba(255, 125, 0, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.25,
                    pointRadius: 3,
                    pointHoverRadius: 5,
                    pointBackgroundColor: '#ff7d00',
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 200 },
            scales: {
                x: {
                    display: true,
                    title: { display: true, text: '时间' },
                    ticks: { maxTicksLimit: 10, maxRotation: 0 }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    beginAtZero: true,
                    title: { display: true, text: '内存 (MB)' }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    beginAtZero: true,
                    max: 100,
                    title: { display: true, text: 'CPU (%)' },
                    grid: { drawOnChartArea: false }
                }
            },
            plugins: {
                legend: { display: true, position: 'top' },
                tooltip: { mode: 'index', intersect: false }
            }
        }
    });
}

function refreshData() {
    fetch('status.php?getdata=1')
        .then(res => res.json())
        .then(data => {
            document.getElementById('memTotal').innerText = data.total;
            document.getElementById('memUsed').innerText = data.used;
            document.getElementById('cpuVal').innerText = data.cpu;
            document.getElementById('loadVal').innerText = data.load;

            const now = Math.floor(Date.now() / 1000);
            // 按选择的时间范围过滤，实时只留30秒
            const list = data.list.filter(item => item.time >= now - currentRange);

            chart.data.labels = list.map(item => {
                const d = new Date(item.time * 1000);
                return `${d.getHours().toString().padStart(2,'0')}:${d.getMinutes().toString().padStart(2,'0')}:${d.getSeconds().toString().padStart(2,'0')}`;
            });
            chart.data.datasets[0].data = list.map(item => item.mem);
            chart.data.datasets[1].data = list.map(item => item.cpu);
            chart.update();
        });
}

document.querySelectorAll('.btns button').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.btns button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentRange = parseInt(btn.dataset.range);
        refreshData();
    });
});

initChart();
refreshData();
setInterval(refreshData, 2000); // 2秒刷新一次
</script>

</body>
</html>