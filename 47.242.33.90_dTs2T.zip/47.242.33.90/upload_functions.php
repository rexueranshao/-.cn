<?php
// =============================================
// 文件名：upload_functions.php
// 用途：统一处理用户上传图片
// =============================================

function handle_image_upload($file, $subDir = 'chat') {
    if (!isset($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['success' => true, 'url' => '', 'error' => ''];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $msg = '上传失败，错误码：' . $file['error'];
        if ($file['error'] === UPLOAD_ERR_INI_SIZE) $msg = '图片超过服务器限制（upload_max_filesize）';
        if ($file['error'] === UPLOAD_ERR_FORM_SIZE) $msg = '图片超过表单限制';
        if ($file['error'] === UPLOAD_ERR_PARTIAL) $msg = '图片上传不完整';
        if ($file['error'] === UPLOAD_ERR_NO_TMP_DIR) $msg = '服务器缺少临时目录';
        if ($file['error'] === UPLOAD_ERR_CANT_WRITE) $msg = '服务器无法写入文件';
        if ($file['error'] === UPLOAD_ERR_EXTENSION) $msg = 'PHP 扩展阻止了上传';
        return ['success' => false, 'url' => '', 'error' => $msg];
    }

    $maxSize = 5 * 1024 * 1024;
    $imageInfo = @getimagesize($file['tmp_name']);
    if ($imageInfo === false) {
        return ['success' => false, 'url' => '', 'error' => '仅支持 JPG/PNG/GIF/WEBP'];
    }
    if ($file['size'] > $maxSize) {
        return ['success' => false, 'url' => '', 'error' => '图片不能超过 5MB'];
    }

    $mime = $imageInfo['mime'];
    $allowedMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($mime, $allowedMimes)) {
        return ['success' => false, 'url' => '', 'error' => '仅支持 JPG/PNG/GIF/WEBP'];
    }

    $extMap = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
    ];
    $ext = $extMap[$mime] ?? 'jpg';
    $newFileName = $subDir . '_' . date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;

    $uploadDir = __DIR__ . '/uploads/' . $subDir . '/';
    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0755, true)) {
            return ['success' => false, 'url' => '', 'error' => '无法创建上传目录'];
        }
    }
    $targetPath = $uploadDir . $newFileName;

    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => false, 'url' => '', 'error' => '文件保存失败，请检查目录权限'];
    }

    return [
        'success' => true,
        'url' => 'uploads/' . $subDir . '/' . $newFileName,
        'error' => ''
    ];
}