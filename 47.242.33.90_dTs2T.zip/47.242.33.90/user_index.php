<?php
// =============================================
// 文件名：user_index.php
// 用途：普通用户首页（含 MC/报名/论坛/云盘 入口）
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$currentName = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$isUser = isset($_SESSION['user']);

// 报名开关
$programSignupEnabled = false;
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'program_signup_enabled' LIMIT 1");
    $val = $stmt->fetchColumn();
    if ($val === '1') $programSignupEnabled = true;
} catch (PDOException $e) {}

// 所有组（主组 + 附加组）
$userGroupIds = [];
$userGroupNames = [];
if ($isUser) {
    try {
        $stmt = $pdo->prepare("SELECT u.group_id, g.name FROM users u LEFT JOIN user_groups g ON u.group_id = g.id WHERE u.name = :name");
        $stmt->execute([':name' => $currentName]);
        $main = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($main && !empty($main['group_id'])) {
            $userGroupIds[] = (int)$main['group_id'];
            if (!empty($main['name'])) $userGroupNames[] = $main['name'];
        }
        $stmt = $pdo->prepare("SELECT g.id, g.name FROM user_group_relation r JOIN user_groups g ON r.group_id = g.id JOIN users u ON r.user_id = u.id WHERE u.name = :name");
        $stmt->execute([':name' => $currentName]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $g) {
            if (!in_array((int)$g['id'], $userGroupIds)) {
                $userGroupIds[] = (int)$g['id'];
                $userGroupNames[] = $g['name'];
            }
        }
    } catch (PDOException $e) {
        $userGroupIds = $_SESSION['user_group_ids'] ?? [];
        $userGroupNames = $_SESSION['user_group_names'] ?? [];
    }
}

// 报名入口：管理员或所有组只有"同学"
$showProgramSignup = isset($_SESSION['admin'])
    || ($isUser && $programSignupEnabled && count($userGroupNames) === 1 && $userGroupNames[0] === '同学');

// MC 板块
$mcAllowedGroups = [];
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'mc_game_groups' LIMIT 1");
    $val = $stmt->fetchColumn();
    if ($val !== false && $val !== '') $mcAllowedGroups = array_map('intval', explode(',', $val));
} catch (PDOException $e) {}

$showMcGame = isset($_SESSION['admin'])
    || ($isUser && !empty($userGroupIds) && count(array_intersect($userGroupIds, $mcAllowedGroups)) > 0);

// 聊天室未读
$totalUnread = 0;
if ($isUser && isset($_SESSION['user_id'])) {
    try {
        $sql = "SELECT SUM(unread) AS total FROM (
            SELECT cr.id,
                   (SELECT COUNT(*) FROM chat_messages cm 
                    WHERE cm.room_id = cr.id 
                    AND cm.id > COALESCE((SELECT last_read_message_id FROM chat_reads WHERE user_id = :uid AND room_id = cr.id), 0)
                   ) AS unread
            FROM chat_rooms cr
        ) t";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':uid' => $_SESSION['user_id']]);
        $totalUnread = (int)$stmt->fetchColumn();
    } catch (PDOException $e) {}
}

// 页脚
$siteFooter = '';
try {
    $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'site_footer' LIMIT 1");
    $siteFooter = $stmt->fetchColumn();
    if ($siteFooter === false) $siteFooter = '';
} catch (PDOException $e) {}

// 云盘占用
$cloudCount = 0;
$cloudSize = 0;
if ($isUser && isset($_SESSION['user_id'])) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) AS cnt, COALESCE(SUM(file_size),0) AS sz FROM cloud_files WHERE user_id = :uid AND is_folder = 0");
        $stmt->execute([':uid' => $_SESSION['user_id']]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $cloudCount = (int)$row['cnt'];
        $cloudSize = (int)$row['sz'];
    } catch (PDOException $e) {}
}

function humanSize($b) {
    if ($b <= 0) return '0 B';
    $u = ['B','KB','MB','GB','TB'];
    $i = floor(log($b, 1024));
    if ($i >= count($u)) $i = count($u) - 1;
    return round($b / pow(1024, $i), 2) . ' ' . $u[$i];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户首页</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .header-actions { display: flex; gap: 10px; flex-wrap: wrap; }
        .menu { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 18px; margin: 20px 0; }
        .menu-item {
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 12px;
            height: 150px;
            text-decoration: none;
            color: var(--text);
            font-size: 15px;
            font-weight: 600;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
            transition: all .2s;
        }
        .menu-item:hover {
            transform: translateY(-3px);
            border-color: var(--accent);
            color: var(--accent);
            box-shadow: 0 10px 30px rgba(15,107,255,.15);
            text-decoration: none;
            opacity: 1;
        }
        .menu-item .icon {
            width: 48px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            color: #fff;
        }
        .menu-item .icon svg { width: 24px; height: 24px; }
        .menu-item.mc .icon { background: linear-gradient(135deg, #2ecc71, #159a52); }
        .menu-item.program .icon { background: linear-gradient(135deg, #f39c12, #c77413); }
        .menu-item.forum .icon { background: linear-gradient(135deg, #a55eea, #7e3a9e); }
        .menu-item.cloud .icon { background: linear-gradient(135deg, #4b8dff, #0f6bff); }
        .menu-item .badge-info {
            position: absolute;
            top: 12px;
            right: 12px;
            background: var(--accent-soft);
            color: var(--accent-hover);
            border-radius: 8px;
            padding: 2px 9px;
            font-size: 11px;
            font-weight: 500;
        }
        .small-btn-row { display: flex; gap: 12px; flex-wrap: wrap; margin: 20px 0; }
        .small-btn {
            position: relative;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 22px;
            border-radius: var(--radius);
            font-size: 14px;
            font-weight: 500;
            color: var(--text);
            text-decoration: none;
            background: #fff;
            border: 1px solid var(--border);
            box-shadow: var(--shadow-sm);
            transition: all .2s;
        }
        .small-btn:hover {
            transform: translateY(-2px);
            border-color: var(--accent);
            color: var(--accent);
            text-decoration: none;
            opacity: 1;
            box-shadow: 0 8px 20px rgba(15,107,255,.12);
        }
        .small-btn svg { width: 16px; height: 16px; color: var(--accent); }
        .small-btn .badge-total {
            position: absolute;
            top: -6px;
            right: -6px;
            background: var(--danger);
            color: #fff;
            border-radius: 10px;
            min-width: 20px;
            height: 20px;
            line-height: 20px;
            padding: 0 6px;
            font-size: 11px;
            font-weight: 700;
            text-align: center;
            border: 2px solid #fff;
        }
        .site-footer {
            margin-top: 40px;
            padding: 18px;
            text-align: center;
            font-size: 13px;
            color: var(--text-light);
            background: #fff;
            border: 1px solid var(--border);
            border-radius: var(--radius);
        }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>

    <div class="flex-between mb-20">
        <h1 style="margin:0;border:none;padding:0;font-size:22px;">欢迎您，<span style="color:var(--accent);"><?php echo htmlspecialchars($currentName); ?></span></h1>
        <div class="header-actions">
            <?php if ($isUser): ?>
                <a href="user_profile.php" class="btn">个人中心</a>
                <a href="delete_account.php" class="btn btn-danger" onclick="return confirm('确定要注销账号吗？此操作不可恢复！');">注销账号</a>
            <?php endif; ?>
            <a href="logout.php" class="btn btn-secondary">退出登录</a>
        </div>
    </div>

    <p class="text-mute mb-10">请选择功能：</p>

    <div class="menu">
        <?php if ($showMcGame): ?>
        <a href="mc_game.php" class="menu-item mc">
            <div class="icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 10h8M8 14h4"/></svg>
            </div>
            <div>MC游戏联机</div>
        </a>
        <?php endif; ?>

        <?php if ($showProgramSignup): ?>
        <a href="user_program.php" class="menu-item program">
            <div class="icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
            </div>
            <div>元旦晚会报名</div>
        </a>
        <?php endif; ?>

        <a href="forum.php" class="menu-item forum">
            <div class="icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            </div>
            <div>论坛</div>
        </a>

        <a href="cloud.php" class="menu-item cloud">
            <?php if ($cloudCount > 0): ?>
                <div class="badge-info"><?php echo $cloudCount; ?> 个 · <?php echo humanSize($cloudSize); ?></div>
            <?php endif; ?>
            <div class="icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/><path d="M12 12v6M9 15l3-3 3 3"/></svg>
            </div>
            <div>云盘</div>
        </a>
    </div>

    <div class="small-btn-row">
        <a href="message.php" class="small-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            留言板
        </a>
        <a href="chat_rooms.php" class="small-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8z"/></svg>
            聊天室
            <?php if ($totalUnread > 0): ?>
                <span class="badge-total"><?php echo $totalUnread > 99 ? '99+' : $totalUnread; ?></span>
            <?php endif; ?>
        </a>
        <a href="bug_list.php" class="small-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2l2 3M16 2l-2 3M9 9h6v6a3 3 0 0 1-6 0z"/><path d="M6 13H2M22 13h-4M6 8L3 5M18 8l3-3M6 18l-3 3M18 18l3 3"/></svg>
            bug反馈
        </a>
    </div>

    <?php if ($siteFooter): ?>
        <div class="site-footer"><?php echo $siteFooter; ?></div>
    <?php endif; ?>
</body>
</html>