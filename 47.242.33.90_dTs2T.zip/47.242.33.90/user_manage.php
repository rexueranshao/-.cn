<?php
// =============================================
// 文件名：user_manage.php
// 用途：管理员用户管理（查看、创建、删除、分配多个用户组）
// =============================================
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$error = '';
$success = '';

// 批量删除
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'bulk_delete') {
    if (isset($_POST['ids']) && is_array($_POST['ids'])) {
        $ids = array_map('intval', $_POST['ids']);
        if (!empty($ids)) {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            try {
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("DELETE FROM `user_group_relation` WHERE `user_id` IN ($placeholders)");
                $stmt->execute($ids);
                $stmt = $pdo->prepare("DELETE FROM `users` WHERE `id` IN ($placeholders)");
                $stmt->execute($ids);
                $pdo->commit();
                $success = '已删除 ' . count($ids) . ' 个用户';
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = '批量删除失败，请重试';
            }
        }
    }
}

// 创建用户
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_user') {
    $new_name = trim($_POST['new_name'] ?? '');
    $new_password = $_POST['new_password'] ?? '';
    if ($new_name === '' || $new_password === '') {
        $error = '请输入姓名和密码';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM `users` WHERE `name` = :name");
            $stmt->execute([':name' => $new_name]);
            if ($stmt->fetchColumn() > 0) {
                $error = '该姓名已存在，请更换';
            } else {
                $stmt = $pdo->prepare("INSERT INTO `users` (`name`, `password`, `group_id`) VALUES (:name, :password, NULL)");
                $stmt->execute([':name' => $new_name, ':password' => md5($new_password)]);
                $success = '用户创建成功';
            }
        } catch (PDOException $e) {
            $error = '数据库操作失败，请重试';
        }
    }
}

// 删除单个用户
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $deleteId = intval($_GET['id']);
    if ($deleteId > 0) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("DELETE FROM `user_group_relation` WHERE `user_id` = :uid");
            $stmt->execute([':uid' => $deleteId]);
            $stmt = $pdo->prepare("DELETE FROM `users` WHERE `id` = :uid");
            $stmt->execute([':uid' => $deleteId]);
            $pdo->commit();
            $success = '用户已删除';
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = '删除失败，请重试';
        }
    }
    header('Location: user_manage.php');
    exit;
}

// 更新用户组
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_groups') {
    $userId = intval($_POST['user_id'] ?? 0);
    $mainGroupId = $_POST['main_group'] ?? '';
    $mainGroupId = ($mainGroupId !== '') ? intval($mainGroupId) : null;
    $additionalGroups = $_POST['additional_groups'] ?? [];
    if (is_array($additionalGroups)) $additionalGroups = array_map('intval', $additionalGroups);

    if ($userId > 0) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("UPDATE `users` SET `group_id` = :gid WHERE `id` = :uid");
            $stmt->execute([':gid' => $mainGroupId, ':uid' => $userId]);
            $stmt = $pdo->prepare("DELETE FROM `user_group_relation` WHERE `user_id` = :uid");
            $stmt->execute([':uid' => $userId]);
            foreach ($additionalGroups as $gid) {
                if ($gid > 0 && $gid != $mainGroupId) {
                    $stmt = $pdo->prepare("INSERT INTO `user_group_relation` (`user_id`, `group_id`) VALUES (:uid, :gid)");
                    $stmt->execute([':uid' => $userId, ':gid' => $gid]);
                }
            }
            $pdo->commit();
            $success = '用户组更新成功';
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = '更新失败，请重试';
        }
    }
}

// 用户列表
$userList = [];
try {
    $sql = "SELECT u.id, u.name, u.group_id, g.name AS main_group_name FROM users u LEFT JOIN user_groups g ON u.group_id = g.id ORDER BY u.id ASC";
    $stmt = $pdo->query($sql);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT r.user_id, g.id, g.name FROM user_group_relation r JOIN user_groups g ON r.group_id = g.id ORDER BY g.id ASC");
    $relations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $additionalMap = [];
    foreach ($relations as $rel) {
        $additionalMap[$rel['user_id']][] = ['id' => $rel['id'], 'name' => $rel['name']];
    }
    foreach ($users as $u) {
        $u['additional_groups'] = $additionalMap[$u['id']] ?? [];
        $userList[] = $u;
    }
} catch (PDOException $e) {
    $error = '用户列表查询失败，请检查数据表';
}

$groupList = [];
try {
    $stmt = $pdo->query("SELECT `id`, `name` FROM `user_groups` ORDER BY `id` ASC");
    $groupList = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户管理</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .group-edit-form { display: inline-block; }
        .group-edit-form select, .group-edit-form button { margin: 2px 3px; }
        .checkbox-inline { display: inline-flex; align-items: center; gap: 4px; margin-right: 10px; font-size: 12px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>用户管理</h1>
    <p class="page-nav">
        <a href="admin_index.php" class="btn btn-secondary btn-sm">返回后台首页</a>
        <a href="group_manage.php" class="btn btn-secondary btn-sm">用户组管理</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:640px;">
        <h2>创建新用户</h2>
        <form method="post" action="user_manage.php" class="flex">
            <input type="hidden" name="action" value="create_user">
            <label style="font-size:13px;color:var(--text-light);">姓名</label>
            <input type="text" name="new_name" required style="max-width:180px;">
            <label style="font-size:13px;color:var(--text-light);">密码</label>
            <input type="password" name="new_password" required style="max-width:180px;">
            <button type="submit" class="btn">创建用户</button>
        </form>
    </div>

    <div class="card" style="padding:0;overflow:hidden;">
        <div style="padding:16px 20px;border-bottom:1px solid var(--border);">
            <h2 style="margin:0;">现有用户列表（<?php echo count($userList); ?>）</h2>
        </div>
        <?php if (empty($userList)): ?>
            <p class="text-mute" style="padding:30px;text-align:center;">暂无用户</p>
        <?php else: ?>
            <form method="post" action="user_manage.php" onsubmit="return confirm('确定删除选中的用户吗？');">
                <input type="hidden" name="action" value="bulk_delete">
                <table>
                    <tr>
                        <th style="width:40px;"><input type="checkbox" onclick="toggleAll(this)"></th>
                        <th style="width:60px;">ID</th>
                        <th style="width:110px;">姓名</th>
                        <th style="width:100px;">主组</th>
                        <th style="width:140px;">附加组</th>
                        <th>修改组</th>
                        <th style="width:80px;">操作</th>
                    </tr>
                    <?php foreach ($userList as $user): ?>
                    <tr>
                        <td><input type="checkbox" name="ids[]" value="<?php echo $user['id']; ?>"></td>
                        <td><?php echo $user['id']; ?></td>
                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                        <td><?php echo htmlspecialchars($user['main_group_name'] ?? '未分组'); ?></td>
                        <td>
                            <?php if (!empty($user['additional_groups'])): ?>
                                <?php echo implode(', ', array_map(function($g){ return htmlspecialchars($g['name']); }, $user['additional_groups'])); ?>
                            <?php else: ?>
                                <span class="text-mute">无</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="post" action="user_manage.php" class="group-edit-form">
                                <input type="hidden" name="action" value="update_groups">
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                <select name="main_group" style="max-width:140px;">
                                    <option value="">未分组</option>
                                    <?php foreach ($groupList as $grp): ?>
                                        <option value="<?php echo $grp['id']; ?>" <?php echo ($user['group_id'] == $grp['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($grp['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="mt-10">
                                    <?php foreach ($groupList as $grp): ?>
                                        <label class="checkbox-inline">
                                            <input type="checkbox" name="additional_groups[]" value="<?php echo $grp['id']; ?>" 
                                                <?php echo in_array($grp['id'], array_column($user['additional_groups'], 'id')) ? 'checked' : ''; ?>>
                                            <?php echo htmlspecialchars($grp['name']); ?>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                                <button type="submit" class="btn btn-sm mt-10">保存组</button>
                            </form>
                        </td>
                        <td>
                            <a href="user_manage.php?action=delete&id=<?php echo $user['id']; ?>" onclick="return confirm('确定要删除该用户吗？');">删除</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
                <div style="padding:14px 20px;border-top:1px solid var(--border);">
                    <button type="submit" class="btn btn-danger btn-sm">批量删除选中</button>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <script>
        function toggleAll(source) {
            var checkboxes = document.querySelectorAll('input[name="ids[]"]');
            checkboxes.forEach(function(cb) { cb.checked = source.checked; });
        }
    </script>
</body>
</html>