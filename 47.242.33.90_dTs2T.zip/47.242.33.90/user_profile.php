<?php
// =============================================
// 文件名：user_profile.php
// 用途：个人中心（资料编辑、头像上传、签到、购买装饰）
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$currentUser = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$error = '';
$success = '';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$userId = 0;
$userData = null;
try {
    $stmt = $pdo->prepare("SELECT id, name, points, avatar, avatar_frame, name_color, signature, last_sign_date FROM users WHERE name = :name");
    $stmt->execute([':name' => $currentUser]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($userData) $userId = $userData['id'];
} catch (PDOException $e) {
    $error = '获取用户信息失败';
}

// 签到
if (isset($_GET['action']) && $_GET['action'] === 'sign' && $userId > 0) {
    $today = date('Y-m-d');
    if ($userData['last_sign_date'] == $today) {
        $error = '今天已经签到过了';
    } else {
        $pointsAwarded = 10;
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("UPDATE users SET points = points + :points, last_sign_date = :today WHERE id = :uid");
            $stmt->execute([':points' => $pointsAwarded, ':today' => $today, ':uid' => $userId]);
            $stmt = $pdo->prepare("INSERT INTO sign_logs (user_id, sign_date, points_awarded) VALUES (:uid, :today, :points)");
            $stmt->execute([':uid' => $userId, ':today' => $today, ':points' => $pointsAwarded]);
            $pdo->commit();
            $success = "签到成功，获得{$pointsAwarded}积分";
            $userData['points'] += $pointsAwarded;
            $userData['last_sign_date'] = $today;
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = '签到失败，请稍后再试';
        }
    }
}

// 上传头像
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_avatar') {
    if ($userId > 0 && isset($_FILES['avatar_file']) && $_FILES['avatar_file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['avatar_file'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 2 * 1024 * 1024;

        if (function_exists('getimagesize')) {
            $imageInfo = @getimagesize($file['tmp_name']);
            if ($imageInfo === false) {
                $error = '文件不是有效图片';
            } else {
                $mime = $imageInfo['mime'];
                if (!in_array($mime, $allowedTypes)) {
                    $error = '只允许上传 JPG、PNG、GIF、WEBP 格式的图片';
                } elseif ($file['size'] > $maxSize) {
                    $error = '图片大小不能超过 2MB';
                } else {
                    $extMap = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
                    $ext = $extMap[$mime] ?? 'jpg';
                    $newFileName = 'avatar_' . $userId . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                    $uploadDir = __DIR__ . '/uploads/avatars/';
                    $targetPath = $uploadDir . $newFileName;
                    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

                    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                        $avatarUrl = 'uploads/avatars/' . $newFileName;
                        try {
                            $stmt = $pdo->prepare("UPDATE users SET avatar = :avatar WHERE id = :uid");
                            $stmt->execute([':avatar' => $avatarUrl, ':uid' => $userId]);
                            $userData['avatar'] = $avatarUrl;
                            $success = '头像上传成功';
                        } catch (PDOException $e) {
                            $error = '数据库更新失败，请重试';
                            @unlink($targetPath);
                        }
                    } else {
                        $error = '文件保存失败，请检查目录权限';
                    }
                }
            }
        } else {
            $error = '服务器缺少图片处理扩展（GD）';
        }
    } else {
        $error = '请选择要上传的图片文件';
    }
}

// 更新资料
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $newAvatarUrl = trim($_POST['avatar'] ?? '');
    $newSignature = trim($_POST['signature'] ?? '');
    $newFrame = trim($_POST['avatar_frame'] ?? '');
    $newColor = trim($_POST['name_color'] ?? '');

    if ($userId > 0) {
        try {
            if ($newFrame !== '') {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_inventory WHERE user_id = :uid AND item_type = 'frame' AND item_id = :item");
                $stmt->execute([':uid' => $userId, ':item' => $newFrame]);
                if ($stmt->fetchColumn() == 0) {
                    $error = '您尚未拥有该头像框';
                    $newFrame = $userData['avatar_frame'];
                }
            }
            if ($newColor !== '') {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_inventory WHERE user_id = :uid AND item_type = 'color' AND item_id = :item");
                $stmt->execute([':uid' => $userId, ':item' => $newColor]);
                if ($stmt->fetchColumn() == 0) {
                    $error = '您尚未拥有该彩色名字';
                    $newColor = $userData['name_color'];
                }
            }
            if (!$error) {
                $finalAvatar = ($newAvatarUrl !== '') ? $newAvatarUrl : ($userData['avatar'] ?? '');
                $stmt = $pdo->prepare("UPDATE users SET avatar = :avatar, signature = :signature, avatar_frame = :frame, name_color = :color WHERE id = :uid");
                $stmt->execute([
                    ':avatar' => $finalAvatar, ':signature' => $newSignature,
                    ':frame' => $newFrame, ':color' => $newColor, ':uid' => $userId
                ]);
                $success = '资料已更新';
                $userData['avatar'] = $finalAvatar;
                $userData['signature'] = $newSignature;
                $userData['avatar_frame'] = $newFrame;
                $userData['name_color'] = $newColor;
            }
        } catch (PDOException $e) {
            $error = '更新失败，请稍后再试';
        }
    }
}

// 购买装饰
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'buy_item') {
    $itemType = $_POST['item_type'] ?? '';
    $itemId = $_POST['item_id'] ?? '';
    if ($userId > 0 && $itemType && $itemId) {
        $prices = [
            'frame_gold' => 50, 'frame_diamond' => 100, 'frame_rainbow' => 150,
            'color_red' => 20, 'color_blue' => 20, 'color_green' => 20, 'color_purple' => 30,
        ];
        if (!isset($prices[$itemId])) {
            $error = '商品不存在';
        } else {
            $price = $prices[$itemId];
            try {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_inventory WHERE user_id = :uid AND item_type = :type AND item_id = :item");
                $stmt->execute([':uid' => $userId, ':type' => $itemType, ':item' => $itemId]);
                if ($stmt->fetchColumn() > 0) {
                    $error = '您已拥有该商品';
                } else {
                    if ($userData['points'] < $price) {
                        $error = '积分不足，需要' . $price . '积分';
                    } else {
                        $pdo->beginTransaction();
                        $stmt = $pdo->prepare("UPDATE users SET points = points - :price WHERE id = :uid");
                        $stmt->execute([':price' => $price, ':uid' => $userId]);
                        $stmt = $pdo->prepare("INSERT INTO user_inventory (user_id, item_type, item_id) VALUES (:uid, :type, :item)");
                        $stmt->execute([':uid' => $userId, ':type' => $itemType, ':item' => $itemId]);
                        $pdo->commit();
                        $success = '购买成功！';
                        $userData['points'] -= $price;
                    }
                }
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = '购买失败，请稍后再试';
            }
        }
    }
}

// 已拥有商品
$ownedFrames = [];
$ownedColors = [];
if ($userId > 0) {
    try {
        $stmt = $pdo->prepare("SELECT item_id FROM user_inventory WHERE user_id = :uid AND item_type = 'frame'");
        $stmt->execute([':uid' => $userId]);
        $ownedFrames = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $stmt = $pdo->prepare("SELECT item_id FROM user_inventory WHERE user_id = :uid AND item_type = 'color'");
        $stmt->execute([':uid' => $userId]);
        $ownedColors = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {}
}

function displayAvatar($avatarUrl, $avatarFrame, $userName, $size = 'large') {
    $width = $size === 'large' ? 80 : 30;
    $style = "display:inline-block;width:{$width}px;height:{$width}px;border-radius:50%;background:#ccc;text-align:center;line-height:{$width}px;color:#fff;font-size:".($width*0.5)."px;";
    if (!empty($avatarUrl)) {
        return '<img src="'.htmlspecialchars($avatarUrl).'" alt="头像" class="avatar '.htmlspecialchars($avatarFrame).'" style="width:'.$width.'px;height:'.$width.'px;border-radius:50%;object-fit:cover;border:2px solid #ddd;">';
    } else {
        $frameClass = !empty($avatarFrame) ? htmlspecialchars($avatarFrame) : '';
        return '<span class="avatar '.$frameClass.'" style="'.$style.'">'.htmlspecialchars(mb_substr($userName,0,1)).'</span>';
    }
}

$frameNames = ['frame_gold'=>'金色边框','frame_diamond'=>'钻石边框','frame_rainbow'=>'彩虹边框'];
$colorNames = ['color_red'=>'红色','color_blue'=>'蓝色','color_green'=>'绿色','color_purple'=>'紫色'];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>个人中心</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-row { margin-bottom: 12px; }
        .form-row label { display: block; margin-bottom: 5px; font-weight: 500; color: var(--text-light); font-size: 13px; }
        .avatar-preview { margin-bottom: 10px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>个人中心</h1>
    <p class="page-nav">
        <a href="user_index.php" class="btn btn-secondary btn-sm">返回首页</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card">
        <h2>我的资料</h2>
        <p>用户名：<?php echo htmlspecialchars($currentUser); ?></p>
        <p>当前积分：<strong><?php echo $userData['points'] ?? 0; ?></strong></p>
        <p><a href="user_profile.php?action=sign" class="btn btn-sm">每日签到（+10积分）</a></p>

        <div class="avatar-preview">
            <?php echo displayAvatar($userData['avatar'] ?? '', $userData['avatar_frame'] ?? '', $currentUser, 'large'); ?>
        </div>

        <h3>上传自定义头像</h3>
        <form method="post" action="user_profile.php" enctype="multipart/form-data">
            <input type="hidden" name="action" value="upload_avatar">
            <div class="form-row">
                <input type="file" name="avatar_file" accept="image/*" required>
            </div>
            <button type="submit" class="btn">上传头像</button>
        </form>
        <p class="text-mute mt-10">支持 JPG/PNG/GIF/WEBP，大小不超过 2MB</p>

        <h3 class="mt-20">修改资料</h3>
        <form method="post" action="user_profile.php">
            <input type="hidden" name="action" value="update_profile">
            <div class="form-row">
                <label>头像URL（可选）</label>
                <input type="text" name="avatar" value="<?php echo htmlspecialchars($userData['avatar'] ?? ''); ?>">
            </div>
            <div class="form-row">
                <label>个性签名</label>
                <input type="text" name="signature" value="<?php echo htmlspecialchars($userData['signature'] ?? ''); ?>">
            </div>
            <div class="form-row">
                <label>使用头像框</label>
                <select name="avatar_frame">
                    <option value="">无</option>
                    <?php foreach ($ownedFrames as $fid): ?>
                        <option value="<?php echo $fid; ?>" <?php echo ($userData['avatar_frame'] == $fid) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($frameNames[$fid] ?? $fid); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row">
                <label>使用彩色名字</label>
                <select name="name_color">
                    <option value="">默认</option>
                    <?php foreach ($ownedColors as $cid): ?>
                        <option value="<?php echo $cid; ?>" <?php echo ($userData['name_color'] == $cid) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($colorNames[$cid] ?? $cid); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn">保存资料</button>
        </form>
    </div>

    <div class="card">
        <h2>购买装饰</h2>
        <h3>头像框</h3>
        <table>
            <tr><th>名称</th><th style="width:100px;">价格</th><th style="width:120px;">操作</th></tr>
            <?php foreach ($frameNames as $fid => $fname): ?>
            <tr>
                <td><?php echo htmlspecialchars($fname); ?></td>
                <td><?php echo ['frame_gold'=>50,'frame_diamond'=>100,'frame_rainbow'=>150][$fid] ?? 0; ?></td>
                <td>
                    <?php if (in_array($fid, $ownedFrames)): ?>
                        <span class="text-mute">已拥有</span>
                    <?php else: ?>
                        <form method="post" action="user_profile.php" style="display:inline;">
                            <input type="hidden" name="action" value="buy_item">
                            <input type="hidden" name="item_type" value="frame">
                            <input type="hidden" name="item_id" value="<?php echo $fid; ?>">
                            <button type="submit" class="btn btn-sm">购买</button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <h3 class="mt-20">彩色名字</h3>
        <table>
            <tr><th>名称</th><th style="width:100px;">价格</th><th style="width:120px;">操作</th></tr>
            <?php foreach ($colorNames as $cid => $cname): ?>
            <tr>
                <td><?php echo htmlspecialchars($cname); ?></td>
                <td><?php echo ['color_red'=>20,'color_blue'=>20,'color_green'=>20,'color_purple'=>30][$cid] ?? 0; ?></td>
                <td>
                    <?php if (in_array($cid, $ownedColors)): ?>
                        <span class="text-mute">已拥有</span>
                    <?php else: ?>
                        <form method="post" action="user_profile.php" style="display:inline;">
                            <input type="hidden" name="action" value="buy_item">
                            <input type="hidden" name="item_type" value="color">
                            <input type="hidden" name="item_id" value="<?php echo $cid; ?>">
                            <button type="submit" class="btn btn-sm">购买</button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>