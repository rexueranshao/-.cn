<?php
// =============================================
// 文件名：user_program.php
// 用途：普通用户元旦晚会报名页
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

// 权限：管理员直接通过；普通用户需开关开启且所有组只有"同学"
if (!isset($_SESSION['admin'])) {
    $currentUser = $_SESSION['user'];
    $programSignupEnabled = false;
    try {
        $stmt = $pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'program_signup_enabled' LIMIT 1");
        $val = $stmt->fetchColumn();
        if ($val === '1') $programSignupEnabled = true;
    } catch (PDOException $e) {}

    $userGroup = '';
    try {
        $stmt = $pdo->prepare("SELECT g.name FROM users u LEFT JOIN user_groups g ON u.group_id = g.id WHERE u.name = :name");
        $stmt->execute([':name' => $currentUser]);
        $userGroup = $stmt->fetchColumn() ?: '';
    } catch (PDOException $e) {}

    if (!$programSignupEnabled || $userGroup !== '同学') {
        header('Location: user_index.php');
        exit;
    }
}

$currentName = $_SESSION['user'] ?? $_SESSION['admin'] ?? '';
$success = '';
$error = '';

// 删除报名
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $deleteId = intval($_GET['id']);
    if ($deleteId > 0) {
        try {
            $stmt = $pdo->prepare("SELECT `name` FROM `program_registrations` WHERE `id` = :id");
            $stmt->execute([':id' => $deleteId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && $row['name'] === $currentName) {
                $stmt = $pdo->prepare("DELETE FROM `program_registrations` WHERE `id` = :id AND `name` = :name");
                $stmt->execute([':id' => $deleteId, ':name' => $currentName]);
            }
        } catch (PDOException $e) {}
    }
    header('Location: user_program.php');
    exit;
}

// 提交报名
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $program_name = trim($_POST['program_name'] ?? '');
    $program_type = trim($_POST['program_type'] ?? '');
    $duration = trim($_POST['duration'] ?? '');
    $props = trim($_POST['props'] ?? '');
    $remark = trim($_POST['remark'] ?? '');

    if ($program_name === '' || $program_type === '' || $duration === '') {
        $error = '请填写必填项（节目名称、节目类型、预估时长）';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO `program_registrations` (`name`, `program_name`, `program_type`, `duration`, `props`, `remark`) VALUES (:name, :program_name, :program_type, :duration, :props, :remark)");
            $stmt->execute([
                ':name' => $currentName,
                ':program_name' => $program_name,
                ':program_type' => $program_type,
                ':duration' => $duration,
                ':props' => $props,
                ':remark' => $remark,
            ]);
            $success = '报名成功！';
        } catch (PDOException $e) {
            $error = '数据库写入失败，请稍后再试。';
        }
    }
}

// 我的报名记录
$myRecords = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM `program_registrations` WHERE `name` = :name ORDER BY `created_at` DESC, `id` DESC");
    $stmt->execute([':name' => $currentName]);
    $myRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>元旦晚会报名</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-row { margin-bottom: 12px; }
        .form-row label { display: block; margin-bottom: 5px; font-weight: 500; color: var(--text-light); font-size: 13px; }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <h1>元旦晚会报名</h1>
    <p class="page-nav">
        <a href="user_index.php" class="btn btn-secondary btn-sm">返回首页</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>

    <div class="card" style="max-width:640px;">
        <h2>报名表单</h2>
        <form method="post" action="user_program.php">
            <div class="form-row">
                <label>报名人姓名</label>
                <input type="text" value="<?php echo htmlspecialchars($currentName); ?>" disabled>
            </div>
            <div class="form-row">
                <label>节目名称 <span style="color:var(--danger);">*</span></label>
                <input type="text" name="program_name" required>
            </div>
            <div class="form-row">
                <label>节目类型 <span style="color:var(--danger);">*</span></label>
                <input type="text" name="program_type" required placeholder="如：歌舞、小品、魔术等">
            </div>
            <div class="form-row">
                <label>预估时长 <span style="color:var(--danger);">*</span></label>
                <input type="text" name="duration" required placeholder="如：5分钟、3-5分钟">
            </div>
            <div class="form-row">
                <label>道具需求</label>
                <textarea name="props" rows="3"></textarea>
            </div>
            <div class="form-row">
                <label>备注</label>
                <textarea name="remark" rows="3"></textarea>
            </div>
            <button type="submit" class="btn">提交报名</button>
        </form>
    </div>

    <div class="card">
        <h2>我的报名记录</h2>
        <?php if (empty($myRecords)): ?>
            <p class="text-mute">暂无报名记录。</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>节目名称</th>
                    <th style="width:100px;">类型</th>
                    <th style="width:100px;">时长</th>
                    <th style="width:120px;">道具</th>
                    <th style="width:120px;">备注</th>
                    <th style="width:160px;">时间</th>
                    <th style="width:80px;">操作</th>
                </tr>
                <?php foreach ($myRecords as $row): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['program_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['program_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['duration']); ?></td>
                    <td><?php echo htmlspecialchars($row['props']); ?></td>
                    <td><?php echo htmlspecialchars($row['remark']); ?></td>
                    <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                    <td>
                        <a href="user_program.php?action=delete&id=<?php echo $row['id']; ?>" onclick="return confirm('确定删除吗？');">删除</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>