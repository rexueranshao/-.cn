<?php
// =============================================
// 文件名：user_view.php
// 用途：查看他人个人主页
// =============================================
session_start();
if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

$viewName = trim($_GET['name'] ?? '');
$userData = null;
$error = '';

if ($viewName === '') {
    $error = '未指定用户';
} else {
    try {
        $stmt = $pdo->prepare("SELECT id, name, avatar, avatar_frame, name_color, signature, points FROM users WHERE name = :name");
        $stmt->execute([':name' => $viewName]);
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$userData) $error = '用户不存在';
    } catch (PDOException $e) {
        $error = '查询失败';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $userData ? htmlspecialchars($userData['name']) . '的主页' : '用户主页'; ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .profile-card {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 30px;
            text-align: center;
            box-shadow: var(--shadow-sm);
            max-width: 500px;
        }
        .avatar-large {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #ddd;
            display: inline-block;
        }
        .profile-name {
            font-size: 24px;
            font-weight: 700;
            margin: 16px 0 8px;
        }
    </style>
</head>
<body>
    <?php include 'announcement_bar.php'; ?>
    <p class="page-nav">
        <a href="user_index.php" class="btn btn-secondary btn-sm">返回首页</a>
        <a href="logout.php" class="btn btn-secondary btn-sm">退出登录</a>
    </p>

    <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>

    <?php if ($userData): ?>
        <div class="profile-card">
            <?php if (!empty($userData['avatar'])): ?>
                <img class="avatar-large <?php echo htmlspecialchars($userData['avatar_frame']); ?>" src="<?php echo htmlspecialchars($userData['avatar']); ?>" alt="头像">
            <?php else: ?>
                <span style="display:inline-block;width:100px;height:100px;border-radius:50%;background:#ccc;text-align:center;line-height:100px;color:#fff;font-size:40px;">
                    <?php echo htmlspecialchars(mb_substr($userData['name'],0,1)); ?>
                </span>
            <?php endif; ?>
            <div class="profile-name" style="color:<?php echo htmlspecialchars($userData['name_color'] ?: '#1f2937'); ?>;">
                <?php echo htmlspecialchars($userData['name']); ?>
            </div>
            <p class="text-mute">积分：<?php echo (int)$userData['points']; ?></p>
            <p>个性签名：<?php echo htmlspecialchars($userData['signature'] ?: '这个人很懒，什么都没写'); ?></p>
        </div>
    <?php endif; ?>
</body>
</html>